var networks = {"spy-family-s2-adjectives-network-data.tsv": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "spy-family-s2-adjectives-network-data.tsv",
    "name" : "spy-family-s2-adjectives-network-data.tsv",
    "SUID" : 155,
    "__Annotations" : [ ],
    "selected" : true
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "4019",
        "shared_name" : "wilted",
        "name" : "wilted",
        "SUID" : 4019,
        "selected" : false
      },
      "position" : {
        "x" : 1284.844313095522,
        "y" : 1047.885720364934
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4011",
        "shared_name" : "weird",
        "name" : "weird",
        "SUID" : 4011,
        "selected" : false
      },
      "position" : {
        "x" : 1227.435919649523,
        "y" : 1171.1575719067241
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3988",
        "shared_name" : "suspect",
        "name" : "suspect",
        "SUID" : 3988,
        "selected" : false
      },
      "position" : {
        "x" : 1175.5744648096256,
        "y" : 1097.787588019345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3968",
        "shared_name" : "skinny",
        "name" : "skinny",
        "SUID" : 3968,
        "selected" : false
      },
      "position" : {
        "x" : 1402.9330121229946,
        "y" : 1346.6546643801958
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3954",
        "shared_name" : "shriveled",
        "name" : "shriveled",
        "SUID" : 3954,
        "selected" : false
      },
      "position" : {
        "x" : 1403.7469455192013,
        "y" : 1064.9813380063224
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3949",
        "shared_name" : "serial",
        "name" : "serial",
        "SUID" : 3949,
        "selected" : false
      },
      "position" : {
        "x" : 1315.1844658862587,
        "y" : 1383.0013023099746
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3932",
        "shared_name" : "restless",
        "name" : "restless",
        "SUID" : 3932,
        "selected" : false
      },
      "position" : {
        "x" : 1284.8443130955216,
        "y" : 1469.9265159219858
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3918",
        "shared_name" : "preposterous",
        "name" : "preposterous",
        "SUID" : 3918,
        "selected" : false
      },
      "position" : {
        "x" : 1403.7469455192008,
        "y" : 1452.830898280598
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3910",
        "shared_name" : "plastic",
        "name" : "plastic",
        "SUID" : 3910,
        "selected" : false
      },
      "position" : {
        "x" : 1402.9330121229946,
        "y" : 1171.1575719067241
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3887",
        "shared_name" : "multiple",
        "name" : "multiple",
        "SUID" : 3887,
        "selected" : false
      },
      "position" : {
        "x" : 1494.531616412,
        "y" : 1374.165533152689
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3867",
        "shared_name" : "irrational",
        "name" : "irrational",
        "SUID" : 3867,
        "selected" : false
      },
      "position" : {
        "x" : 1175.5744648096256,
        "y" : 1420.0246482675739
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3862",
        "shared_name" : "intelligent",
        "name" : "intelligent",
        "SUID" : 3862,
        "selected" : false
      },
      "position" : {
        "x" : 1110.6298054284307,
        "y" : 1198.8434505790292
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3857",
        "shared_name" : "inside",
        "name" : "inside",
        "SUID" : 3857,
        "selected" : false
      },
      "position" : {
        "x" : 1494.5316164120004,
        "y" : 1143.6467031342318
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3852",
        "shared_name" : "innocent",
        "name" : "innocent",
        "SUID" : 3852,
        "selected" : false
      },
      "position" : {
        "x" : 1227.435919649523,
        "y" : 1346.6546643801958
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3820",
        "shared_name" : "gentle",
        "name" : "gentle",
        "SUID" : 3820,
        "selected" : false
      },
      "position" : {
        "x" : 1191.0892817197441,
        "y" : 1258.90611814346
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3815",
        "shared_name" : "fluffy",
        "name" : "fluffy",
        "SUID" : 3815,
        "selected" : false
      },
      "position" : {
        "x" : 1315.1844658862587,
        "y" : 1134.8109339769453
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3801",
        "shared_name" : "enjoyable",
        "name" : "enjoyable",
        "SUID" : 3801,
        "selected" : false
      },
      "position" : {
        "x" : 1110.6298054284302,
        "y" : 1318.9687857078902
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3781",
        "shared_name" : "critical",
        "name" : "critical",
        "SUID" : 3781,
        "selected" : false
      },
      "position" : {
        "x" : 1439.2796500527734,
        "y" : 1258.90611814346
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3761",
        "shared_name" : "addictive",
        "name" : "addictive",
        "SUID" : 3761,
        "selected" : false
      },
      "position" : {
        "x" : 1528.374834219288,
        "y" : 1258.90611814346
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3756",
        "shared_name" : "02x12_-_Part_of_the_Family",
        "name" : "02x12_-_Part_of_the_Family",
        "SUID" : 3756,
        "selected" : false
      },
      "position" : {
        "x" : 1315.1844658862587,
        "y" : 1258.90611814346
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3745",
        "shared_name" : "worthless",
        "name" : "worthless",
        "SUID" : 3745,
        "selected" : false
      },
      "position" : {
        "x" : 1764.2508660605954,
        "y" : -689.3424280932759
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3734",
        "shared_name" : "womanly",
        "name" : "womanly",
        "SUID" : 3734,
        "selected" : false
      },
      "position" : {
        "x" : 1890.250483851009,
        "y" : -815.3420458836893
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3729",
        "shared_name" : "wise",
        "name" : "wise",
        "SUID" : 3729,
        "selected" : false
      },
      "position" : {
        "x" : 1504.027688805384,
        "y" : -476.2837274195854
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3724",
        "shared_name" : "willing",
        "name" : "willing",
        "SUID" : 3724,
        "selected" : false
      },
      "position" : {
        "x" : 1742.3817666758196,
        "y" : -804.3499708710315
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3719",
        "shared_name" : "weak",
        "name" : "weak",
        "SUID" : 3719,
        "selected" : false
      },
      "position" : {
        "x" : 1819.154520256407,
        "y" : -443.16256278822993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3714",
        "shared_name" : "valuable",
        "name" : "valuable",
        "SUID" : 3714,
        "selected" : false
      },
      "position" : {
        "x" : 1588.7537735871233,
        "y" : -689.3424280932761
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3706",
        "shared_name" : "useful",
        "name" : "useful",
        "SUID" : 3706,
        "selected" : false
      },
      "position" : {
        "x" : 1462.7541557967097,
        "y" : -387.84571782939065
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3701",
        "shared_name" : "urgent",
        "name" : "urgent",
        "SUID" : 3701,
        "selected" : false
      },
      "position" : {
        "x" : 1978.787872323403,
        "y" : -601.5938818565401
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3696",
        "shared_name" : "unannounced",
        "name" : "unannounced",
        "SUID" : 3696,
        "selected" : false
      },
      "position" : {
        "x" : 1467.9706725393503,
        "y" : -557.269111910359
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3688",
        "shared_name" : "trivial",
        "name" : "trivial",
        "SUID" : 3688,
        "selected" : false
      },
      "position" : {
        "x" : 1819.154520256407,
        "y" : -760.0252009248504
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3680",
        "shared_name" : "tiresome",
        "name" : "tiresome",
        "SUID" : 3680,
        "selected" : false
      },
      "position" : {
        "x" : 1800.5975039903738,
        "y" : -601.5938818565401
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3672",
        "shared_name" : "suited",
        "name" : "suited",
        "SUID" : 3672,
        "selected" : false
      },
      "position" : {
        "x" : 1462.7541557967097,
        "y" : -815.3420458836895
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3661",
        "shared_name" : "spacious",
        "name" : "spacious",
        "SUID" : 3661,
        "selected" : false
      },
      "position" : {
        "x" : 1504.0276888053836,
        "y" : -726.9040362934948
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3653",
        "shared_name" : "smiley",
        "name" : "smiley",
        "SUID" : 3653,
        "selected" : false
      },
      "position" : {
        "x" : 1654.2178582385427,
        "y" : -389.5713926677158
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3642",
        "shared_name" : "sexy",
        "name" : "sexy",
        "SUID" : 3642,
        "selected" : false
      },
      "position" : {
        "x" : 1374.2167673243152,
        "y" : -601.5938818565403
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3634",
        "shared_name" : "rounded",
        "name" : "rounded",
        "SUID" : 3634,
        "selected" : false
      },
      "position" : {
        "x" : 1569.9071356573445,
        "y" : -416.9656070379756
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3623",
        "shared_name" : "professional",
        "name" : "professional",
        "SUID" : 3623,
        "selected" : false
      },
      "position" : {
        "x" : 1742.3817666758196,
        "y" : -398.83779284204866
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3618",
        "shared_name" : "potential",
        "name" : "potential",
        "SUID" : 3618,
        "selected" : false
      },
      "position" : {
        "x" : 1676.5023198238591,
        "y" : -725.6890660230547
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3592",
        "shared_name" : "nauseous",
        "name" : "nauseous",
        "SUID" : 3592,
        "selected" : false
      },
      "position" : {
        "x" : 1871.261412427651,
        "y" : -688.3062166084096
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3587",
        "shared_name" : "naive",
        "name" : "naive",
        "SUID" : 3587,
        "selected" : false
      },
      "position" : {
        "x" : 1588.7537735871233,
        "y" : -513.8453356198042
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3579",
        "shared_name" : "major",
        "name" : "major",
        "SUID" : 3579,
        "selected" : false
      },
      "position" : {
        "x" : 1676.5023198238591,
        "y" : -299.30832935699664
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3556",
        "shared_name" : "ill",
        "name" : "ill",
        "SUID" : 3556,
        "selected" : false
      },
      "position" : {
        "x" : 1676.5023198238591,
        "y" : -477.49869769002544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3551",
        "shared_name" : "hot",
        "name" : "hot",
        "SUID" : 3551,
        "selected" : false
      },
      "position" : {
        "x" : 2079.002319823859,
        "y" : 616.9061181434599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3528",
        "shared_name" : "future",
        "name" : "future",
        "SUID" : 3528,
        "selected" : false
      },
      "position" : {
        "x" : 1889.6926881568884,
        "y" : -601.5938818565401
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3520",
        "shared_name" : "formal",
        "name" : "formal",
        "SUID" : 3520,
        "selected" : false
      },
      "position" : {
        "x" : 1764.250866060595,
        "y" : -513.8453356198042
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3509",
        "shared_name" : "experienced",
        "name" : "experienced",
        "SUID" : 3509,
        "selected" : false
      },
      "position" : {
        "x" : 1890.2504838510085,
        "y" : -387.84571782939065
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3504",
        "shared_name" : "envious",
        "name" : "envious",
        "SUID" : 3504,
        "selected" : false
      },
      "position" : {
        "x" : 1467.9706725393503,
        "y" : -645.9186518027209
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3496",
        "shared_name" : "dull",
        "name" : "dull",
        "SUID" : 3496,
        "selected" : false
      },
      "position" : {
        "x" : 1871.261412427651,
        "y" : -514.8815471046705
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3491",
        "shared_name" : "drunk",
        "name" : "drunk",
        "SUID" : 3491,
        "selected" : false
      },
      "position" : {
        "x" : 1552.4071356573445,
        "y" : -601.5938818565401
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3480",
        "shared_name" : "curious",
        "name" : "curious",
        "SUID" : 3480,
        "selected" : false
      },
      "position" : {
        "x" : 1676.5023198238591,
        "y" : -903.8794343560837
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3469",
        "shared_name" : "confident",
        "name" : "confident",
        "SUID" : 3469,
        "selected" : false
      },
      "position" : {
        "x" : 1569.9071356573445,
        "y" : -786.2221566751048
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3437",
        "shared_name" : "acute",
        "name" : "acute",
        "SUID" : 3437,
        "selected" : false
      },
      "position" : {
        "x" : 1654.2178582385427,
        "y" : -813.6163710453645
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3432",
        "shared_name" : "02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "name" : "02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "SUID" : 3432,
        "selected" : false
      },
      "position" : {
        "x" : 1676.5023198238591,
        "y" : -601.5938818565401
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3424",
        "shared_name" : "worthy",
        "name" : "worthy",
        "SUID" : 3424,
        "selected" : false
      },
      "position" : {
        "x" : -1180.7203499472269,
        "y" : -823.5938818565401
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3416",
        "shared_name" : "unnerving",
        "name" : "unnerving",
        "SUID" : 3416,
        "selected" : false
      },
      "position" : {
        "x" : -1509.3701945715695,
        "y" : -763.5312142921098
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3408",
        "shared_name" : "unfortunate",
        "name" : "unfortunate",
        "SUID" : 3408,
        "selected" : false
      },
      "position" : {
        "x" : -1216.2530544807987,
        "y" : -1017.5186619936778
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3397",
        "shared_name" : "tra",
        "name" : "tra",
        "SUID" : 3397,
        "selected" : false
      },
      "position" : {
        "x" : -1392.5640803504773,
        "y" : -911.3424280932759
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3389",
        "shared_name" : "thrilling",
        "name" : "thrilling",
        "SUID" : 3389,
        "selected" : false
      },
      "position" : {
        "x" : -1335.1556869044784,
        "y" : -612.573484078014
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3384",
        "shared_name" : "threatening",
        "name" : "threatening",
        "SUID" : 3384,
        "selected" : false
      },
      "position" : {
        "x" : -1509.3701945715693,
        "y" : -883.6565494209708
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3379",
        "shared_name" : "tame",
        "name" : "tame",
        "SUID" : 3379,
        "selected" : false
      },
      "position" : {
        "x" : -1444.4255351903741,
        "y" : -984.7124119806547
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3374",
        "shared_name" : "swollen",
        "name" : "swollen",
        "SUID" : 3374,
        "selected" : false
      },
      "position" : {
        "x" : -1091.6251657807122,
        "y" : -823.5938818565401
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3363",
        "shared_name" : "sleepy",
        "name" : "sleepy",
        "SUID" : 3363,
        "selected" : false
      },
      "position" : {
        "x" : -1304.8155341137413,
        "y" : -947.6890660230547
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3343",
        "shared_name" : "remarkable",
        "name" : "remarkable",
        "SUID" : 3343,
        "selected" : false
      },
      "position" : {
        "x" : -1125.4683835879996,
        "y" : -938.8532968657685
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3323",
        "shared_name" : "ordinary",
        "name" : "ordinary",
        "SUID" : 3323,
        "selected" : false
      },
      "position" : {
        "x" : 61.002319823859125,
        "y" : -679.0938818565401
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3282",
        "shared_name" : "la",
        "name" : "la",
        "SUID" : 3282,
        "selected" : false
      },
      "position" : {
        "x" : -1335.155686904478,
        "y" : -1034.6142796350662
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3274",
        "shared_name" : "ideal",
        "name" : "ideal",
        "SUID" : 3274,
        "selected" : false
      },
      "position" : {
        "x" : -1304.8155341137413,
        "y" : -699.4986976900254
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3242",
        "shared_name" : "exhausting",
        "name" : "exhausting",
        "SUID" : 3242,
        "selected" : false
      },
      "position" : {
        "x" : -1392.5640803504773,
        "y" : -735.8453356198042
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3234",
        "shared_name" : "embarrassed",
        "name" : "embarrassed",
        "SUID" : 3234,
        "selected" : false
      },
      "position" : {
        "x" : -1217.0669878770054,
        "y" : -911.3424280932759
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3214",
        "shared_name" : "convincing",
        "name" : "convincing",
        "SUID" : 3214,
        "selected" : false
      },
      "position" : {
        "x" : -1125.4683835879998,
        "y" : -708.3344668473112
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3209",
        "shared_name" : "complicated",
        "name" : "complicated",
        "SUID" : 3209,
        "selected" : false
      },
      "position" : {
        "x" : -1428.9107182802559,
        "y" : -823.5938818565401
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3198",
        "shared_name" : "careless",
        "name" : "careless",
        "SUID" : 3198,
        "selected" : false
      },
      "position" : {
        "x" : -1217.0669878770054,
        "y" : -735.845335619804
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3193",
        "shared_name" : "bold",
        "name" : "bold",
        "SUID" : 3193,
        "selected" : false
      },
      "position" : {
        "x" : -1444.4255351903746,
        "y" : -662.4753517324257
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3179",
        "shared_name" : "awful",
        "name" : "awful",
        "SUID" : 3179,
        "selected" : false
      },
      "position" : {
        "x" : -1216.2530544807992,
        "y" : -629.6691017194021
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3174",
        "shared_name" : "02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "name" : "02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "SUID" : 3174,
        "selected" : false
      },
      "position" : {
        "x" : -1304.8155341137413,
        "y" : -823.5938818565401
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3163",
        "shared_name" : "western",
        "name" : "western",
        "SUID" : 3163,
        "selected" : false
      },
      "position" : {
        "x" : -832.0928643426555,
        "y" : -281.222156675105
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3155",
        "shared_name" : "upper",
        "name" : "upper",
        "SUID" : 3155,
        "selected" : false
      },
      "position" : {
        "x" : -849.5928643426554,
        "y" : -96.59388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3132",
        "shared_name" : "straightforward",
        "name" : "straightforward",
        "SUID" : 3132,
        "selected" : false
      },
      "position" : {
        "x" : -938.6880485091699,
        "y" : -96.59388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3127",
        "shared_name" : "sticky",
        "name" : "sticky",
        "SUID" : 3127,
        "selected" : false
      },
      "position" : {
        "x" : -725.4976801761409,
        "y" : 27.501302309974562
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3116",
        "shared_name" : "sentimental",
        "name" : "sentimental",
        "SUID" : 3116,
        "selected" : false
      },
      "position" : {
        "x" : -725.4976801761409,
        "y" : -220.6890660230547
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3099",
        "shared_name" : "risky",
        "name" : "risky",
        "SUID" : 3099,
        "selected" : false
      },
      "position" : {
        "x" : -618.9024960096262,
        "y" : -281.222156675105
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3088",
        "shared_name" : "peaceful",
        "name" : "peaceful",
        "SUID" : 3088,
        "selected" : false
      },
      "position" : {
        "x" : -1620.9976801761409,
        "y" : -47.093881856540065
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3062",
        "shared_name" : "impossible",
        "name" : "impossible",
        "SUID" : 3062,
        "selected" : false
      },
      "position" : {
        "x" : -813.2462264128768,
        "y" : -8.845335619804246
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3057",
        "shared_name" : "hey",
        "name" : "hey",
        "SUID" : 3057,
        "selected" : false
      },
      "position" : {
        "x" : -1201.9976801761409,
        "y" : -150.09388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3037",
        "shared_name" : "fullest",
        "name" : "fullest",
        "SUID" : 3037,
        "selected" : false
      },
      "position" : {
        "x" : -618.9024960096262,
        "y" : 88.03439296202487
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3032",
        "shared_name" : "farewell",
        "name" : "farewell",
        "SUID" : 3032,
        "selected" : false
      },
      "position" : {
        "x" : -512.3073118431116,
        "y" : -96.59388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3018",
        "shared_name" : "eastern",
        "name" : "eastern",
        "SUID" : 3018,
        "selected" : false
      },
      "position" : {
        "x" : -637.7491339394048,
        "y" : -184.34242809327588
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3010",
        "shared_name" : "deadly",
        "name" : "deadly",
        "SUID" : 3010,
        "selected" : false
      },
      "position" : {
        "x" : -637.749133939405,
        "y" : -8.845335619804246
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3005",
        "shared_name" : "darn",
        "name" : "darn",
        "SUID" : 3005,
        "selected" : false
      },
      "position" : {
        "x" : -832.0928643426554,
        "y" : 88.03439296202487
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2991",
        "shared_name" : "convenient",
        "name" : "convenient",
        "SUID" : 2991,
        "selected" : false
      },
      "position" : {
        "x" : -813.2462264128767,
        "y" : -184.34242809327588
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2986",
        "shared_name" : "common",
        "name" : "common",
        "SUID" : 2986,
        "selected" : false
      },
      "position" : {
        "x" : -601.4024960096262,
        "y" : -96.59388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2951",
        "shared_name" : "alive",
        "name" : "alive",
        "SUID" : 2951,
        "selected" : false
      },
      "position" : {
        "x" : 196.00231982385912,
        "y" : 624.9061181434599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2946",
        "shared_name" : "02x09_-_The_Hand_That_Connects_to_the_Future",
        "name" : "02x09_-_The_Hand_That_Connects_to_the_Future",
        "SUID" : 2946,
        "selected" : false
      },
      "position" : {
        "x" : -725.4976801761409,
        "y" : -96.59388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2935",
        "shared_name" : "unwarranted",
        "name" : "unwarranted",
        "SUID" : 2935,
        "selected" : false
      },
      "position" : {
        "x" : -1549.1115022857177,
        "y" : 601.3836289546352
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2927",
        "shared_name" : "unfamiliar",
        "name" : "unfamiliar",
        "SUID" : 2927,
        "selected" : false
      },
      "position" : {
        "x" : -1384.174840267853,
        "y" : 971.8374372117705
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2922",
        "shared_name" : "unexpected",
        "name" : "unexpected",
        "SUID" : 2922,
        "selected" : false
      },
      "position" : {
        "x" : -1614.575586937137,
        "y" : 901.1546643801958
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2905",
        "shared_name" : "sturdy",
        "name" : "sturdy",
        "SUID" : 2905,
        "selected" : false
      },
      "position" : {
        "x" : -1735.35868798491,
        "y" : 769.0813481972791
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2897",
        "shared_name" : "strange",
        "name" : "strange",
        "SUID" : 2897,
        "selected" : false
      },
      "position" : {
        "x" : -123.99768017614088,
        "y" : 726.9061181434599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2892",
        "shared_name" : "startling",
        "name" : "startling",
        "SUID" : 2892,
        "selected" : false
      },
      "position" : {
        "x" : -1549.1115022857175,
        "y" : 1025.4286073322846
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2881",
        "shared_name" : "similar",
        "name" : "similar",
        "SUID" : 2881,
        "selected" : false
      },
      "position" : {
        "x" : -1402.7318565338865,
        "y" : 813.4061181434599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2873",
        "shared_name" : "secluded",
        "name" : "secluded",
        "SUID" : 2873,
        "selected" : false
      },
      "position" : {
        "x" : -1699.3016717188764,
        "y" : 688.0959637065052
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2853",
        "shared_name" : "red",
        "name" : "red",
        "SUID" : 2853,
        "selected" : false
      },
      "position" : {
        "x" : -1526.827040700401,
        "y" : 689.3109339769453
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2848",
        "shared_name" : "reckless",
        "name" : "reckless",
        "SUID" : 2848,
        "selected" : false
      },
      "position" : {
        "x" : -74.99768017614088,
        "y" : 798.9061181434599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2840",
        "shared_name" : "proud",
        "name" : "proud",
        "SUID" : 2840,
        "selected" : false
      },
      "position" : {
        "x" : -1633.422224866916,
        "y" : 628.7778433248955
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2835",
        "shared_name" : "pretty",
        "name" : "pretty",
        "SUID" : 2835,
        "selected" : false
      },
      "position" : {
        "x" : -1313.6366723673718,
        "y" : 813.4061181434599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2824",
        "shared_name" : "poisonous",
        "name" : "poisonous",
        "SUID" : 2824,
        "selected" : false
      },
      "position" : {
        "x" : -1614.575586937137,
        "y" : 725.6575719067241
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2810",
        "shared_name" : "natural",
        "name" : "natural",
        "SUID" : 2810,
        "selected" : false
      },
      "position" : {
        "x" : -1735.3586879849097,
        "y" : 857.7308880896408
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2805",
        "shared_name" : "memorable",
        "name" : "memorable",
        "SUID" : 2805,
        "selected" : false
      },
      "position" : {
        "x" : -1384.174840267853,
        "y" : 654.9747990751498
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2779",
        "shared_name" : "inflatable",
        "name" : "inflatable",
        "SUID" : 2779,
        "selected" : false
      },
      "position" : {
        "x" : -1633.4222248669157,
        "y" : 998.0343929620249
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2771",
        "shared_name" : "horrible",
        "name" : "horrible",
        "SUID" : 2771,
        "selected" : false
      },
      "position" : {
        "x" : -1332.0679480966094,
        "y" : 900.1184528953295
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2766",
        "shared_name" : "herbal",
        "name" : "herbal",
        "SUID" : 2766,
        "selected" : false
      },
      "position" : {
        "x" : -1460.9475938484404,
        "y" : 1016.1622071579513
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2761",
        "shared_name" : "heavy",
        "name" : "heavy",
        "SUID" : 2761,
        "selected" : false
      },
      "position" : {
        "x" : -1650.9222248669157,
        "y" : 813.4061181434599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2747",
        "shared_name" : "grueling",
        "name" : "grueling",
        "SUID" : 2747,
        "selected" : false
      },
      "position" : {
        "x" : -1699.3016717188762,
        "y" : 938.7162725804146
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2742",
        "shared_name" : "green",
        "name" : "green",
        "SUID" : 2742,
        "selected" : false
      },
      "position" : {
        "x" : -1460.9475938484404,
        "y" : 610.6500291289685
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2725",
        "shared_name" : "fashioned",
        "name" : "fashioned",
        "SUID" : 2725,
        "selected" : false
      },
      "position" : {
        "x" : -1439.078494463665,
        "y" : 725.6575719067241
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2708",
        "shared_name" : "disgusting",
        "name" : "disgusting",
        "SUID" : 2708,
        "selected" : false
      },
      "position" : {
        "x" : -1332.0679480966091,
        "y" : 726.6937833915904
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2700",
        "shared_name" : "dazzling",
        "name" : "dazzling",
        "SUID" : 2700,
        "selected" : false
      },
      "position" : {
        "x" : -1526.827040700401,
        "y" : 937.5013023099746
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2695",
        "shared_name" : "crowded",
        "name" : "crowded",
        "SUID" : 2695,
        "selected" : false
      },
      "position" : {
        "x" : -855.9976801761409,
        "y" : 177.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2687",
        "shared_name" : "climactic",
        "name" : "climactic",
        "SUID" : 2687,
        "selected" : false
      },
      "position" : {
        "x" : -1439.078494463665,
        "y" : 901.1546643801958
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2682",
        "shared_name" : "clean",
        "name" : "clean",
        "SUID" : 2682,
        "selected" : false
      },
      "position" : {
        "x" : -29.997680176140875,
        "y" : 835.9061181434599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2677",
        "shared_name" : "carefree",
        "name" : "carefree",
        "SUID" : 2677,
        "selected" : false
      },
      "position" : {
        "x" : -1702.9976801761409,
        "y" : 9.906118143459935
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2654",
        "shared_name" : "02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "name" : "02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "SUID" : 2654,
        "selected" : false
      },
      "position" : {
        "x" : -1526.827040700401,
        "y" : 813.4061181434599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2646",
        "shared_name" : "yor",
        "name" : "yor",
        "SUID" : 2646,
        "selected" : false
      },
      "position" : {
        "x" : -813.0755649808498,
        "y" : 1437.9062839872759
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2638",
        "shared_name" : "useless",
        "name" : "useless",
        "SUID" : 2638,
        "selected" : false
      },
      "position" : {
        "x" : 467.0023198238591,
        "y" : 841.9061181434599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2633",
        "shared_name" : "upset",
        "name" : "upset",
        "SUID" : 2633,
        "selected" : false
      },
      "position" : {
        "x" : -573.5583603041846,
        "y" : 1738.2513588396541
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2628",
        "shared_name" : "unknown",
        "name" : "unknown",
        "SUID" : 2628,
        "selected" : false
      },
      "position" : {
        "x" : -713.9976801761409,
        "y" : 287.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2623",
        "shared_name" : "unidentified",
        "name" : "unidentified",
        "SUID" : 2623,
        "selected" : false
      },
      "position" : {
        "x" : -533.2491339394048,
        "y" : 1442.6575719067241
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2615",
        "shared_name" : "uncool",
        "name" : "uncool",
        "SUID" : 2615,
        "selected" : false
      },
      "position" : {
        "x" : -519.9976801761409,
        "y" : 651.9061181434599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2610",
        "shared_name" : "unable",
        "name" : "unable",
        "SUID" : 2610,
        "selected" : false
      },
      "position" : {
        "x" : -668.4370000480972,
        "y" : 1322.5608774472657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2605",
        "shared_name" : "troubling",
        "name" : "troubling",
        "SUID" : 2605,
        "selected" : false
      },
      "position" : {
        "x" : -407.80731184311185,
        "y" : 1530.40611814346
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2594",
        "shared_name" : "successful",
        "name" : "successful",
        "SUID" : 2594,
        "selected" : false
      },
      "position" : {
        "x" : -708.7462264128767,
        "y" : 1442.6575719067241
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2577",
        "shared_name" : "scary",
        "name" : "scary",
        "SUID" : 2577,
        "selected" : false
      },
      "position" : {
        "x" : -610.9976801761409,
        "y" : 817.9061181434599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2572",
        "shared_name" : "scared",
        "name" : "scared",
        "SUID" : 2572,
        "selected" : false
      },
      "position" : {
        "x" : -78.99768017614088,
        "y" : 1009.9061181434599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2567",
        "shared_name" : "satisfied",
        "name" : "satisfied",
        "SUID" : 2567,
        "selected" : false
      },
      "position" : {
        "x" : -924.9976801761409,
        "y" : 481.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2559",
        "shared_name" : "rebellious",
        "name" : "rebellious",
        "SUID" : 2559,
        "selected" : false
      },
      "position" : {
        "x" : -496.90249600962625,
        "y" : 1530.40611814346
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2548",
        "shared_name" : "pro",
        "name" : "pro",
        "SUID" : 2548,
        "selected" : false
      },
      "position" : {
        "x" : -753.9197006862914,
        "y" : 1363.7271764217421
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2540",
        "shared_name" : "pet",
        "name" : "pet",
        "SUID" : 2540,
        "selected" : false
      },
      "position" : {
        "x" : -428.919795371432,
        "y" : 1622.905952299644
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2529",
        "shared_name" : "overconfident",
        "name" : "overconfident",
        "SUID" : 2529,
        "selected" : false
      },
      "position" : {
        "x" : -620.9976801761409,
        "y" : 1406.3109339769453
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2512",
        "shared_name" : "obedient",
        "name" : "obedient",
        "SUID" : 2512,
        "selected" : false
      },
      "position" : {
        "x" : -488.0756596659901,
        "y" : 1363.7271764217426
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2495",
        "shared_name" : "loud",
        "name" : "loud",
        "SUID" : 2495,
        "selected" : false
      },
      "position" : {
        "x" : -793.9976801761409,
        "y" : 378.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2484",
        "shared_name" : "likely",
        "name" : "likely",
        "SUID" : 2484,
        "selected" : false
      },
      "position" : {
        "x" : -1243.9976801761409,
        "y" : 1717.90611814346
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2479",
        "shared_name" : "invisible",
        "name" : "invisible",
        "SUID" : 2479,
        "selected" : false
      },
      "position" : {
        "x" : -428.91979537143175,
        "y" : 1437.9062839872759
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2474",
        "shared_name" : "intermediate",
        "name" : "intermediate",
        "SUID" : 2474,
        "selected" : false
      },
      "position" : {
        "x" : -488.0756596659901,
        "y" : 1697.0850598651768
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2460",
        "shared_name" : "heroic",
        "name" : "heroic",
        "SUID" : 2460,
        "selected" : false
      },
      "position" : {
        "x" : -753.9197006862917,
        "y" : 1697.0850598651768
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2455",
        "shared_name" : "headed",
        "name" : "headed",
        "SUID" : 2455,
        "selected" : false
      },
      "position" : {
        "x" : -834.18804850917,
        "y" : 1530.40611814346
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2435",
        "shared_name" : "flawless",
        "name" : "flawless",
        "SUID" : 2435,
        "selected" : false
      },
      "position" : {
        "x" : -745.0928643426555,
        "y" : 1530.40611814346
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2430",
        "shared_name" : "flashy",
        "name" : "flashy",
        "SUID" : 2430,
        "selected" : false
      },
      "position" : {
        "x" : -533.249133939405,
        "y" : 1618.1546643801958
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2425",
        "shared_name" : "fit",
        "name" : "fit",
        "SUID" : 2425,
        "selected" : false
      },
      "position" : {
        "x" : -813.0755649808499,
        "y" : 1622.905952299644
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2417",
        "shared_name" : "fatal",
        "name" : "fatal",
        "SUID" : 2417,
        "selected" : false
      },
      "position" : {
        "x" : -573.5583603041844,
        "y" : 1322.5608774472657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2409",
        "shared_name" : "evil",
        "name" : "evil",
        "SUID" : 2409,
        "selected" : false
      },
      "position" : {
        "x" : -668.4370000480972,
        "y" : 1738.2513588396541
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2404",
        "shared_name" : "dummy",
        "name" : "dummy",
        "SUID" : 2404,
        "selected" : false
      },
      "position" : {
        "x" : -708.7462264128767,
        "y" : 1618.1546643801958
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2390",
        "shared_name" : "crazy",
        "name" : "crazy",
        "SUID" : 2390,
        "selected" : false
      },
      "position" : {
        "x" : -21.997680176140875,
        "y" : 493.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2355",
        "shared_name" : "asleep",
        "name" : "asleep",
        "SUID" : 2355,
        "selected" : false
      },
      "position" : {
        "x" : 269.0023198238591,
        "y" : 507.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2344",
        "shared_name" : "afraid",
        "name" : "afraid",
        "SUID" : 2344,
        "selected" : false
      },
      "position" : {
        "x" : -620.9976801761409,
        "y" : 1654.5013023099746
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2339",
        "shared_name" : "02x07_-_Who_Is_This_Mission_For_",
        "name" : "02x07_-_Who_Is_This_Mission_For_",
        "SUID" : 2339,
        "selected" : false
      },
      "position" : {
        "x" : -620.9976801761409,
        "y" : 1530.40611814346
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2331",
        "shared_name" : "wooden",
        "name" : "wooden",
        "SUID" : 2331,
        "selected" : false
      },
      "position" : {
        "x" : 677.8119514908299,
        "y" : -316.59388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2326",
        "shared_name" : "unstable",
        "name" : "unstable",
        "SUID" : 2326,
        "selected" : false
      },
      "position" : {
        "x" : 1023.9243403340101,
        "y" : -483.27282357825743
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2321",
        "shared_name" : "unnecessary",
        "name" : "unnecessary",
        "SUID" : 2321,
        "selected" : false
      },
      "position" : {
        "x" : -231.99768017614088,
        "y" : 515.9061181434599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2316",
        "shared_name" : "unfair",
        "name" : "unfair",
        "SUID" : 2316,
        "selected" : false
      },
      "position" : {
        "x" : 69.00231982385912,
        "y" : 221.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2302",
        "shared_name" : "stern",
        "name" : "stern",
        "SUID" : 2302,
        "selected" : false
      },
      "position" : {
        "x" : 978.750866060595,
        "y" : -228.84533561980425
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2297",
        "shared_name" : "squid",
        "name" : "squid",
        "SUID" : 2297,
        "selected" : false
      },
      "position" : {
        "x" : 843.5629999519028,
        "y" : -524.4391225527343
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2271",
        "shared_name" : "psychotic",
        "name" : "psychotic",
        "SUID" : 2271,
        "selected" : false
      },
      "position" : {
        "x" : 1015.0975039903738,
        "y" : -316.59388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2266",
        "shared_name" : "private",
        "name" : "private",
        "SUID" : 2266,
        "selected" : false
      },
      "position" : {
        "x" : 758.0802993137086,
        "y" : -483.27282357825766
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2261",
        "shared_name" : "precious",
        "name" : "precious",
        "SUID" : 2261,
        "selected" : false
      },
      "position" : {
        "x" : 1083.0802046285685,
        "y" : -409.09371601272414
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2256",
        "shared_name" : "popular",
        "name" : "popular",
        "SUID" : 2256,
        "selected" : false
      },
      "position" : {
        "x" : -31.997680176140875,
        "y" : 631.9061181434599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2245",
        "shared_name" : "overwhelming",
        "name" : "overwhelming",
        "SUID" : 2245,
        "selected" : false
      },
      "position" : {
        "x" : 803.2537735871233,
        "y" : -404.3424280932759
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2237",
        "shared_name" : "optimal",
        "name" : "optimal",
        "SUID" : 2237,
        "selected" : false
      },
      "position" : {
        "x" : 758.0802993137081,
        "y" : -149.9149401348227
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2223",
        "shared_name" : "nervous",
        "name" : "nervous",
        "SUID" : 2223,
        "selected" : false
      },
      "position" : {
        "x" : 938.4416396958154,
        "y" : -108.74864116034587
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2218",
        "shared_name" : "mental",
        "name" : "mental",
        "SUID" : 2218,
        "selected" : false
      },
      "position" : {
        "x" : 803.2537735871233,
        "y" : -228.84533561980425
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2204",
        "shared_name" : "low",
        "name" : "low",
        "SUID" : 2204,
        "selected" : false
      },
      "position" : {
        "x" : 315.0023198238591,
        "y" : 400.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2199",
        "shared_name" : "lonesome",
        "name" : "lonesome",
        "SUID" : 2199,
        "selected" : false
      },
      "position" : {
        "x" : 938.4416396958154,
        "y" : -524.439122552734
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2194",
        "shared_name" : "lonely",
        "name" : "lonely",
        "SUID" : 2194,
        "selected" : false
      },
      "position" : {
        "x" : 306.0023198238591,
        "y" : 869.9061181434599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2189",
        "shared_name" : "local",
        "name" : "local",
        "SUID" : 2189,
        "selected" : false
      },
      "position" : {
        "x" : 843.5629999519028,
        "y" : -108.74864116034587
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2172",
        "shared_name" : "impatient",
        "name" : "impatient",
        "SUID" : 2172,
        "selected" : false
      },
      "position" : {
        "x" : 698.9244350191502,
        "y" : -224.094047700356
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2161",
        "shared_name" : "haired",
        "name" : "haired",
        "SUID" : 2161,
        "selected" : false
      },
      "position" : {
        "x" : -234.99768017614088,
        "y" : 371.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2147",
        "shared_name" : "fitting",
        "name" : "fitting",
        "SUID" : 2147,
        "selected" : false
      },
      "position" : {
        "x" : 978.750866060595,
        "y" : -404.3424280932759
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2133",
        "shared_name" : "extravagant",
        "name" : "extravagant",
        "SUID" : 2133,
        "selected" : false
      },
      "position" : {
        "x" : 1104.1926881568884,
        "y" : -316.59388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2107",
        "shared_name" : "damn",
        "name" : "damn",
        "SUID" : 2107,
        "selected" : false
      },
      "position" : {
        "x" : 698.9244350191502,
        "y" : -409.09371601272414
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2102",
        "shared_name" : "cute",
        "name" : "cute",
        "SUID" : 2102,
        "selected" : false
      },
      "position" : {
        "x" : 459.0023198238591,
        "y" : 882.9061181434599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2097",
        "shared_name" : "crucial",
        "name" : "crucial",
        "SUID" : 2097,
        "selected" : false
      },
      "position" : {
        "x" : 1023.9243403340101,
        "y" : -149.9149401348227
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2089",
        "shared_name" : "constant",
        "name" : "constant",
        "SUID" : 2089,
        "selected" : false
      },
      "position" : {
        "x" : 766.9071356573445,
        "y" : -316.59388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2084",
        "shared_name" : "complete",
        "name" : "complete",
        "SUID" : 2084,
        "selected" : false
      },
      "position" : {
        "x" : 891.0023198238591,
        "y" : -440.6890660230547
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2079",
        "shared_name" : "clumsy",
        "name" : "clumsy",
        "SUID" : 2079,
        "selected" : false
      },
      "position" : {
        "x" : -145.99768017614088,
        "y" : -409.09388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2071",
        "shared_name" : "cheerful",
        "name" : "cheerful",
        "SUID" : 2071,
        "selected" : false
      },
      "position" : {
        "x" : 223.00231982385912,
        "y" : 708.9061181434599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2066",
        "shared_name" : "boorish",
        "name" : "boorish",
        "SUID" : 2066,
        "selected" : false
      },
      "position" : {
        "x" : 1083.080204628568,
        "y" : -224.094047700356
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2061",
        "shared_name" : "blonde",
        "name" : "blonde",
        "SUID" : 2061,
        "selected" : false
      },
      "position" : {
        "x" : 891.0023198238591,
        "y" : -192.49869769002544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2056",
        "shared_name" : "blind",
        "name" : "blind",
        "SUID" : 2056,
        "selected" : false
      },
      "position" : {
        "x" : -197.99768017614088,
        "y" : 631.9061181434599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2051",
        "shared_name" : "black",
        "name" : "black",
        "SUID" : 2051,
        "selected" : false
      },
      "position" : {
        "x" : -104.99768017614088,
        "y" : 539.9061181434599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2037",
        "shared_name" : "02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "name" : "02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "SUID" : 2037,
        "selected" : false
      },
      "position" : {
        "x" : 891.0023198238591,
        "y" : -316.59388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2020",
        "shared_name" : "vibrant",
        "name" : "vibrant",
        "SUID" : 2020,
        "selected" : false
      },
      "position" : {
        "x" : 190.53949553364168,
        "y" : -1824.66256278823
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2012",
        "shared_name" : "unnoticed",
        "name" : "unnoticed",
        "SUID" : 2012,
        "selected" : false
      },
      "position" : {
        "x" : 100.37863042768049,
        "y" : -1685.400726131411
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2001",
        "shared_name" : "thin",
        "name" : "thin",
        "SUID" : 2001,
        "selected" : false
      },
      "position" : {
        "x" : 587.0023198238591,
        "y" : -293.09388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1984",
        "shared_name" : "sixth",
        "name" : "sixth",
        "SUID" : 1984,
        "selected" : false
      },
      "position" : {
        "x" : -76.20788906542111,
        "y" : -1983.0938818565403
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1979",
        "shared_name" : "short",
        "name" : "short",
        "SUID" : 1979,
        "selected" : false
      },
      "position" : {
        "x" : -103.25548114867843,
        "y" : -1721.306914194921
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1974",
        "shared_name" : "seventh",
        "name" : "seventh",
        "SUID" : 1974,
        "selected" : false
      },
      "position" : {
        "x" : 279.45146282851965,
        "y" : -2177.399289590496
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1969",
        "shared_name" : "scrubby",
        "name" : "scrubby",
        "SUID" : 1969,
        "selected" : false
      },
      "position" : {
        "x" : -58.707889065421114,
        "y" : -1798.4656070379756
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1955",
        "shared_name" : "relaxing",
        "name" : "relaxing",
        "SUID" : 1955,
        "selected" : false
      },
      "position" : {
        "x" : 25.602833515777093,
        "y" : -1771.0713926677158
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1950",
        "shared_name" : "recent",
        "name" : "recent",
        "SUID" : 1950,
        "selected" : false
      },
      "position" : {
        "x" : 47.887295101093514,
        "y" : -2107.1890660230547
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1945",
        "shared_name" : "reassuring",
        "name" : "reassuring",
        "SUID" : 1945,
        "selected" : false
      },
      "position" : {
        "x" : -236.16820795291892,
        "y" : -2086.4816298477135
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1934",
        "shared_name" : "proper",
        "name" : "proper",
        "SUID" : 1934,
        "selected" : false
      },
      "position" : {
        "x" : -160.64435218341532,
        "y" : -2027.4186518027211
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1926",
        "shared_name" : "political",
        "name" : "political",
        "SUID" : 1926,
        "selected" : false
      },
      "position" : {
        "x" : 261.07766343412277,
        "y" : -1983.0938818565403
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1921",
        "shared_name" : "picky",
        "name" : "picky",
        "SUID" : 1921,
        "selected" : false
      },
      "position" : {
        "x" : -39.861251135642306,
        "y" : -1895.3453356198045
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1916",
        "shared_name" : "outside",
        "name" : "outside",
        "SUID" : 1916,
        "selected" : false
      },
      "position" : {
        "x" : 789.0023198238591,
        "y" : -591.0938818565401
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1902",
        "shared_name" : "offshore",
        "name" : "offshore",
        "SUID" : 1902,
        "selected" : false
      },
      "position" : {
        "x" : -124.58733591738178,
        "y" : -2108.4040362934948
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1897",
        "shared_name" : "numerous",
        "name" : "numerous",
        "SUID" : 1897,
        "selected" : false
      },
      "position" : {
        "x" : -117.99768017614088,
        "y" : -525.0938818565401
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1886",
        "shared_name" : "meticulous",
        "name" : "meticulous",
        "SUID" : 1886,
        "selected" : false
      },
      "position" : {
        "x" : 135.63584133782956,
        "y" : -2070.842428093276
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1881",
        "shared_name" : "mega",
        "name" : "mega",
        "SUID" : 1881,
        "selected" : false
      },
      "position" : {
        "x" : -103.25548114867797,
        "y" : -2244.88084951816
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1876",
        "shared_name" : "main",
        "name" : "main",
        "SUID" : 1876,
        "selected" : false
      },
      "position" : {
        "x" : -265.9976801761409,
        "y" : -78.09388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1871",
        "shared_name" : "luxurious",
        "name" : "luxurious",
        "SUID" : 1871,
        "selected" : false
      },
      "position" : {
        "x" : -160.64435218341532,
        "y" : -1938.7691119103592
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1860",
        "shared_name" : "large",
        "name" : "large",
        "SUID" : 1860,
        "selected" : false
      },
      "position" : {
        "x" : -672.9976801761409,
        "y" : -1631.09388185654
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1855",
        "shared_name" : "internal",
        "name" : "internal",
        "SUID" : 1855,
        "selected" : false
      },
      "position" : {
        "x" : -39.861251135642306,
        "y" : -2070.8424280932763
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1850",
        "shared_name" : "interested",
        "name" : "interested",
        "SUID" : 1850,
        "selected" : false
      },
      "position" : {
        "x" : -236.16820795291915,
        "y" : -1879.7061338653677
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1845",
        "shared_name" : "indebted",
        "name" : "indebted",
        "SUID" : 1845,
        "selected" : false
      },
      "position" : {
        "x" : 279.4514628285192,
        "y" : -1788.7884741225837
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1837",
        "shared_name" : "huge",
        "name" : "huge",
        "SUID" : 1837,
        "selected" : false
      },
      "position" : {
        "x" : -16.997680176140875,
        "y" : 385.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1832",
        "shared_name" : "honorable",
        "name" : "honorable",
        "SUID" : 1832,
        "selected" : false
      },
      "position" : {
        "x" : 242.64638770488546,
        "y" : -2069.80621660841
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1827",
        "shared_name" : "honest",
        "name" : "honest",
        "SUID" : 1827,
        "selected" : false
      },
      "position" : {
        "x" : 47.887295101093514,
        "y" : -1858.998697690026
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1822",
        "shared_name" : "hidden",
        "name" : "hidden",
        "SUID" : 1822,
        "selected" : false
      },
      "position" : {
        "x" : 171.98247926760814,
        "y" : -1983.0938818565403
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1811",
        "shared_name" : "grand",
        "name" : "grand",
        "SUID" : 1811,
        "selected" : false
      },
      "position" : {
        "x" : 266.0023198238591,
        "y" : -356.09388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1803",
        "shared_name" : "funny",
        "name" : "funny",
        "SUID" : 1803,
        "selected" : false
      },
      "position" : {
        "x" : 113.76674195305395,
        "y" : -2185.8499708710315
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1798",
        "shared_name" : "friendly",
        "name" : "friendly",
        "SUID" : 1798,
        "selected" : false
      },
      "position" : {
        "x" : 242.64638770488523,
        "y" : -1896.3815471046707
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1790",
        "shared_name" : "frail",
        "name" : "frail",
        "SUID" : 1790,
        "selected" : false
      },
      "position" : {
        "x" : 135.63584133782933,
        "y" : -1895.3453356198045
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1785",
        "shared_name" : "foreign",
        "name" : "foreign",
        "SUID" : 1785,
        "selected" : false
      },
      "position" : {
        "x" : -649.9976801761409,
        "y" : -392.09388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1777",
        "shared_name" : "fearsome",
        "name" : "fearsome",
        "SUID" : 1777,
        "selected" : false
      },
      "position" : {
        "x" : 581.0023198238591,
        "y" : -571.0938818565401
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1769",
        "shared_name" : "fair",
        "name" : "fair",
        "SUID" : 1769,
        "selected" : false
      },
      "position" : {
        "x" : 190.53949553364168,
        "y" : -2141.5252009248507
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1761",
        "shared_name" : "difficult",
        "name" : "difficult",
        "SUID" : 1761,
        "selected" : false
      },
      "position" : {
        "x" : 60.002319823859125,
        "y" : 403.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1753",
        "shared_name" : "dependent",
        "name" : "dependent",
        "SUID" : 1753,
        "selected" : false
      },
      "position" : {
        "x" : 100.37863042768117,
        "y" : -2280.7870375816697
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1742",
        "shared_name" : "concerned",
        "name" : "concerned",
        "SUID" : 1742,
        "selected" : false
      },
      "position" : {
        "x" : -58.70788906542134,
        "y" : -2167.722156675105
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1734",
        "shared_name" : "clear",
        "name" : "clear",
        "SUID" : 1734,
        "selected" : false
      },
      "position" : {
        "x" : -183.42582543832236,
        "y" : -62.15999328040789
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1723",
        "shared_name" : "calm",
        "name" : "calm",
        "SUID" : 1723,
        "selected" : false
      },
      "position" : {
        "x" : -348.5695349139594,
        "y" : -94.02777043267224
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1718",
        "shared_name" : "brave",
        "name" : "brave",
        "SUID" : 1718,
        "selected" : false
      },
      "position" : {
        "x" : 350.17284760063694,
        "y" : -1983.0938818565403
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1713",
        "shared_name" : "bogus",
        "name" : "bogus",
        "SUID" : 1713,
        "selected" : false
      },
      "position" : {
        "x" : -124.58733591738155,
        "y" : -1857.7837274195856
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1708",
        "shared_name" : "blank",
        "name" : "blank",
        "SUID" : 1708,
        "selected" : false
      },
      "position" : {
        "x" : 25.602833515776865,
        "y" : -2195.1163710453648
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1700",
        "shared_name" : "biannual",
        "name" : "biannual",
        "SUID" : 1700,
        "selected" : false
      },
      "position" : {
        "x" : 113.76674195305418,
        "y" : -1780.337792842049
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1677",
        "shared_name" : "02x05_-_Plan_to_Cross_the_Border",
        "name" : "02x05_-_Plan_to_Cross_the_Border",
        "SUID" : 1677,
        "selected" : false
      },
      "position" : {
        "x" : 47.887295101093514,
        "y" : -1983.0938818565403
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1672",
        "shared_name" : "worth",
        "name" : "worth",
        "SUID" : 1672,
        "selected" : false
      },
      "position" : {
        "x" : 382.0023198238591,
        "y" : -136.09388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1661",
        "shared_name" : "urban",
        "name" : "urban",
        "SUID" : 1661,
        "selected" : false
      },
      "position" : {
        "x" : -137.99768017614088,
        "y" : -2500.09388185654
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1656",
        "shared_name" : "unofficial",
        "name" : "unofficial",
        "SUID" : 1656,
        "selected" : false
      },
      "position" : {
        "x" : 174.00643881617134,
        "y" : -1507.4302434959257
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1651",
        "shared_name" : "ultimate",
        "name" : "ultimate",
        "SUID" : 1651,
        "selected" : false
      },
      "position" : {
        "x" : -186.94015143500246,
        "y" : -1396.4040362934948
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1631",
        "shared_name" : "strong",
        "name" : "strong",
        "SUID" : 1631,
        "selected" : false
      },
      "position" : {
        "x" : -114.99768017614088,
        "y" : -372.09388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1620",
        "shared_name" : "soft",
        "name" : "soft",
        "SUID" : 1620,
        "selected" : false
      },
      "position" : {
        "x" : -222.99716770103578,
        "y" : -1315.418651802721
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1615",
        "shared_name" : "smart",
        "name" : "smart",
        "SUID" : 1615,
        "selected" : false
      },
      "position" : {
        "x" : 128.186680016021,
        "y" : -1429.5252009248504
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1607",
        "shared_name" : "separate",
        "name" : "separate",
        "SUID" : 1607,
        "selected" : false
      },
      "position" : {
        "x" : -36.74998200184359,
        "y" : -1059.0713926677156
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1602",
        "shared_name" : "sarcastic",
        "name" : "sarcastic",
        "SUID" : 1602,
        "selected" : false
      },
      "position" : {
        "x" : -102.21406665326299,
        "y" : -1358.842428093276
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1591",
        "shared_name" : "rude",
        "name" : "rude",
        "SUID" : 1591,
        "selected" : false
      },
      "position" : {
        "x" : -121.06070458304157,
        "y" : -1086.4656070379754
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1586",
        "shared_name" : "royal",
        "name" : "royal",
        "SUID" : 1586,
        "selected" : false
      },
      "position" : {
        "x" : -36.74998200184382,
        "y" : -1483.1163710453645
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1575",
        "shared_name" : "rich",
        "name" : "rich",
        "SUID" : 1575,
        "selected" : false
      },
      "position" : {
        "x" : -175.99768017614088,
        "y" : -280.09388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1570",
        "shared_name" : "physical",
        "name" : "physical",
        "SUID" : 1570,
        "selected" : false
      },
      "position" : {
        "x" : -14.465520416526942,
        "y" : -1395.1890660230547
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1565",
        "shared_name" : "phenomenal",
        "name" : "phenomenal",
        "SUID" : 1565,
        "selected" : false
      },
      "position" : {
        "x" : 174.00643881617134,
        "y" : -1034.7575202171543
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1560",
        "shared_name" : "phantom",
        "name" : "phantom",
        "SUID" : 1560,
        "selected" : false
      },
      "position" : {
        "x" : 287.8200320830165,
        "y" : -1271.09388185654
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1555",
        "shared_name" : "paramilitary",
        "name" : "paramilitary",
        "SUID" : 1555,
        "selected" : false
      },
      "position" : {
        "x" : -121.0607045830418,
        "y" : -1455.7221566751045
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1547",
        "shared_name" : "open",
        "name" : "open",
        "SUID" : 1547,
        "selected" : false
      },
      "position" : {
        "x" : -295.9976801761409,
        "y" : 186.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1527",
        "shared_name" : "military",
        "name" : "military",
        "SUID" : 1527,
        "selected" : false
      },
      "position" : {
        "x" : 597.0023198238591,
        "y" : -219.09388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1519",
        "shared_name" : "lucky",
        "name" : "lucky",
        "SUID" : 1519,
        "selected" : false
      },
      "position" : {
        "x" : -17.997680176140875,
        "y" : -615.0938818565401
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1511",
        "shared_name" : "lost",
        "name" : "lost",
        "SUID" : 1511,
        "selected" : false
      },
      "position" : {
        "x" : -14.465520416526942,
        "y" : -1146.9986976900254
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1500",
        "shared_name" : "limited",
        "name" : "limited",
        "SUID" : 1500,
        "selected" : false
      },
      "position" : {
        "x" : -81.7303838802261,
        "y" : -976.387259275431
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1495",
        "shared_name" : "legendary",
        "name" : "legendary",
        "SUID" : 1495,
        "selected" : false
      },
      "position" : {
        "x" : -894.9976801761409,
        "y" : -1772.09388185654
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1484",
        "shared_name" : "laborious",
        "name" : "laborious",
        "SUID" : 1484,
        "selected" : false
      },
      "position" : {
        "x" : 180.29357218726477,
        "y" : -1357.8062166084096
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1479",
        "shared_name" : "idiot",
        "name" : "idiot",
        "SUID" : 1479,
        "selected" : false
      },
      "position" : {
        "x" : 284.0023198238591,
        "y" : 249.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1474",
        "shared_name" : "identical",
        "name" : "identical",
        "SUID" : 1474,
        "selected" : false
      },
      "position" : {
        "x" : 73.28302582020888,
        "y" : -1358.8424280932759
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1466",
        "shared_name" : "hearted",
        "name" : "hearted",
        "SUID" : 1466,
        "selected" : false
      },
      "position" : {
        "x" : -286.81539243529824,
        "y" : -1402.250667656259
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1452",
        "shared_name" : "gray",
        "name" : "gray",
        "SUID" : 1452,
        "selected" : false
      },
      "position" : {
        "x" : 198.72484791650209,
        "y" : -1271.09388185654
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1441",
        "shared_name" : "free",
        "name" : "free",
        "SUID" : 1441,
        "selected" : false
      },
      "position" : {
        "x" : 346.0023198238591,
        "y" : -2474.09388185654
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1430",
        "shared_name" : "favorite",
        "name" : "favorite",
        "SUID" : 1430,
        "selected" : false
      },
      "position" : {
        "x" : -222.99716770103578,
        "y" : -1226.769111910359
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1419",
        "shared_name" : "exquisite",
        "name" : "exquisite",
        "SUID" : 1419,
        "selected" : false
      },
      "position" : {
        "x" : 128.186680016021,
        "y" : -1112.6625627882297
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1411",
        "shared_name" : "excited",
        "name" : "excited",
        "SUID" : 1411,
        "selected" : false
      },
      "position" : {
        "x" : 129.00231982385912,
        "y" : -640.0938818565401
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1406",
        "shared_name" : "entire",
        "name" : "entire",
        "SUID" : 1406,
        "selected" : false
      },
      "position" : {
        "x" : 156.00231982385912,
        "y" : -528.0938818565401
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1401",
        "shared_name" : "embarrassing",
        "name" : "embarrassing",
        "SUID" : 1401,
        "selected" : false
      },
      "position" : {
        "x" : -81.73038388022587,
        "y" : -1565.8005044376491
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1393",
        "shared_name" : "dumb",
        "name" : "dumb",
        "SUID" : 1393,
        "selected" : false
      },
      "position" : {
        "x" : 51.413926435433495,
        "y" : -1473.8499708710315
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1388",
        "shared_name" : "dirty",
        "name" : "dirty",
        "SUID" : 1388,
        "selected" : false
      },
      "position" : {
        "x" : -374.9976801761409,
        "y" : -627.0938818565401
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1383",
        "shared_name" : "desperate",
        "name" : "desperate",
        "SUID" : 1383,
        "selected" : false
      },
      "position" : {
        "x" : -102.21406665326299,
        "y" : -1183.3453356198042
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1375",
        "shared_name" : "decent",
        "name" : "decent",
        "SUID" : 1375,
        "selected" : false
      },
      "position" : {
        "x" : 73.28302582020888,
        "y" : -1183.3453356198042
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1361",
        "shared_name" : "close",
        "name" : "close",
        "SUID" : 1361,
        "selected" : false
      },
      "position" : {
        "x" : 241.00231982385912,
        "y" : 212.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1356",
        "shared_name" : "classical",
        "name" : "classical",
        "SUID" : 1356,
        "selected" : false
      },
      "position" : {
        "x" : 180.29357218726454,
        "y" : -1184.3815471046705
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1348",
        "shared_name" : "cautious",
        "name" : "cautious",
        "SUID" : 1348,
        "selected" : false
      },
      "position" : {
        "x" : -138.56070458304157,
        "y" : -1271.09388185654
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1340",
        "shared_name" : "broad",
        "name" : "broad",
        "SUID" : 1340,
        "selected" : false
      },
      "position" : {
        "x" : 858.0023198238591,
        "y" : -1605.09388185654
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1335",
        "shared_name" : "bleak",
        "name" : "bleak",
        "SUID" : 1335,
        "selected" : false
      },
      "position" : {
        "x" : -186.94015143500224,
        "y" : -1145.7837274195854
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1321",
        "shared_name" : "annoying",
        "name" : "annoying",
        "SUID" : 1321,
        "selected" : false
      },
      "position" : {
        "x" : 51.413926435433495,
        "y" : -1068.3377928420487
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1313",
        "shared_name" : "adamant",
        "name" : "adamant",
        "SUID" : 1313,
        "selected" : false
      },
      "position" : {
        "x" : 109.62966374998746,
        "y" : -1271.09388185654
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1308",
        "shared_name" : "02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "name" : "02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "SUID" : 1308,
        "selected" : false
      },
      "position" : {
        "x" : -14.465520416526942,
        "y" : -1271.09388185654
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1306",
        "shared_name" : "academic",
        "name" : "academic",
        "SUID" : 1306,
        "selected" : false
      },
      "position" : {
        "x" : -286.81539243529824,
        "y" : -1139.9370960568212
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1298",
        "shared_name" : "worthwhile",
        "name" : "worthwhile",
        "SUID" : 1298,
        "selected" : false
      },
      "position" : {
        "x" : 652.784791231817,
        "y" : 549.0343929620249
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1290",
        "shared_name" : "vulgar",
        "name" : "vulgar",
        "SUID" : 1290,
        "selected" : false
      },
      "position" : {
        "x" : 586.9053443798562,
        "y" : 239.09596370650524
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1285",
        "shared_name" : "usual",
        "name" : "usual",
        "SUID" : 1285,
        "selected" : false
      },
      "position" : {
        "x" : 737.0955138130153,
        "y" : 576.4286073322846
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1280",
        "shared_name" : "unpaid",
        "name" : "unpaid",
        "SUID" : 1280,
        "selected" : false
      },
      "position" : {
        "x" : 671.6314291615959,
        "y" : 276.6575719067241
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1275",
        "shared_name" : "underground",
        "name" : "underground",
        "SUID" : 1275,
        "selected" : false
      },
      "position" : {
        "x" : 144.00231982385912,
        "y" : 661.9061181434599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1270",
        "shared_name" : "tough",
        "name" : "tough",
        "SUID" : 1270,
        "selected" : false
      },
      "position" : {
        "x" : 697.0023198238591,
        "y" : -23.093881856540065
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1265",
        "shared_name" : "thorough",
        "name" : "thorough",
        "SUID" : 1265,
        "selected" : false
      },
      "position" : {
        "x" : -179.99768017614088,
        "y" : 453.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1260",
        "shared_name" : "suspicious",
        "name" : "suspicious",
        "SUID" : 1260,
        "selected" : false
      },
      "position" : {
        "x" : -215.99768017614088,
        "y" : 334.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1252",
        "shared_name" : "sudden",
        "name" : "sudden",
        "SUID" : 1252,
        "selected" : false
      },
      "position" : {
        "x" : 157.00231982385912,
        "y" : 578.9061181434599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1247",
        "shared_name" : "subject",
        "name" : "subject",
        "SUID" : 1247,
        "selected" : false
      },
      "position" : {
        "x" : 883.4751595648463,
        "y" : 364.40611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1242",
        "shared_name" : "stupid",
        "name" : "stupid",
        "SUID" : 1242,
        "selected" : false
      },
      "position" : {
        "x" : 307.82824362207293,
        "y" : -551.4636964121096
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1237",
        "shared_name" : "stingy",
        "name" : "stingy",
        "SUID" : 1237,
        "selected" : false
      },
      "position" : {
        "x" : 1013.6787643623984,
        "y" : 200.9782099350905
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1232",
        "shared_name" : "sophisticated",
        "name" : "sophisticated",
        "SUID" : 1232,
        "selected" : false
      },
      "position" : {
        "x" : 586.9053443798562,
        "y" : 489.7162725804146
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1224",
        "shared_name" : "silver",
        "name" : "silver",
        "SUID" : 1224,
        "selected" : false
      },
      "position" : {
        "x" : 737.0955138130148,
        "y" : 152.3836289546357
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1216",
        "shared_name" : "shiny",
        "name" : "shiny",
        "SUID" : 1216,
        "selected" : false
      },
      "position" : {
        "x" : 759.3799753983317,
        "y" : 240.3109339769453
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1211",
        "shared_name" : "set",
        "name" : "set",
        "SUID" : 1211,
        "selected" : false
      },
      "position" : {
        "x" : 469.33911174984314,
        "y" : 449.56979974538035
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1200",
        "shared_name" : "ridiculous",
        "name" : "ridiculous",
        "SUID" : 1200,
        "selected" : false
      },
      "position" : {
        "x" : 384.0023198238591,
        "y" : -587.0938818565401
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1195",
        "shared_name" : "rid",
        "name" : "rid",
        "SUID" : 1195,
        "selected" : false
      },
      "position" : {
        "x" : -476.9976801761409,
        "y" : 556.9061181434599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1190",
        "shared_name" : "relieved",
        "name" : "relieved",
        "SUID" : 1190,
        "selected" : false
      },
      "position" : {
        "x" : 972.5703437313609,
        "y" : 364.40611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1185",
        "shared_name" : "real",
        "name" : "real",
        "SUID" : 1185,
        "selected" : false
      },
      "position" : {
        "x" : 587.0023198238591,
        "y" : -256.09388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1177",
        "shared_name" : "public",
        "name" : "public",
        "SUID" : 1177,
        "selected" : false
      },
      "position" : {
        "x" : 208.00231982385912,
        "y" : -313.09388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1172",
        "shared_name" : "polar",
        "name" : "polar",
        "SUID" : 1172,
        "selected" : false
      },
      "position" : {
        "x" : 884.9539321202119,
        "y" : 639.3747284304627
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1164",
        "shared_name" : "past",
        "name" : "past",
        "SUID" : 1164,
        "selected" : false
      },
      "position" : {
        "x" : 550.8483281138228,
        "y" : 320.0813481972791
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1156",
        "shared_name" : "old",
        "name" : "old",
        "SUID" : 1156,
        "selected" : false
      },
      "position" : {
        "x" : -430.9976801761409,
        "y" : -107.09388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1148",
        "shared_name" : "notable",
        "name" : "notable",
        "SUID" : 1148,
        "selected" : false
      },
      "position" : {
        "x" : 716.360255882008,
        "y" : 663.614839578333
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1140",
        "shared_name" : "necessary",
        "name" : "necessary",
        "SUID" : 1140,
        "selected" : false
      },
      "position" : {
        "x" : 900.0023198238591,
        "y" : -5.093881856540065
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1135",
        "shared_name" : "mysterious",
        "name" : "mysterious",
        "SUID" : 1135,
        "selected" : false
      },
      "position" : {
        "x" : 460.17639602564486,
        "y" : -622.7240673009705
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1130",
        "shared_name" : "miserable",
        "name" : "miserable",
        "SUID" : 1130,
        "selected" : false
      },
      "position" : {
        "x" : 652.784791231817,
        "y" : 179.77784332489546
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1125",
        "shared_name" : "mere",
        "name" : "mere",
        "SUID" : 1125,
        "selected" : false
      },
      "position" : {
        "x" : 759.3799753983317,
        "y" : 488.50130230997456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1120",
        "shared_name" : "lovey",
        "name" : "lovey",
        "SUID" : 1120,
        "selected" : false
      },
      "position" : {
        "x" : 847.1285216350675,
        "y" : 276.6575719067241
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1115",
        "shared_name" : "lovely",
        "name" : "lovely",
        "SUID" : 1115,
        "selected" : false
      },
      "position" : {
        "x" : 54.002319823859125,
        "y" : -486.09388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1104",
        "shared_name" : "kind",
        "name" : "kind",
        "SUID" : 1104,
        "selected" : false
      },
      "position" : {
        "x" : -337.9976801761409,
        "y" : 610.9061181434599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1099",
        "shared_name" : "jealous",
        "name" : "jealous",
        "SUID" : 1099,
        "selected" : false
      },
      "position" : {
        "x" : 831.0023198238591,
        "y" : -42.093881856540065
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1094",
        "shared_name" : "inevitable",
        "name" : "inevitable",
        "SUID" : 1094,
        "selected" : false
      },
      "position" : {
        "x" : 954.1390680021232,
        "y" : 451.1184528953295
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1089",
        "shared_name" : "indefensible",
        "name" : "indefensible",
        "SUID" : 1089,
        "selected" : false
      },
      "position" : {
        "x" : 635.284791231817,
        "y" : 364.40611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1084",
        "shared_name" : "hostile",
        "name" : "hostile",
        "SUID" : 1084,
        "selected" : false
      },
      "position" : {
        "x" : 561.4250366274241,
        "y" : 592.858295778432
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1079",
        "shared_name" : "hefty",
        "name" : "hefty",
        "SUID" : 1079,
        "selected" : false
      },
      "position" : {
        "x" : 884.9539321202124,
        "y" : 89.43750785645716
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1074",
        "shared_name" : "hard",
        "name" : "hard",
        "SUID" : 1074,
        "selected" : false
      },
      "position" : {
        "x" : 272.0023198238591,
        "y" : 4.906118143459935
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1063",
        "shared_name" : "government",
        "name" : "government",
        "SUID" : 1063,
        "selected" : false
      },
      "position" : {
        "x" : 954.1390680021236,
        "y" : 277.6937833915904
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1055",
        "shared_name" : "glad",
        "name" : "glad",
        "SUID" : 1055,
        "selected" : false
      },
      "position" : {
        "x" : -123.99768017614088,
        "y" : 315.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1050",
        "shared_name" : "gentlemanly",
        "name" : "gentlemanly",
        "SUID" : 1050,
        "selected" : false
      },
      "position" : {
        "x" : 561.425036627425,
        "y" : 135.95394050848745
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1045",
        "shared_name" : "futile",
        "name" : "futile",
        "SUID" : 1045,
        "selected" : false
      },
      "position" : {
        "x" : 1061.665527897875,
        "y" : 364.40611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1037",
        "shared_name" : "following",
        "name" : "following",
        "SUID" : 1037,
        "selected" : false
      },
      "position" : {
        "x" : 550.8483281138228,
        "y" : 408.7308880896412
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1032",
        "shared_name" : "firm",
        "name" : "firm",
        "SUID" : 1032,
        "selected" : false
      },
      "position" : {
        "x" : 825.2594222502921,
        "y" : 161.65002912896853
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1027",
        "shared_name" : "female",
        "name" : "female",
        "SUID" : 1027,
        "selected" : false
      },
      "position" : {
        "x" : 374.0023198238591,
        "y" : 1.9061181434599348
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1022",
        "shared_name" : "fellow",
        "name" : "fellow",
        "SUID" : 1022,
        "selected" : false
      },
      "position" : {
        "x" : 847.1285216350675,
        "y" : 452.15466438019575
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1017",
        "shared_name" : "extremist",
        "name" : "extremist",
        "SUID" : 1017,
        "selected" : false
      },
      "position" : {
        "x" : -239.99768017614088,
        "y" : -407.09388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1012",
        "shared_name" : "exhausted",
        "name" : "exhausted",
        "SUID" : 1012,
        "selected" : false
      },
      "position" : {
        "x" : 1013.6787643623979,
        "y" : 527.8340263518303
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1007",
        "shared_name" : "entertaining",
        "name" : "entertaining",
        "SUID" : 1007,
        "selected" : false
      },
      "position" : {
        "x" : 154.00231982385912,
        "y" : 490.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "999",
        "shared_name" : "dictatorial",
        "name" : "dictatorial",
        "SUID" : 999,
        "selected" : false
      },
      "position" : {
        "x" : 902.0321758308796,
        "y" : 205.9747990751498
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "994",
        "shared_name" : "destitute",
        "name" : "destitute",
        "SUID" : 994,
        "selected" : false
      },
      "position" : {
        "x" : 671.6314291615959,
        "y" : 452.15466438019575
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "983",
        "shared_name" : "courteous",
        "name" : "courteous",
        "SUID" : 983,
        "selected" : false
      },
      "position" : {
        "x" : 716.3602558820089,
        "y" : 65.19739670858735
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "978",
        "shared_name" : "correct",
        "name" : "correct",
        "SUID" : 978,
        "selected" : false
      },
      "position" : {
        "x" : 519.0023198238591,
        "y" : -442.09388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "970",
        "shared_name" : "clever",
        "name" : "clever",
        "SUID" : 970,
        "selected" : false
      },
      "position" : {
        "x" : -331.9976801761409,
        "y" : -260.09388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "965",
        "shared_name" : "central",
        "name" : "central",
        "SUID" : 965,
        "selected" : false
      },
      "position" : {
        "x" : 902.0321758308796,
        "y" : 522.8374372117705
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "954",
        "shared_name" : "beloved",
        "name" : "beloved",
        "SUID" : 954,
        "selected" : false
      },
      "position" : {
        "x" : 469.3391117498436,
        "y" : 279.2424365415386
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "943",
        "shared_name" : "aware",
        "name" : "aware",
        "SUID" : 943,
        "selected" : false
      },
      "position" : {
        "x" : 560.0023198238591,
        "y" : -392.09388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "938",
        "shared_name" : "awake",
        "name" : "awake",
        "SUID" : 938,
        "selected" : false
      },
      "position" : {
        "x" : 1155.0023198238591,
        "y" : 513.9061181434599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "933",
        "shared_name" : "anti",
        "name" : "anti",
        "SUID" : 933,
        "selected" : false
      },
      "position" : {
        "x" : 825.2594222502921,
        "y" : 567.1622071579513
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "928",
        "shared_name" : "02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "name" : "02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "SUID" : 928,
        "selected" : false
      },
      "position" : {
        "x" : 759.3799753983317,
        "y" : 364.40611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "923",
        "shared_name" : "yummy",
        "name" : "yummy",
        "SUID" : 923,
        "selected" : false
      },
      "position" : {
        "x" : 824.1226897330821,
        "y" : 896.3173133398941
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "912",
        "shared_name" : "wonderful",
        "name" : "wonderful",
        "SUID" : 912,
        "selected" : false
      },
      "position" : {
        "x" : -13.997680176140875,
        "y" : 110.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "907",
        "shared_name" : "wet",
        "name" : "wet",
        "SUID" : 907,
        "selected" : false
      },
      "position" : {
        "x" : 558.0023198238591,
        "y" : 1788.90611814346
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "899",
        "shared_name" : "warm",
        "name" : "warm",
        "SUID" : 899,
        "selected" : false
      },
      "position" : {
        "x" : -689.9976801761409,
        "y" : 682.9061181434599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "894",
        "shared_name" : "unrefined",
        "name" : "unrefined",
        "SUID" : 894,
        "selected" : false
      },
      "position" : {
        "x" : -22.805375703565005,
        "y" : 1579.6546643801958
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "889",
        "shared_name" : "tight",
        "name" : "tight",
        "SUID" : 889,
        "selected" : false
      },
      "position" : {
        "x" : -302.63180674500995,
        "y" : 1584.405952299644
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "884",
        "shared_name" : "tasty",
        "name" : "tasty",
        "SUID" : 884,
        "selected" : false
      },
      "position" : {
        "x" : -157.9932418122571,
        "y" : 1284.0608774472657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "876",
        "shared_name" : "super",
        "name" : "super",
        "SUID" : 876,
        "selected" : false
      },
      "position" : {
        "x" : 481.0023198238591,
        "y" : 1593.90611814346
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "871",
        "shared_name" : "stray",
        "name" : "stray",
        "SUID" : 871,
        "selected" : false
      },
      "position" : {
        "x" : -110.55392194030082,
        "y" : 1367.8109339769453
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "866",
        "shared_name" : "special",
        "name" : "special",
        "SUID" : 866,
        "selected" : false
      },
      "position" : {
        "x" : 71.04192881958761,
        "y" : -68.53706654562075
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "855",
        "shared_name" : "simple",
        "name" : "simple",
        "SUID" : 855,
        "selected" : false
      },
      "position" : {
        "x" : 181.00231982385912,
        "y" : -101.09388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "850",
        "shared_name" : "sick",
        "name" : "sick",
        "SUID" : 850,
        "selected" : false
      },
      "position" : {
        "x" : -6.997680176140875,
        "y" : 872.9061181434599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "845",
        "shared_name" : "shallow",
        "name" : "shallow",
        "SUID" : 845,
        "selected" : false
      },
      "position" : {
        "x" : -198.30246817703687,
        "y" : 1579.6546643801958
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "840",
        "shared_name" : "second",
        "name" : "second",
        "SUID" : 840,
        "selected" : false
      },
      "position" : {
        "x" : 53.002319823859125,
        "y" : 688.9061181434599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "829",
        "shared_name" : "ready",
        "name" : "ready",
        "SUID" : 829,
        "selected" : false
      },
      "position" : {
        "x" : -354.9976801761409,
        "y" : 392.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "824",
        "shared_name" : "quiet",
        "name" : "quiet",
        "SUID" : 824,
        "selected" : false
      },
      "position" : {
        "x" : -290.9976801761409,
        "y" : 66.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "819",
        "shared_name" : "possible",
        "name" : "possible",
        "SUID" : 819,
        "selected" : false
      },
      "position" : {
        "x" : -466.9976801761409,
        "y" : 232.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "814",
        "shared_name" : "particular",
        "name" : "particular",
        "SUID" : 814,
        "selected" : false
      },
      "position" : {
        "x" : 595.0023198238591,
        "y" : 808.9061181434599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "809",
        "shared_name" : "outer",
        "name" : "outer",
        "SUID" : 809,
        "selected" : false
      },
      "position" : {
        "x" : -198.30246817703687,
        "y" : 1404.1575719067241
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "804",
        "shared_name" : "okay",
        "name" : "okay",
        "SUID" : 804,
        "selected" : false
      },
      "position" : {
        "x" : -285.9976801761409,
        "y" : 260.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "793",
        "shared_name" : "minded",
        "name" : "minded",
        "SUID" : 793,
        "selected" : false
      },
      "position" : {
        "x" : 760.0023198238591,
        "y" : 841.9061181434599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "788",
        "shared_name" : "long",
        "name" : "long",
        "SUID" : 788,
        "selected" : false
      },
      "position" : {
        "x" : 64.00231982385912,
        "y" : -357.09388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "780",
        "shared_name" : "left",
        "name" : "left",
        "SUID" : 780,
        "selected" : false
      },
      "position" : {
        "x" : -12.997680176140875,
        "y" : -71.59388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "775",
        "shared_name" : "lazy",
        "name" : "lazy",
        "SUID" : 775,
        "selected" : false
      },
      "position" : {
        "x" : -22.805375703564778,
        "y" : 1404.1575719067241
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "770",
        "shared_name" : "late",
        "name" : "late",
        "SUID" : 770,
        "selected" : false
      },
      "position" : {
        "x" : 89.00231982385912,
        "y" : 538.9061181434599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "765",
        "shared_name" : "lame",
        "name" : "lame",
        "SUID" : 765,
        "selected" : false
      },
      "position" : {
        "x" : -97.03728917186936,
        "y" : -74.65069716745938
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "760",
        "shared_name" : "insane",
        "name" : "insane",
        "SUID" : 760,
        "selected" : false
      },
      "position" : {
        "x" : -1057.9976801761409,
        "y" : 1725.90611814346
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "755",
        "shared_name" : "idle",
        "name" : "idle",
        "SUID" : 755,
        "selected" : false
      },
      "position" : {
        "x" : 22.368098569849963,
        "y" : 1325.2271764217426
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "747",
        "shared_name" : "helpful",
        "name" : "helpful",
        "SUID" : 747,
        "selected" : false
      },
      "position" : {
        "x" : 695.8819499146362,
        "y" : 787.4949229470258
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "742",
        "shared_name" : "healthy",
        "name" : "healthy",
        "SUID" : 742,
        "selected" : false
      },
      "position" : {
        "x" : -982.9976801761409,
        "y" : 1523.90611814346
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "728",
        "shared_name" : "final",
        "name" : "final",
        "SUID" : 728,
        "selected" : false
      },
      "position" : {
        "x" : -302.63180674500995,
        "y" : 1399.4062839872759
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "723",
        "shared_name" : "fast",
        "name" : "fast",
        "SUID" : 723,
        "selected" : false
      },
      "position" : {
        "x" : 489.0023198238591,
        "y" : 921.9061181434599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "718",
        "shared_name" : "fancy",
        "name" : "fancy",
        "SUID" : 718,
        "selected" : false
      },
      "position" : {
        "x" : -110.55392194030082,
        "y" : 1616.0013023099746
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "713",
        "shared_name" : "famous",
        "name" : "famous",
        "SUID" : 713,
        "selected" : false
      },
      "position" : {
        "x" : -94.99768017614088,
        "y" : 110.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "708",
        "shared_name" : "elegant",
        "name" : "elegant",
        "SUID" : 708,
        "selected" : false
      },
      "position" : {
        "x" : 76.00231982385912,
        "y" : 797.9061181434599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "703",
        "shared_name" : "efficient",
        "name" : "efficient",
        "SUID" : 703,
        "selected" : false
      },
      "position" : {
        "x" : 13.541262226213576,
        "y" : 1491.90611814346
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "698",
        "shared_name" : "early",
        "name" : "early",
        "SUID" : 698,
        "selected" : false
      },
      "position" : {
        "x" : -157.99324181225734,
        "y" : 1699.7513588396541
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "690",
        "shared_name" : "disheveled",
        "name" : "disheveled",
        "SUID" : 690,
        "selected" : false
      },
      "position" : {
        "x" : 102.6364463927282,
        "y" : 1491.90611814346
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "682",
        "shared_name" : "dead",
        "name" : "dead",
        "SUID" : 682,
        "selected" : false
      },
      "position" : {
        "x" : -234.64910610681545,
        "y" : 1491.90611814346
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "677",
        "shared_name" : "current",
        "name" : "current",
        "SUID" : 677,
        "selected" : false
      },
      "position" : {
        "x" : 30.002319823859125,
        "y" : 440.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "669",
        "shared_name" : "commendable",
        "name" : "commendable",
        "SUID" : 669,
        "selected" : false
      },
      "position" : {
        "x" : 22.368098569849735,
        "y" : 1658.5850598651768
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "664",
        "shared_name" : "cold",
        "name" : "cold",
        "SUID" : 664,
        "selected" : false
      },
      "position" : {
        "x" : -0.9976801761408751,
        "y" : 147.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "656",
        "shared_name" : "busy",
        "name" : "busy",
        "SUID" : 656,
        "selected" : false
      },
      "position" : {
        "x" : 62.002319823859125,
        "y" : 626.9061181434599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "651",
        "shared_name" : "big",
        "name" : "big",
        "SUID" : 651,
        "selected" : false
      },
      "position" : {
        "x" : -166.99768017614088,
        "y" : 165.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "646",
        "shared_name" : "beautiful",
        "name" : "beautiful",
        "SUID" : 646,
        "selected" : false
      },
      "position" : {
        "x" : 267.0023198238591,
        "y" : 41.906118143459935
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "638",
        "shared_name" : "available",
        "name" : "available",
        "SUID" : 638,
        "selected" : false
      },
      "position" : {
        "x" : -252.99768017614088,
        "y" : -266.09388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "633",
        "shared_name" : "angry",
        "name" : "angry",
        "SUID" : 633,
        "selected" : false
      },
      "position" : {
        "x" : -422.9976801761409,
        "y" : 2148.90611814346
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "628",
        "shared_name" : "amazing",
        "name" : "amazing",
        "SUID" : 628,
        "selected" : false
      },
      "position" : {
        "x" : -99.99768017614088,
        "y" : 265.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "623",
        "shared_name" : "02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "name" : "02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "SUID" : 623,
        "selected" : false
      },
      "position" : {
        "x" : -110.55392194030082,
        "y" : 1491.90611814346
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "618",
        "shared_name" : "young",
        "name" : "young",
        "SUID" : 618,
        "selected" : false
      },
      "position" : {
        "x" : -650.9976801761409,
        "y" : 538.9061181434599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "613",
        "shared_name" : "wrong",
        "name" : "wrong",
        "SUID" : 613,
        "selected" : false
      },
      "position" : {
        "x" : 258.0023198238591,
        "y" : -80.09388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "608",
        "shared_name" : "worried",
        "name" : "worried",
        "SUID" : 608,
        "selected" : false
      },
      "position" : {
        "x" : -79.99768017614088,
        "y" : -335.09388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "603",
        "shared_name" : "worldwide",
        "name" : "worldwide",
        "SUID" : 603,
        "selected" : false
      },
      "position" : {
        "x" : -1475.0220222492267,
        "y" : 329.97052146316673
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "598",
        "shared_name" : "well",
        "name" : "well",
        "SUID" : 598,
        "selected" : false
      },
      "position" : {
        "x" : -335.9976801761409,
        "y" : -223.09388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "593",
        "shared_name" : "unwell",
        "name" : "unwell",
        "SUID" : 593,
        "selected" : false
      },
      "position" : {
        "x" : -1083.9733381030558,
        "y" : 1.8417148237526817
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "588",
        "shared_name" : "unhappy",
        "name" : "unhappy",
        "SUID" : 588,
        "selected" : false
      },
      "position" : {
        "x" : -1151.878229484089,
        "y" : 386.94949077612546
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "583",
        "shared_name" : "true",
        "name" : "true",
        "SUID" : 583,
        "selected" : false
      },
      "position" : {
        "x" : 1.0023198238591249,
        "y" : 184.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "578",
        "shared_name" : "toxic",
        "name" : "toxic",
        "SUID" : 578,
        "selected" : false
      },
      "position" : {
        "x" : -1155.4024960096262,
        "y" : 165.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "573",
        "shared_name" : "tired",
        "name" : "tired",
        "SUID" : 573,
        "selected" : false
      },
      "position" : {
        "x" : -284.9976801761409,
        "y" : 223.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "568",
        "shared_name" : "tingly",
        "name" : "tingly",
        "SUID" : 568,
        "selected" : false
      },
      "position" : {
        "x" : -1519.3437923442857,
        "y" : 78.60927250978284
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "563",
        "shared_name" : "thick",
        "name" : "thick",
        "SUID" : 563,
        "selected" : false
      },
      "position" : {
        "x" : -1323.8194502712006,
        "y" : -85.45513080992396
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "558",
        "shared_name" : "talented",
        "name" : "talented",
        "SUID" : 558,
        "selected" : false
      },
      "position" : {
        "x" : -581.9976801761409,
        "y" : -507.09388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "553",
        "shared_name" : "surprising",
        "name" : "surprising",
        "SUID" : 553,
        "selected" : false
      },
      "position" : {
        "x" : -1407.1171308681928,
        "y" : 386.94949077612546
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "548",
        "shared_name" : "sure",
        "name" : "sure",
        "SUID" : 548,
        "selected" : false
      },
      "position" : {
        "x" : -75.99768017614088,
        "y" : -218.09388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "543",
        "shared_name" : "sorry",
        "name" : "sorry",
        "SUID" : 543,
        "selected" : false
      },
      "position" : {
        "x" : 161.00231982385912,
        "y" : 109.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "538",
        "shared_name" : "small",
        "name" : "small",
        "SUID" : 538,
        "selected" : false
      },
      "position" : {
        "x" : 133.00231982385912,
        "y" : -429.09388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "533",
        "shared_name" : "skilled",
        "name" : "skilled",
        "SUID" : 533,
        "selected" : false
      },
      "position" : {
        "x" : 3.002319823859125,
        "y" : 530.9061181434599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "528",
        "shared_name" : "single",
        "name" : "single",
        "SUID" : 528,
        "selected" : false
      },
      "position" : {
        "x" : -279.9976801761409,
        "y" : -359.09388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "523",
        "shared_name" : "sharp",
        "name" : "sharp",
        "SUID" : 523,
        "selected" : false
      },
      "position" : {
        "x" : -1235.1759100810818,
        "y" : 417.2673670968443
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "518",
        "shared_name" : "secret",
        "name" : "secret",
        "SUID" : 518,
        "selected" : false
      },
      "position" : {
        "x" : -734.9976801761409,
        "y" : 341.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "513",
        "shared_name" : "safe",
        "name" : "safe",
        "SUID" : 513,
        "selected" : false
      },
      "position" : {
        "x" : 39.002319823859125,
        "y" : -307.09388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "508",
        "shared_name" : "sad",
        "name" : "sad",
        "SUID" : 508,
        "selected" : false
      },
      "position" : {
        "x" : 366.0023198238591,
        "y" : -184.09388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "503",
        "shared_name" : "right",
        "name" : "right",
        "SUID" : 503,
        "selected" : false
      },
      "position" : {
        "x" : -46.997680176140875,
        "y" : 311.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "498",
        "shared_name" : "rare",
        "name" : "rare",
        "SUID" : 498,
        "selected" : false
      },
      "position" : {
        "x" : -1151.8782294840896,
        "y" : -55.13725448920559
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "493",
        "shared_name" : "pufferfish",
        "name" : "pufferfish",
        "SUID" : 493,
        "selected" : false
      },
      "position" : {
        "x" : -1083.973338103055,
        "y" : 329.97052146316673
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "488",
        "shared_name" : "psychic",
        "name" : "psychic",
        "SUID" : 488,
        "selected" : false
      },
      "position" : {
        "x" : 536.5023198238591,
        "y" : 1256.90611814346
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "483",
        "shared_name" : "pitiful",
        "name" : "pitiful",
        "SUID" : 483,
        "selected" : false
      },
      "position" : {
        "x" : -179.99768017614088,
        "y" : 413.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "478",
        "shared_name" : "personal",
        "name" : "personal",
        "SUID" : 478,
        "selected" : false
      },
      "position" : {
        "x" : 454.3741833962149,
        "y" : 1222.3674289878559
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "473",
        "shared_name" : "perfect",
        "name" : "perfect",
        "SUID" : 473,
        "selected" : false
      },
      "position" : {
        "x" : 171.00231982385912,
        "y" : 427.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "468",
        "shared_name" : "pathetic",
        "name" : "pathetic",
        "SUID" : 468,
        "selected" : false
      },
      "position" : {
        "x" : -1225.9976801761409,
        "y" : 1000.9061181434599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "463",
        "shared_name" : "ostanian",
        "name" : "ostanian",
        "SUID" : 463,
        "selected" : false
      },
      "position" : {
        "x" : 618.6304562515033,
        "y" : 1291.444807299064
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "458",
        "shared_name" : "original",
        "name" : "original",
        "SUID" : 458,
        "selected" : false
      },
      "position" : {
        "x" : -79.99768017614088,
        "y" : 186.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "453",
        "shared_name" : "olive",
        "name" : "olive",
        "SUID" : 453,
        "selected" : false
      },
      "position" : {
        "x" : -1367.2462264128767,
        "y" : 78.15757190672412
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "448",
        "shared_name" : "odd",
        "name" : "odd",
        "SUID" : 448,
        "selected" : false
      },
      "position" : {
        "x" : -1191.749133939405,
        "y" : 253.65466438019575
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "443",
        "shared_name" : "obtrusive",
        "name" : "obtrusive",
        "SUID" : 443,
        "selected" : false
      },
      "position" : {
        "x" : -1519.3437923442857,
        "y" : 253.20296377713794
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "438",
        "shared_name" : "normal",
        "name" : "normal",
        "SUID" : 438,
        "selected" : false
      },
      "position" : {
        "x" : 257.0023198238591,
        "y" : 175.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "433",
        "shared_name" : "nice",
        "name" : "nice",
        "SUID" : 433,
        "selected" : false
      },
      "position" : {
        "x" : -200.99768017614088,
        "y" : 288.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "428",
        "shared_name" : "new",
        "name" : "new",
        "SUID" : 428,
        "selected" : false
      },
      "position" : {
        "x" : 154.00231982385912,
        "y" : -64.09388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "423",
        "shared_name" : "mean",
        "name" : "mean",
        "SUID" : 423,
        "selected" : false
      },
      "position" : {
        "x" : -1367.2462264128767,
        "y" : 253.65466438019575
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "418",
        "shared_name" : "married",
        "name" : "married",
        "SUID" : 418,
        "selected" : false
      },
      "position" : {
        "x" : 17.002319823859125,
        "y" : -440.09388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "413",
        "shared_name" : "mad",
        "name" : "mad",
        "SUID" : 413,
        "selected" : false
      },
      "position" : {
        "x" : 112.00231982385912,
        "y" : 363.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "408",
        "shared_name" : "loose",
        "name" : "loose",
        "SUID" : 408,
        "selected" : false
      },
      "position" : {
        "x" : -1475.0220222492271,
        "y" : 1.841714823754046
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "403",
        "shared_name" : "lone",
        "name" : "lone",
        "SUID" : 403,
        "selected" : false
      },
      "position" : {
        "x" : -1235.1759100810827,
        "y" : -85.45513080992441
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "398",
        "shared_name" : "little",
        "name" : "little",
        "SUID" : 398,
        "selected" : false
      },
      "position" : {
        "x" : 22.002319823859125,
        "y" : -254.09388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "393",
        "shared_name" : "like",
        "name" : "like",
        "SUID" : 393,
        "selected" : false
      },
      "position" : {
        "x" : -1279.4976801761409,
        "y" : 290.00130230997456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "388",
        "shared_name" : "lethal",
        "name" : "lethal",
        "SUID" : 388,
        "selected" : false
      },
      "position" : {
        "x" : -1279.4976801761409,
        "y" : 41.81093397694531
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "383",
        "shared_name" : "key",
        "name" : "key",
        "SUID" : 383,
        "selected" : false
      },
      "position" : {
        "x" : 501.96363066825506,
        "y" : 1339.0342545711037
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "378",
        "shared_name" : "infamous",
        "name" : "infamous",
        "SUID" : 378,
        "selected" : false
      },
      "position" : {
        "x" : -1534.736581560245,
        "y" : 165.9061181434604
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "373",
        "shared_name" : "impressive",
        "name" : "impressive",
        "SUID" : 373,
        "selected" : false
      },
      "position" : {
        "x" : -21.997680176140875,
        "y" : 73.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "368",
        "shared_name" : "important",
        "name" : "important",
        "SUID" : 368,
        "selected" : false
      },
      "position" : {
        "x" : 272.0023198238591,
        "y" : -150.09388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "363",
        "shared_name" : "hungry",
        "name" : "hungry",
        "SUID" : 363,
        "selected" : false
      },
      "position" : {
        "x" : 344.0023198238591,
        "y" : 44.906118143459935
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "358",
        "shared_name" : "horrendous",
        "name" : "horrendous",
        "SUID" : 358,
        "selected" : false
      },
      "position" : {
        "x" : -1403.5928643426555,
        "y" : 165.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "353",
        "shared_name" : "hopeless",
        "name" : "hopeless",
        "SUID" : 353,
        "selected" : false
      },
      "position" : {
        "x" : -745.9976801761409,
        "y" : 597.9061181434599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "348",
        "shared_name" : "high",
        "name" : "high",
        "SUID" : 348,
        "selected" : false
      },
      "position" : {
        "x" : 321.0023198238591,
        "y" : 105.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "343",
        "shared_name" : "hectic",
        "name" : "hectic",
        "SUID" : 343,
        "selected" : false
      },
      "position" : {
        "x" : -1407.1171308681933,
        "y" : -55.137254489205134
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "338",
        "shared_name" : "happy",
        "name" : "happy",
        "SUID" : 338,
        "selected" : false
      },
      "position" : {
        "x" : 65.00231982385912,
        "y" : 295.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "333",
        "shared_name" : "great",
        "name" : "great",
        "SUID" : 333,
        "selected" : false
      },
      "position" : {
        "x" : 163.00231982385912,
        "y" : -228.09388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "328",
        "shared_name" : "good",
        "name" : "good",
        "SUID" : 328,
        "selected" : false
      },
      "position" : {
        "x" : -171.99768017614088,
        "y" : 108.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "323",
        "shared_name" : "fun",
        "name" : "fun",
        "SUID" : 323,
        "selected" : false
      },
      "position" : {
        "x" : -15.997680176140875,
        "y" : 348.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "318",
        "shared_name" : "fine",
        "name" : "fine",
        "SUID" : 318,
        "selected" : false
      },
      "position" : {
        "x" : -127.99768017614088,
        "y" : 223.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "313",
        "shared_name" : "fierce",
        "name" : "fierce",
        "SUID" : 313,
        "selected" : false
      },
      "position" : {
        "x" : 335.0023198238591,
        "y" : 195.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "308",
        "shared_name" : "fake",
        "name" : "fake",
        "SUID" : 308,
        "selected" : false
      },
      "position" : {
        "x" : 184.00231982385912,
        "y" : -138.09388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "303",
        "shared_name" : "faint",
        "name" : "faint",
        "SUID" : 303,
        "selected" : false
      },
      "position" : {
        "x" : -1024.2587787920368,
        "y" : 165.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "298",
        "shared_name" : "extreme",
        "name" : "extreme",
        "SUID" : 298,
        "selected" : false
      },
      "position" : {
        "x" : -1323.8194502712,
        "y" : 417.2673670968443
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "293",
        "shared_name" : "extra",
        "name" : "extra",
        "SUID" : 293,
        "selected" : false
      },
      "position" : {
        "x" : 212.00231982385912,
        "y" : 286.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "288",
        "shared_name" : "exciting",
        "name" : "exciting",
        "SUID" : 288,
        "selected" : false
      },
      "position" : {
        "x" : -331.9976801761409,
        "y" : 103.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "283",
        "shared_name" : "easy",
        "name" : "easy",
        "SUID" : 283,
        "selected" : false
      },
      "position" : {
        "x" : -225.99768017614088,
        "y" : -229.09388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "278",
        "shared_name" : "dry",
        "name" : "dry",
        "SUID" : 278,
        "selected" : false
      },
      "position" : {
        "x" : -668.9976801761409,
        "y" : 780.9061181434599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "273",
        "shared_name" : "discrete",
        "name" : "discrete",
        "SUID" : 273,
        "selected" : false
      },
      "position" : {
        "x" : 571.0410089794632,
        "y" : 1174.7779817158162
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "268",
        "shared_name" : "different",
        "name" : "different",
        "SUID" : 268,
        "selected" : false
      },
      "position" : {
        "x" : 173.00231982385912,
        "y" : -3.093881856540065
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "263",
        "shared_name" : "delicious",
        "name" : "delicious",
        "SUID" : 263,
        "selected" : false
      },
      "position" : {
        "x" : -191.99768017614088,
        "y" : -317.09388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "258",
        "shared_name" : "dangerous",
        "name" : "dangerous",
        "SUID" : 258,
        "selected" : false
      },
      "position" : {
        "x" : 190.00231982385912,
        "y" : 62.906118143459935
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "253",
        "shared_name" : "countless",
        "name" : "countless",
        "SUID" : 253,
        "selected" : false
      },
      "position" : {
        "x" : 187.00231982385912,
        "y" : -191.09388185654007
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "248",
        "shared_name" : "cool",
        "name" : "cool",
        "SUID" : 248,
        "selected" : false
      },
      "position" : {
        "x" : -243.99768017614088,
        "y" : 147.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "243",
        "shared_name" : "certain",
        "name" : "certain",
        "SUID" : 243,
        "selected" : false
      },
      "position" : {
        "x" : -60.997680176140875,
        "y" : -578.0938818565401
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "238",
        "shared_name" : "casual",
        "name" : "casual",
        "SUID" : 238,
        "selected" : false
      },
      "position" : {
        "x" : -1039.651568007996,
        "y" : 253.20296377713748
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "233",
        "shared_name" : "careful",
        "name" : "careful",
        "SUID" : 233,
        "selected" : false
      },
      "position" : {
        "x" : -364.9976801761409,
        "y" : 239.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "228",
        "shared_name" : "capable",
        "name" : "capable",
        "SUID" : 228,
        "selected" : false
      },
      "position" : {
        "x" : -1191.7491339394048,
        "y" : 78.15757190672412
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "223",
        "shared_name" : "boring",
        "name" : "boring",
        "SUID" : 223,
        "selected" : false
      },
      "position" : {
        "x" : -89.99768017614088,
        "y" : 148.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "218",
        "shared_name" : "bored",
        "name" : "bored",
        "SUID" : 218,
        "selected" : false
      },
      "position" : {
        "x" : -1766.9976801761409,
        "y" : -59.093881856540065
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "213",
        "shared_name" : "bad",
        "name" : "bad",
        "SUID" : 213,
        "selected" : false
      },
      "position" : {
        "x" : 78.00231982385912,
        "y" : 258.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "208",
        "shared_name" : "armed",
        "name" : "armed",
        "SUID" : 208,
        "selected" : false
      },
      "position" : {
        "x" : -1039.6515680079965,
        "y" : 78.60927250978148
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "203",
        "shared_name" : "actual",
        "name" : "actual",
        "SUID" : 203,
        "selected" : false
      },
      "position" : {
        "x" : -451.9976801761409,
        "y" : -727.0938818565401
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "185",
        "shared_name" : "02x01_-_Follow_Mama_and_Papa",
        "name" : "02x01_-_Follow_Mama_and_Papa",
        "SUID" : 185,
        "selected" : false
      },
      "position" : {
        "x" : -1279.4976801761409,
        "y" : 165.90611814345993
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "183",
        "shared_name" : "able",
        "name" : "able",
        "SUID" : 183,
        "selected" : false
      },
      "position" : {
        "x" : 1.0023198238591249,
        "y" : -217.09388185654007
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "4021",
        "source" : "4019",
        "target" : "3756",
        "shared_name" : "wilted (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "wilted (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 4021,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4013",
        "source" : "4011",
        "target" : "3756",
        "shared_name" : "weird (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "weird (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 4013,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3990",
        "source" : "3988",
        "target" : "3756",
        "shared_name" : "suspect (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "suspect (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3990,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3970",
        "source" : "3968",
        "target" : "3756",
        "shared_name" : "skinny (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "skinny (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3970,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3956",
        "source" : "3954",
        "target" : "3756",
        "shared_name" : "shriveled (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "shriveled (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3956,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3951",
        "source" : "3949",
        "target" : "3756",
        "shared_name" : "serial (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "serial (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3951,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3934",
        "source" : "3932",
        "target" : "3756",
        "shared_name" : "restless (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "restless (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3934,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3920",
        "source" : "3918",
        "target" : "3756",
        "shared_name" : "preposterous (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "preposterous (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3920,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3912",
        "source" : "3910",
        "target" : "3756",
        "shared_name" : "plastic (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "plastic (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3912,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3889",
        "source" : "3887",
        "target" : "3756",
        "shared_name" : "multiple (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "multiple (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3889,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3869",
        "source" : "3867",
        "target" : "3756",
        "shared_name" : "irrational (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "irrational (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3869,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3864",
        "source" : "3862",
        "target" : "3756",
        "shared_name" : "intelligent (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "intelligent (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3864,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3859",
        "source" : "3857",
        "target" : "3756",
        "shared_name" : "inside (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 2,
        "name" : "inside (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3859,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3854",
        "source" : "3852",
        "target" : "3756",
        "shared_name" : "innocent (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 8,
        "count" : 1,
        "name" : "innocent (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3854,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3822",
        "source" : "3820",
        "target" : "3756",
        "shared_name" : "gentle (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 1,
        "name" : "gentle (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3822,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3817",
        "source" : "3815",
        "target" : "3756",
        "shared_name" : "fluffy (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "fluffy (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3817,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3803",
        "source" : "3801",
        "target" : "3756",
        "shared_name" : "enjoyable (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "enjoyable (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3803,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3783",
        "source" : "3781",
        "target" : "3756",
        "shared_name" : "critical (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 2,
        "name" : "critical (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3783,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3763",
        "source" : "3761",
        "target" : "3756",
        "shared_name" : "addictive (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "addictive (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3763,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3747",
        "source" : "3745",
        "target" : "3432",
        "shared_name" : "worthless (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "worthless (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3747,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3736",
        "source" : "3734",
        "target" : "3432",
        "shared_name" : "womanly (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "womanly (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3736,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3731",
        "source" : "3729",
        "target" : "3432",
        "shared_name" : "wise (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 1,
        "name" : "wise (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3731,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3726",
        "source" : "3724",
        "target" : "3432",
        "shared_name" : "willing (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "willing (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3726,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3721",
        "source" : "3719",
        "target" : "3432",
        "shared_name" : "weak (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 12,
        "count" : 2,
        "name" : "weak (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3721,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3716",
        "source" : "3714",
        "target" : "3432",
        "shared_name" : "valuable (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "valuable (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3716,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3708",
        "source" : "3706",
        "target" : "3432",
        "shared_name" : "useful (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 2,
        "name" : "useful (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3708,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3703",
        "source" : "3701",
        "target" : "3432",
        "shared_name" : "urgent (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "urgent (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3703,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3698",
        "source" : "3696",
        "target" : "3432",
        "shared_name" : "unannounced (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "unannounced (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3698,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3690",
        "source" : "3688",
        "target" : "3432",
        "shared_name" : "trivial (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "trivial (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3690,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3682",
        "source" : "3680",
        "target" : "3432",
        "shared_name" : "tiresome (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "tiresome (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3682,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3674",
        "source" : "3672",
        "target" : "3432",
        "shared_name" : "suited (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "suited (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3674,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3663",
        "source" : "3661",
        "target" : "3432",
        "shared_name" : "spacious (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "spacious (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3663,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3655",
        "source" : "3653",
        "target" : "3432",
        "shared_name" : "smiley (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "smiley (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3655,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3644",
        "source" : "3642",
        "target" : "3432",
        "shared_name" : "sexy (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "sexy (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3644,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3636",
        "source" : "3634",
        "target" : "3432",
        "shared_name" : "rounded (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 8,
        "count" : 1,
        "name" : "rounded (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3636,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3625",
        "source" : "3623",
        "target" : "3432",
        "shared_name" : "professional (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 8,
        "count" : 1,
        "name" : "professional (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3625,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3620",
        "source" : "3618",
        "target" : "3432",
        "shared_name" : "potential (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "potential (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3620,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3594",
        "source" : "3592",
        "target" : "3432",
        "shared_name" : "nauseous (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "nauseous (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3594,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3589",
        "source" : "3587",
        "target" : "3432",
        "shared_name" : "naive (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "naive (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3589,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3581",
        "source" : "3579",
        "target" : "3432",
        "shared_name" : "major (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 13,
        "count" : 1,
        "name" : "major (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3581,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3558",
        "source" : "3556",
        "target" : "3432",
        "shared_name" : "ill (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 9,
        "count" : 1,
        "name" : "ill (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3558,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3840",
        "source" : "3551",
        "target" : "3756",
        "shared_name" : "hot (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 21,
        "count" : 1,
        "name" : "hot (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3840,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3553",
        "source" : "3551",
        "target" : "3432",
        "shared_name" : "hot (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 21,
        "count" : 1,
        "name" : "hot (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3553,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3530",
        "source" : "3528",
        "target" : "3432",
        "shared_name" : "future (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 1,
        "name" : "future (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3530,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3522",
        "source" : "3520",
        "target" : "3432",
        "shared_name" : "formal (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 8,
        "count" : 1,
        "name" : "formal (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3522,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3511",
        "source" : "3509",
        "target" : "3432",
        "shared_name" : "experienced (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "experienced (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3511,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3506",
        "source" : "3504",
        "target" : "3432",
        "shared_name" : "envious (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "envious (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3506,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3498",
        "source" : "3496",
        "target" : "3432",
        "shared_name" : "dull (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 19,
        "count" : 1,
        "name" : "dull (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3498,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3493",
        "source" : "3491",
        "target" : "3432",
        "shared_name" : "drunk (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 9,
        "count" : 2,
        "name" : "drunk (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3493,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3482",
        "source" : "3480",
        "target" : "3432",
        "shared_name" : "curious (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 2,
        "name" : "curious (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3482,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3471",
        "source" : "3469",
        "target" : "3432",
        "shared_name" : "confident (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "confident (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3471,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3439",
        "source" : "3437",
        "target" : "3432",
        "shared_name" : "acute (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 1,
        "name" : "acute (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3439,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3426",
        "source" : "3424",
        "target" : "3174",
        "shared_name" : "worthy (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "worthy (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3426,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3418",
        "source" : "3416",
        "target" : "3174",
        "shared_name" : "unnerving (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "unnerving (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3418,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3410",
        "source" : "3408",
        "target" : "3174",
        "shared_name" : "unfortunate (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "unfortunate (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3410,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3399",
        "source" : "3397",
        "target" : "3174",
        "shared_name" : "tra (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 0,
        "count" : 1,
        "name" : "tra (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3399,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3391",
        "source" : "3389",
        "target" : "3174",
        "shared_name" : "thrilling (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "thrilling (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3391,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3386",
        "source" : "3384",
        "target" : "3174",
        "shared_name" : "threatening (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "threatening (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3386,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3381",
        "source" : "3379",
        "target" : "3174",
        "shared_name" : "tame (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 9,
        "count" : 1,
        "name" : "tame (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3381,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3376",
        "source" : "3374",
        "target" : "3174",
        "shared_name" : "swollen (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 1,
        "name" : "swollen (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3376,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3365",
        "source" : "3363",
        "target" : "3174",
        "shared_name" : "sleepy (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 2,
        "name" : "sleepy (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3365,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3345",
        "source" : "3343",
        "target" : "3174",
        "shared_name" : "remarkable (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "remarkable (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3345,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3606",
        "source" : "3323",
        "target" : "3432",
        "shared_name" : "ordinary (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 2,
        "name" : "ordinary (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3606,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3325",
        "source" : "3323",
        "target" : "3174",
        "shared_name" : "ordinary (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 2,
        "name" : "ordinary (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3325,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3284",
        "source" : "3282",
        "target" : "3174",
        "shared_name" : "la (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "la (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3284,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3276",
        "source" : "3274",
        "target" : "3174",
        "shared_name" : "ideal (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "ideal (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3276,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3244",
        "source" : "3242",
        "target" : "3174",
        "shared_name" : "exhausting (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 2,
        "name" : "exhausting (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3244,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3236",
        "source" : "3234",
        "target" : "3174",
        "shared_name" : "embarrassed (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "embarrassed (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3236,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3216",
        "source" : "3214",
        "target" : "3174",
        "shared_name" : "convincing (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 2,
        "name" : "convincing (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3216,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3211",
        "source" : "3209",
        "target" : "3174",
        "shared_name" : "complicated (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "complicated (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3211,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3200",
        "source" : "3198",
        "target" : "3174",
        "shared_name" : "careless (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "careless (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3200,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3195",
        "source" : "3193",
        "target" : "3174",
        "shared_name" : "bold (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "bold (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3195,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3181",
        "source" : "3179",
        "target" : "3174",
        "shared_name" : "awful (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 1,
        "name" : "awful (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3181,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3165",
        "source" : "3163",
        "target" : "2946",
        "shared_name" : "western (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 3,
        "name" : "western (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3165,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3157",
        "source" : "3155",
        "target" : "2946",
        "shared_name" : "upper (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 3,
        "name" : "upper (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3157,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3134",
        "source" : "3132",
        "target" : "2946",
        "shared_name" : "straightforward (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "straightforward (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3134,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3129",
        "source" : "3127",
        "target" : "2946",
        "shared_name" : "sticky (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "sticky (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3129,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3118",
        "source" : "3116",
        "target" : "2946",
        "shared_name" : "sentimental (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "sentimental (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3118,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3101",
        "source" : "3099",
        "target" : "2946",
        "shared_name" : "risky (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "risky (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3101,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3331",
        "source" : "3088",
        "target" : "3174",
        "shared_name" : "peaceful (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "peaceful (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3331,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3090",
        "source" : "3088",
        "target" : "2946",
        "shared_name" : "peaceful (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "peaceful (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3090,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3064",
        "source" : "3062",
        "target" : "2946",
        "shared_name" : "impossible (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 2,
        "name" : "impossible (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3064,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3271",
        "source" : "3057",
        "target" : "3174",
        "shared_name" : "hey (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 0,
        "count" : 1,
        "name" : "hey (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3271,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3059",
        "source" : "3057",
        "target" : "2946",
        "shared_name" : "hey (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 0,
        "count" : 1,
        "name" : "hey (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3059,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3039",
        "source" : "3037",
        "target" : "2946",
        "shared_name" : "fullest (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 8,
        "count" : 1,
        "name" : "fullest (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3039,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3034",
        "source" : "3032",
        "target" : "2946",
        "shared_name" : "farewell (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "farewell (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3034,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3020",
        "source" : "3018",
        "target" : "2946",
        "shared_name" : "eastern (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "eastern (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3020,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3012",
        "source" : "3010",
        "target" : "2946",
        "shared_name" : "deadly (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 8,
        "count" : 1,
        "name" : "deadly (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3012,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3007",
        "source" : "3005",
        "target" : "2946",
        "shared_name" : "darn (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "darn (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3007,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2993",
        "source" : "2991",
        "target" : "2946",
        "shared_name" : "convenient (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "convenient (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 2993,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2988",
        "source" : "2986",
        "target" : "2946",
        "shared_name" : "common (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 1,
        "name" : "common (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 2988,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3766",
        "source" : "2951",
        "target" : "3756",
        "shared_name" : "alive (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 1,
        "name" : "alive (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3766,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2953",
        "source" : "2951",
        "target" : "2946",
        "shared_name" : "alive (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 1,
        "name" : "alive (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 2953,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2937",
        "source" : "2935",
        "target" : "2654",
        "shared_name" : "unwarranted (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "unwarranted (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2937,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2929",
        "source" : "2927",
        "target" : "2654",
        "shared_name" : "unfamiliar (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "unfamiliar (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2929,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2924",
        "source" : "2922",
        "target" : "2654",
        "shared_name" : "unexpected (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "unexpected (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2924,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2907",
        "source" : "2905",
        "target" : "2654",
        "shared_name" : "sturdy (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "sturdy (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2907,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3976",
        "source" : "2897",
        "target" : "3756",
        "shared_name" : "strange (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "strange (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3976,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3137",
        "source" : "2897",
        "target" : "2946",
        "shared_name" : "strange (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "strange (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3137,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2899",
        "source" : "2897",
        "target" : "2654",
        "shared_name" : "strange (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "strange (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2899,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2894",
        "source" : "2892",
        "target" : "2654",
        "shared_name" : "startling (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "startling (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2894,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2883",
        "source" : "2881",
        "target" : "2654",
        "shared_name" : "similar (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "similar (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2883,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2875",
        "source" : "2873",
        "target" : "2654",
        "shared_name" : "secluded (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "secluded (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2875,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2855",
        "source" : "2853",
        "target" : "2654",
        "shared_name" : "red (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 1,
        "name" : "red (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2855,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3929",
        "source" : "2848",
        "target" : "3756",
        "shared_name" : "reckless (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "reckless (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3929,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2850",
        "source" : "2848",
        "target" : "2654",
        "shared_name" : "reckless (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "reckless (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2850,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2842",
        "source" : "2840",
        "target" : "2654",
        "shared_name" : "proud (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "proud (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2842,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2837",
        "source" : "2835",
        "target" : "2654",
        "shared_name" : "pretty (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "pretty (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2837,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2826",
        "source" : "2824",
        "target" : "2654",
        "shared_name" : "poisonous (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "poisonous (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2826,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2812",
        "source" : "2810",
        "target" : "2654",
        "shared_name" : "natural (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 13,
        "count" : 1,
        "name" : "natural (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2812,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2807",
        "source" : "2805",
        "target" : "2654",
        "shared_name" : "memorable (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "memorable (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2807,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2781",
        "source" : "2779",
        "target" : "2654",
        "shared_name" : "inflatable (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "inflatable (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2781,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2773",
        "source" : "2771",
        "target" : "2654",
        "shared_name" : "horrible (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 2,
        "name" : "horrible (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2773,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2768",
        "source" : "2766",
        "target" : "2654",
        "shared_name" : "herbal (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 3,
        "name" : "herbal (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2768,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2763",
        "source" : "2761",
        "target" : "2654",
        "shared_name" : "heavy (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 30,
        "count" : 1,
        "name" : "heavy (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2763,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2749",
        "source" : "2747",
        "target" : "2654",
        "shared_name" : "grueling (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "grueling (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2749,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2744",
        "source" : "2742",
        "target" : "2654",
        "shared_name" : "green (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 14,
        "count" : 1,
        "name" : "green (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2744,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2727",
        "source" : "2725",
        "target" : "2654",
        "shared_name" : "fashioned (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "fashioned (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2727,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2710",
        "source" : "2708",
        "target" : "2654",
        "shared_name" : "disgusting (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "disgusting (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2710,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2702",
        "source" : "2700",
        "target" : "2654",
        "shared_name" : "dazzling (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "dazzling (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2702,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3002",
        "source" : "2695",
        "target" : "2946",
        "shared_name" : "crowded (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "crowded (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3002,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2697",
        "source" : "2695",
        "target" : "2654",
        "shared_name" : "crowded (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "crowded (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2697,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2689",
        "source" : "2687",
        "target" : "2654",
        "shared_name" : "climactic (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "climactic (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2689,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3778",
        "source" : "2682",
        "target" : "3756",
        "shared_name" : "clean (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 31,
        "count" : 1,
        "name" : "clean (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3778,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2684",
        "source" : "2682",
        "target" : "2654",
        "shared_name" : "clean (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 31,
        "count" : 1,
        "name" : "clean (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2684,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2977",
        "source" : "2677",
        "target" : "2946",
        "shared_name" : "carefree (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "carefree (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 2977,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2679",
        "source" : "2677",
        "target" : "2654",
        "shared_name" : "carefree (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "carefree (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2679,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2648",
        "source" : "2646",
        "target" : "2339",
        "shared_name" : "yor (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 0,
        "count" : 1,
        "name" : "yor (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2648,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4008",
        "source" : "2638",
        "target" : "3756",
        "shared_name" : "useless (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "useless (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 4008,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3711",
        "source" : "2638",
        "target" : "3432",
        "shared_name" : "useless (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "useless (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3711,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2640",
        "source" : "2638",
        "target" : "2339",
        "shared_name" : "useless (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "useless (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2640,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2635",
        "source" : "2633",
        "target" : "2339",
        "shared_name" : "upset (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 17,
        "count" : 1,
        "name" : "upset (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2635,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3413",
        "source" : "2628",
        "target" : "3174",
        "shared_name" : "unknown (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 8,
        "count" : 1,
        "name" : "unknown (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3413,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2630",
        "source" : "2628",
        "target" : "2339",
        "shared_name" : "unknown (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 8,
        "count" : 4,
        "name" : "unknown (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2630,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2625",
        "source" : "2623",
        "target" : "2339",
        "shared_name" : "unidentified (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "unidentified (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2625,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3152",
        "source" : "2615",
        "target" : "2946",
        "shared_name" : "uncool (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "uncool (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3152,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2617",
        "source" : "2615",
        "target" : "2339",
        "shared_name" : "uncool (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 2,
        "name" : "uncool (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2617,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2612",
        "source" : "2610",
        "target" : "2339",
        "shared_name" : "unable (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "unable (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2612,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2607",
        "source" : "2605",
        "target" : "2339",
        "shared_name" : "troubling (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "troubling (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2607,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2596",
        "source" : "2594",
        "target" : "2339",
        "shared_name" : "successful (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "successful (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2596,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3107",
        "source" : "2577",
        "target" : "2946",
        "shared_name" : "scary (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "scary (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3107,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2579",
        "source" : "2577",
        "target" : "2339",
        "shared_name" : "scary (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 3,
        "name" : "scary (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2579,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3946",
        "source" : "2572",
        "target" : "3756",
        "shared_name" : "scared (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "scared (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3946,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2870",
        "source" : "2572",
        "target" : "2654",
        "shared_name" : "scared (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "scared (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2870,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2574",
        "source" : "2572",
        "target" : "2339",
        "shared_name" : "scared (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "scared (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2574,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3351",
        "source" : "2567",
        "target" : "3174",
        "shared_name" : "satisfied (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "satisfied (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3351,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2867",
        "source" : "2567",
        "target" : "2654",
        "shared_name" : "satisfied (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "satisfied (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2867,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2569",
        "source" : "2567",
        "target" : "2339",
        "shared_name" : "satisfied (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "satisfied (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2569,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2561",
        "source" : "2559",
        "target" : "2339",
        "shared_name" : "rebellious (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "rebellious (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2561,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2550",
        "source" : "2548",
        "target" : "2339",
        "shared_name" : "pro (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "pro (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2550,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2542",
        "source" : "2540",
        "target" : "2339",
        "shared_name" : "pet (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 1,
        "name" : "pet (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2542,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2531",
        "source" : "2529",
        "target" : "2339",
        "shared_name" : "overconfident (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "overconfident (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2531,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2514",
        "source" : "2512",
        "target" : "2339",
        "shared_name" : "obedient (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "obedient (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2514,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3299",
        "source" : "2495",
        "target" : "3174",
        "shared_name" : "loud (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "loud (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3299,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2799",
        "source" : "2495",
        "target" : "2654",
        "shared_name" : "loud (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 2,
        "name" : "loud (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2799,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2497",
        "source" : "2495",
        "target" : "2339",
        "shared_name" : "loud (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "loud (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2497,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2793",
        "source" : "2484",
        "target" : "2654",
        "shared_name" : "likely (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "likely (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2793,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2486",
        "source" : "2484",
        "target" : "2339",
        "shared_name" : "likely (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "likely (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2486,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2481",
        "source" : "2479",
        "target" : "2339",
        "shared_name" : "invisible (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "invisible (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2481,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2476",
        "source" : "2474",
        "target" : "2339",
        "shared_name" : "intermediate (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "intermediate (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2476,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2462",
        "source" : "2460",
        "target" : "2339",
        "shared_name" : "heroic (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "heroic (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2462,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2457",
        "source" : "2455",
        "target" : "2339",
        "shared_name" : "headed (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 13,
        "count" : 1,
        "name" : "headed (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2457,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2437",
        "source" : "2435",
        "target" : "2339",
        "shared_name" : "flawless (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "flawless (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2437,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2432",
        "source" : "2430",
        "target" : "2339",
        "shared_name" : "flashy (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "flashy (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2432,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2427",
        "source" : "2425",
        "target" : "2339",
        "shared_name" : "fit (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 16,
        "count" : 1,
        "name" : "fit (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2427,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2419",
        "source" : "2417",
        "target" : "2339",
        "shared_name" : "fatal (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "fatal (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2419,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2411",
        "source" : "2409",
        "target" : "2339",
        "shared_name" : "evil (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "evil (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2411,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2406",
        "source" : "2404",
        "target" : "2339",
        "shared_name" : "dummy (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "dummy (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2406,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3477",
        "source" : "2390",
        "target" : "3432",
        "shared_name" : "crazy (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "crazy (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3477,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2999",
        "source" : "2390",
        "target" : "2946",
        "shared_name" : "crazy (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "crazy (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 2999,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2392",
        "source" : "2390",
        "target" : "2339",
        "shared_name" : "crazy (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 2,
        "name" : "crazy (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2392,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3442",
        "source" : "2355",
        "target" : "3432",
        "shared_name" : "asleep (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "asleep (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3442,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2959",
        "source" : "2355",
        "target" : "2946",
        "shared_name" : "asleep (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "asleep (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 2959,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2357",
        "source" : "2355",
        "target" : "2339",
        "shared_name" : "asleep (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "asleep (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2357,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2346",
        "source" : "2344",
        "target" : "2339",
        "shared_name" : "afraid (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "afraid (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2346,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2333",
        "source" : "2331",
        "target" : "2037",
        "shared_name" : "wooden (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "wooden (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2333,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2328",
        "source" : "2326",
        "target" : "2037",
        "shared_name" : "unstable (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "unstable (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2328,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2932",
        "source" : "2321",
        "target" : "2654",
        "shared_name" : "unnecessary (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "unnecessary (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2932,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2323",
        "source" : "2321",
        "target" : "2037",
        "shared_name" : "unnecessary (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 3,
        "name" : "unnecessary (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2323,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4005",
        "source" : "2316",
        "target" : "3756",
        "shared_name" : "unfair (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "unfair (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 4005,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3405",
        "source" : "2316",
        "target" : "3174",
        "shared_name" : "unfair (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "unfair (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3405,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2318",
        "source" : "2316",
        "target" : "2037",
        "shared_name" : "unfair (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "unfair (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2318,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2304",
        "source" : "2302",
        "target" : "2037",
        "shared_name" : "stern (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 1,
        "name" : "stern (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2304,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2299",
        "source" : "2297",
        "target" : "2037",
        "shared_name" : "squid (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "squid (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2299,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2273",
        "source" : "2271",
        "target" : "2037",
        "shared_name" : "psychotic (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "psychotic (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2273,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2268",
        "source" : "2266",
        "target" : "2037",
        "shared_name" : "private (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "private (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2268,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2263",
        "source" : "2261",
        "target" : "2037",
        "shared_name" : "precious (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "precious (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2263,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3915",
        "source" : "2256",
        "target" : "3756",
        "shared_name" : "popular (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "popular (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3915,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2829",
        "source" : "2256",
        "target" : "2654",
        "shared_name" : "popular (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "popular (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2829,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2258",
        "source" : "2256",
        "target" : "2037",
        "shared_name" : "popular (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 2,
        "name" : "popular (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2258,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2247",
        "source" : "2245",
        "target" : "2037",
        "shared_name" : "overwhelming (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "overwhelming (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2247,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2239",
        "source" : "2237",
        "target" : "2037",
        "shared_name" : "optimal (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "optimal (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2239,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2225",
        "source" : "2223",
        "target" : "2037",
        "shared_name" : "nervous (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "nervous (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2225,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2220",
        "source" : "2218",
        "target" : "2037",
        "shared_name" : "mental (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "mental (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2220,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3881",
        "source" : "2204",
        "target" : "3756",
        "shared_name" : "low (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 16,
        "count" : 2,
        "name" : "low (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3881,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3073",
        "source" : "2204",
        "target" : "2946",
        "shared_name" : "low (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 16,
        "count" : 1,
        "name" : "low (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3073,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2206",
        "source" : "2204",
        "target" : "2037",
        "shared_name" : "low (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 16,
        "count" : 2,
        "name" : "low (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2206,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2201",
        "source" : "2199",
        "target" : "2037",
        "shared_name" : "lonesome (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "lonesome (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2201,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2492",
        "source" : "2194",
        "target" : "2339",
        "shared_name" : "lonely (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "lonely (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2492,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2196",
        "source" : "2194",
        "target" : "2037",
        "shared_name" : "lonely (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "lonely (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2196,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2191",
        "source" : "2189",
        "target" : "2037",
        "shared_name" : "local (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "local (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2191,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2174",
        "source" : "2172",
        "target" : "2037",
        "shared_name" : "impatient (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "impatient (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2174,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2752",
        "source" : "2161",
        "target" : "2654",
        "shared_name" : "haired (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "haired (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2752,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2163",
        "source" : "2161",
        "target" : "2037",
        "shared_name" : "haired (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 2,
        "name" : "haired (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2163,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2149",
        "source" : "2147",
        "target" : "2037",
        "shared_name" : "fitting (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 15,
        "count" : 1,
        "name" : "fitting (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2149,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2135",
        "source" : "2133",
        "target" : "2037",
        "shared_name" : "extravagant (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "extravagant (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2135,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2109",
        "source" : "2107",
        "target" : "2037",
        "shared_name" : "damn (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "damn (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2109,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3786",
        "source" : "2102",
        "target" : "3756",
        "shared_name" : "cute (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "cute (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3786,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3488",
        "source" : "2102",
        "target" : "3432",
        "shared_name" : "cute (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "cute (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3488,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2395",
        "source" : "2102",
        "target" : "2339",
        "shared_name" : "cute (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "cute (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2395,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2104",
        "source" : "2102",
        "target" : "2037",
        "shared_name" : "cute (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "cute (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2104,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2099",
        "source" : "2097",
        "target" : "2037",
        "shared_name" : "crucial (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "crucial (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2099,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2091",
        "source" : "2089",
        "target" : "2037",
        "shared_name" : "constant (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "constant (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2091,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2086",
        "source" : "2084",
        "target" : "2037",
        "shared_name" : "complete (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 1,
        "name" : "complete (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2086,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3206",
        "source" : "2079",
        "target" : "3174",
        "shared_name" : "clumsy (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "clumsy (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3206,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2081",
        "source" : "2079",
        "target" : "2037",
        "shared_name" : "clumsy (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "clumsy (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2081,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2378",
        "source" : "2071",
        "target" : "2339",
        "shared_name" : "cheerful (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "cheerful (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2378,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2073",
        "source" : "2071",
        "target" : "2037",
        "shared_name" : "cheerful (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "cheerful (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2073,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2068",
        "source" : "2066",
        "target" : "2037",
        "shared_name" : "boorish (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "boorish (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2068,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2063",
        "source" : "2061",
        "target" : "2037",
        "shared_name" : "blonde (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "blonde (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2063,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2668",
        "source" : "2056",
        "target" : "2654",
        "shared_name" : "blind (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 1,
        "name" : "blind (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2668,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2366",
        "source" : "2056",
        "target" : "2339",
        "shared_name" : "blind (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 1,
        "name" : "blind (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2366,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2058",
        "source" : "2056",
        "target" : "2037",
        "shared_name" : "blind (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 1,
        "name" : "blind (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2058,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2665",
        "source" : "2051",
        "target" : "2654",
        "shared_name" : "black (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 22,
        "count" : 1,
        "name" : "black (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2665,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2363",
        "source" : "2051",
        "target" : "2339",
        "shared_name" : "black (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 22,
        "count" : 1,
        "name" : "black (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2363,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2053",
        "source" : "2051",
        "target" : "2037",
        "shared_name" : "black (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 22,
        "count" : 2,
        "name" : "black (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2053,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2022",
        "source" : "2020",
        "target" : "1677",
        "shared_name" : "vibrant (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "vibrant (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 2022,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2014",
        "source" : "2012",
        "target" : "1677",
        "shared_name" : "unnoticed (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "unnoticed (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 2014,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3993",
        "source" : "2001",
        "target" : "3756",
        "shared_name" : "thin (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 13,
        "count" : 2,
        "name" : "thin (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3993,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2003",
        "source" : "2001",
        "target" : "1677",
        "shared_name" : "thin (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 13,
        "count" : 1,
        "name" : "thin (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 2003,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1986",
        "source" : "1984",
        "target" : "1677",
        "shared_name" : "sixth (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "sixth (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1986,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1981",
        "source" : "1979",
        "target" : "1677",
        "shared_name" : "short (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 23,
        "count" : 1,
        "name" : "short (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1981,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1976",
        "source" : "1974",
        "target" : "1677",
        "shared_name" : "seventh (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "seventh (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1976,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1971",
        "source" : "1969",
        "target" : "1677",
        "shared_name" : "scrubby (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 2,
        "name" : "scrubby (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1971,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1957",
        "source" : "1955",
        "target" : "1677",
        "shared_name" : "relaxing (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 9,
        "count" : 1,
        "name" : "relaxing (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1957,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1952",
        "source" : "1950",
        "target" : "1677",
        "shared_name" : "recent (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "recent (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1952,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1947",
        "source" : "1945",
        "target" : "1677",
        "shared_name" : "reassuring (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "reassuring (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1947,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1936",
        "source" : "1934",
        "target" : "1677",
        "shared_name" : "proper (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "proper (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1936,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1928",
        "source" : "1926",
        "target" : "1677",
        "shared_name" : "political (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "political (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1928,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1923",
        "source" : "1921",
        "target" : "1677",
        "shared_name" : "picky (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "picky (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1923,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3904",
        "source" : "1916",
        "target" : "3756",
        "shared_name" : "outside (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 14,
        "count" : 2,
        "name" : "outside (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3904,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1918",
        "source" : "1916",
        "target" : "1677",
        "shared_name" : "outside (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 14,
        "count" : 1,
        "name" : "outside (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1918,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1904",
        "source" : "1902",
        "target" : "1677",
        "shared_name" : "offshore (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "offshore (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1904,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3314",
        "source" : "1897",
        "target" : "3174",
        "shared_name" : "numerous (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "numerous (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3314,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2234",
        "source" : "1897",
        "target" : "2037",
        "shared_name" : "numerous (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 2,
        "name" : "numerous (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2234,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1899",
        "source" : "1897",
        "target" : "1677",
        "shared_name" : "numerous (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "numerous (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1899,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1888",
        "source" : "1886",
        "target" : "1677",
        "shared_name" : "meticulous (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "meticulous (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1888,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1883",
        "source" : "1881",
        "target" : "1677",
        "shared_name" : "mega (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 0,
        "count" : 1,
        "name" : "mega (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1883,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2500",
        "source" : "1876",
        "target" : "2339",
        "shared_name" : "main (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "main (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2500,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1878",
        "source" : "1876",
        "target" : "1677",
        "shared_name" : "main (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "main (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1878,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1873",
        "source" : "1871",
        "target" : "1677",
        "shared_name" : "luxurious (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "luxurious (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1873,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3287",
        "source" : "1860",
        "target" : "3174",
        "shared_name" : "large (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 11,
        "count" : 1,
        "name" : "large (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3287,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1862",
        "source" : "1860",
        "target" : "1677",
        "shared_name" : "large (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 11,
        "count" : 1,
        "name" : "large (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1862,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1857",
        "source" : "1855",
        "target" : "1677",
        "shared_name" : "internal (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "internal (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1857,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1852",
        "source" : "1850",
        "target" : "1677",
        "shared_name" : "interested (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "interested (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1852,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1847",
        "source" : "1845",
        "target" : "1677",
        "shared_name" : "indebted (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "indebted (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1847,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3843",
        "source" : "1837",
        "target" : "3756",
        "shared_name" : "huge (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "huge (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3843,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2468",
        "source" : "1837",
        "target" : "2339",
        "shared_name" : "huge (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 2,
        "name" : "huge (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2468,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1839",
        "source" : "1837",
        "target" : "1677",
        "shared_name" : "huge (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "huge (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1839,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1834",
        "source" : "1832",
        "target" : "1677",
        "shared_name" : "honorable (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "honorable (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1834,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1829",
        "source" : "1827",
        "target" : "1677",
        "shared_name" : "honest (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 1,
        "name" : "honest (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1829,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1824",
        "source" : "1822",
        "target" : "1677",
        "shared_name" : "hidden (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 1,
        "name" : "hidden (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1824,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3539",
        "source" : "1811",
        "target" : "3432",
        "shared_name" : "grand (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 1,
        "name" : "grand (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3539,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3048",
        "source" : "1811",
        "target" : "2946",
        "shared_name" : "grand (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 2,
        "name" : "grand (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3048,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1813",
        "source" : "1811",
        "target" : "1677",
        "shared_name" : "grand (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 7,
        "name" : "grand (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1813,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1805",
        "source" : "1803",
        "target" : "1677",
        "shared_name" : "funny (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "funny (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1805,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1800",
        "source" : "1798",
        "target" : "1677",
        "shared_name" : "friendly (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "friendly (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1800,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1792",
        "source" : "1790",
        "target" : "1677",
        "shared_name" : "frail (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "frail (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1792,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3253",
        "source" : "1785",
        "target" : "3174",
        "shared_name" : "foreign (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 2,
        "name" : "foreign (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3253,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2733",
        "source" : "1785",
        "target" : "2654",
        "shared_name" : "foreign (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "foreign (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2733,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1787",
        "source" : "1785",
        "target" : "1677",
        "shared_name" : "foreign (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "foreign (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1787,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2141",
        "source" : "1777",
        "target" : "2037",
        "shared_name" : "fearsome (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "fearsome (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2141,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1779",
        "source" : "1777",
        "target" : "1677",
        "shared_name" : "fearsome (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "fearsome (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1779,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1771",
        "source" : "1769",
        "target" : "1677",
        "shared_name" : "fair (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 17,
        "count" : 1,
        "name" : "fair (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1771,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3795",
        "source" : "1761",
        "target" : "3756",
        "shared_name" : "difficult (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "difficult (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3795,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2401",
        "source" : "1761",
        "target" : "2339",
        "shared_name" : "difficult (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 3,
        "name" : "difficult (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2401,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1763",
        "source" : "1761",
        "target" : "1677",
        "shared_name" : "difficult (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 2,
        "name" : "difficult (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1763,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1755",
        "source" : "1753",
        "target" : "1677",
        "shared_name" : "dependent (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 1,
        "name" : "dependent (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1755,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1744",
        "source" : "1742",
        "target" : "1677",
        "shared_name" : "concerned (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "concerned (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1744,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2381",
        "source" : "1734",
        "target" : "2339",
        "shared_name" : "clear (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 45,
        "count" : 1,
        "name" : "clear (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2381,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1736",
        "source" : "1734",
        "target" : "1677",
        "shared_name" : "clear (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 45,
        "count" : 1,
        "name" : "clear (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1736,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2372",
        "source" : "1723",
        "target" : "2339",
        "shared_name" : "calm (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 8,
        "count" : 2,
        "name" : "calm (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2372,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1725",
        "source" : "1723",
        "target" : "1677",
        "shared_name" : "calm (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 8,
        "count" : 1,
        "name" : "calm (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1725,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1720",
        "source" : "1718",
        "target" : "1677",
        "shared_name" : "brave (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 2,
        "name" : "brave (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1720,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1715",
        "source" : "1713",
        "target" : "1677",
        "shared_name" : "bogus (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "bogus (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1715,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1710",
        "source" : "1708",
        "target" : "1677",
        "shared_name" : "blank (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 8,
        "count" : 1,
        "name" : "blank (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1710,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1702",
        "source" : "1700",
        "target" : "1677",
        "shared_name" : "biannual (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "biannual (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1702,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4024",
        "source" : "1672",
        "target" : "3756",
        "shared_name" : "worth (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "worth (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 4024,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3742",
        "source" : "1672",
        "target" : "3432",
        "shared_name" : "worth (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "worth (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3742,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3168",
        "source" : "1672",
        "target" : "2946",
        "shared_name" : "worth (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "worth (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3168,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1674",
        "source" : "1672",
        "target" : "1308",
        "shared_name" : "worth (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "worth (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1674,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2017",
        "source" : "1661",
        "target" : "1677",
        "shared_name" : "urban (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "urban (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 2017,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1663",
        "source" : "1661",
        "target" : "1308",
        "shared_name" : "urban (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "urban (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1663,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1658",
        "source" : "1656",
        "target" : "1308",
        "shared_name" : "unofficial (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "unofficial (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1658,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1653",
        "source" : "1651",
        "target" : "1308",
        "shared_name" : "ultimate (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "ultimate (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1653,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3666",
        "source" : "1631",
        "target" : "3432",
        "shared_name" : "strong (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 8,
        "name" : "strong (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3666,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2902",
        "source" : "1631",
        "target" : "2654",
        "shared_name" : "strong (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 3,
        "name" : "strong (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2902,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2307",
        "source" : "1631",
        "target" : "2037",
        "shared_name" : "strong (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 1,
        "name" : "strong (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2307,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1992",
        "source" : "1631",
        "target" : "1677",
        "shared_name" : "strong (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 1,
        "name" : "strong (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1992,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1633",
        "source" : "1631",
        "target" : "1308",
        "shared_name" : "strong (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 1,
        "name" : "strong (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1633,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1622",
        "source" : "1620",
        "target" : "1308",
        "shared_name" : "soft (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 20,
        "count" : 2,
        "name" : "soft (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1622,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1617",
        "source" : "1615",
        "target" : "1308",
        "shared_name" : "smart (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 9,
        "count" : 1,
        "name" : "smart (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1617,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1609",
        "source" : "1607",
        "target" : "1308",
        "shared_name" : "separate (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 19,
        "count" : 1,
        "name" : "separate (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1609,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1604",
        "source" : "1602",
        "target" : "1308",
        "shared_name" : "sarcastic (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "sarcastic (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1604,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1593",
        "source" : "1591",
        "target" : "1308",
        "shared_name" : "rude (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "rude (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1593,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1588",
        "source" : "1586",
        "target" : "1308",
        "shared_name" : "royal (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 2,
        "name" : "royal (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1588,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3628",
        "source" : "1575",
        "target" : "3432",
        "shared_name" : "rich (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 13,
        "count" : 1,
        "name" : "rich (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3628,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2858",
        "source" : "1575",
        "target" : "2654",
        "shared_name" : "rich (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 13,
        "count" : 1,
        "name" : "rich (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2858,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1577",
        "source" : "1575",
        "target" : "1308",
        "shared_name" : "rich (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 13,
        "count" : 1,
        "name" : "rich (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1577,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1572",
        "source" : "1570",
        "target" : "1308",
        "shared_name" : "physical (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 1,
        "name" : "physical (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1572,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1567",
        "source" : "1565",
        "target" : "1308",
        "shared_name" : "phenomenal (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "phenomenal (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1567,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1562",
        "source" : "1560",
        "target" : "1308",
        "shared_name" : "phantom (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "phantom (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1562,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1557",
        "source" : "1555",
        "target" : "1308",
        "shared_name" : "paramilitary (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "paramilitary (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1557,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2523",
        "source" : "1547",
        "target" : "2339",
        "shared_name" : "open (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 36,
        "count" : 1,
        "name" : "open (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2523,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1549",
        "source" : "1547",
        "target" : "1308",
        "shared_name" : "open (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 36,
        "count" : 1,
        "name" : "open (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1549,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3884",
        "source" : "1527",
        "target" : "3756",
        "shared_name" : "military (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "military (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3884,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1529",
        "source" : "1527",
        "target" : "1308",
        "shared_name" : "military (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "military (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1529,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3305",
        "source" : "1519",
        "target" : "3174",
        "shared_name" : "lucky (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 2,
        "name" : "lucky (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3305,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2209",
        "source" : "1519",
        "target" : "2037",
        "shared_name" : "lucky (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "lucky (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2209,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1521",
        "source" : "1519",
        "target" : "1308",
        "shared_name" : "lucky (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "lucky (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1521,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1513",
        "source" : "1511",
        "target" : "1308",
        "shared_name" : "lost (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 21,
        "count" : 1,
        "name" : "lost (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1513,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1502",
        "source" : "1500",
        "target" : "1308",
        "shared_name" : "limited (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 11,
        "count" : 1,
        "name" : "limited (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1502,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3290",
        "source" : "1495",
        "target" : "3174",
        "shared_name" : "legendary (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "legendary (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3290,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1497",
        "source" : "1495",
        "target" : "1308",
        "shared_name" : "legendary (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "legendary (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1497,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1486",
        "source" : "1484",
        "target" : "1308",
        "shared_name" : "laborious (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "laborious (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1486,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2776",
        "source" : "1479",
        "target" : "2654",
        "shared_name" : "idiot (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "idiot (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2776,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2169",
        "source" : "1479",
        "target" : "2037",
        "shared_name" : "idiot (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "idiot (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2169,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1481",
        "source" : "1479",
        "target" : "1308",
        "shared_name" : "idiot (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 5,
        "name" : "idiot (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1481,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1476",
        "source" : "1474",
        "target" : "1308",
        "shared_name" : "identical (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "identical (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1476,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1468",
        "source" : "1466",
        "target" : "1308",
        "shared_name" : "hearted (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 0,
        "count" : 1,
        "name" : "hearted (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1468,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1454",
        "source" : "1452",
        "target" : "1308",
        "shared_name" : "gray (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 15,
        "count" : 1,
        "name" : "gray (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1454,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1795",
        "source" : "1441",
        "target" : "1677",
        "shared_name" : "free (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 22,
        "count" : 2,
        "name" : "free (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1795,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1443",
        "source" : "1441",
        "target" : "1308",
        "shared_name" : "free (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 22,
        "count" : 1,
        "name" : "free (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1443,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1432",
        "source" : "1430",
        "target" : "1308",
        "shared_name" : "favorite (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "favorite (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1432,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1421",
        "source" : "1419",
        "target" : "1308",
        "shared_name" : "exquisite (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "exquisite (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1421,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3239",
        "source" : "1411",
        "target" : "3174",
        "shared_name" : "excited (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 12,
        "count" : 1,
        "name" : "excited (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3239,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2127",
        "source" : "1411",
        "target" : "2037",
        "shared_name" : "excited (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 12,
        "count" : 1,
        "name" : "excited (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2127,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1766",
        "source" : "1411",
        "target" : "1677",
        "shared_name" : "excited (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 12,
        "count" : 2,
        "name" : "excited (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1766,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1413",
        "source" : "1411",
        "target" : "1308",
        "shared_name" : "excited (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 12,
        "count" : 1,
        "name" : "excited (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1413,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3026",
        "source" : "1406",
        "target" : "2946",
        "shared_name" : "entire (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 2,
        "name" : "entire (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3026,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2124",
        "source" : "1406",
        "target" : "2037",
        "shared_name" : "entire (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "entire (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2124,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1408",
        "source" : "1406",
        "target" : "1308",
        "shared_name" : "entire (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "entire (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1408,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1403",
        "source" : "1401",
        "target" : "1308",
        "shared_name" : "embarrassing (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "embarrassing (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1403,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1395",
        "source" : "1393",
        "target" : "1308",
        "shared_name" : "dumb (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 2,
        "name" : "dumb (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1395,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3015",
        "source" : "1388",
        "target" : "2946",
        "shared_name" : "dirty (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 13,
        "count" : 3,
        "name" : "dirty (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3015,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1390",
        "source" : "1388",
        "target" : "1308",
        "shared_name" : "dirty (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 13,
        "count" : 1,
        "name" : "dirty (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1390,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1385",
        "source" : "1383",
        "target" : "1308",
        "shared_name" : "desperate (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 2,
        "name" : "desperate (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1385,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1377",
        "source" : "1375",
        "target" : "1308",
        "shared_name" : "decent (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 1,
        "name" : "decent (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1377,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3466",
        "source" : "1361",
        "target" : "3432",
        "shared_name" : "close (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 37,
        "count" : 2,
        "name" : "close (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3466,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2983",
        "source" : "1361",
        "target" : "2946",
        "shared_name" : "close (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 37,
        "count" : 2,
        "name" : "close (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 2983,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2384",
        "source" : "1361",
        "target" : "2339",
        "shared_name" : "close (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 37,
        "count" : 3,
        "name" : "close (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2384,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2076",
        "source" : "1361",
        "target" : "2037",
        "shared_name" : "close (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 37,
        "count" : 2,
        "name" : "close (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2076,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1363",
        "source" : "1361",
        "target" : "1308",
        "shared_name" : "close (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 37,
        "count" : 2,
        "name" : "close (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1363,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1358",
        "source" : "1356",
        "target" : "1308",
        "shared_name" : "classical (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 3,
        "name" : "classical (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1358,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1350",
        "source" : "1348",
        "target" : "1308",
        "shared_name" : "cautious (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "cautious (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1350,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3457",
        "source" : "1340",
        "target" : "3432",
        "shared_name" : "broad (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 9,
        "count" : 2,
        "name" : "broad (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3457,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1342",
        "source" : "1340",
        "target" : "1308",
        "shared_name" : "broad (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 9,
        "count" : 1,
        "name" : "broad (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1342,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1337",
        "source" : "1335",
        "target" : "1308",
        "shared_name" : "bleak (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "bleak (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1337,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1323",
        "source" : "1321",
        "target" : "1308",
        "shared_name" : "annoying (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "annoying (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1323,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1315",
        "source" : "1313",
        "target" : "1308",
        "shared_name" : "adamant (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "adamant (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1315,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1310",
        "source" : "1306",
        "target" : "1308",
        "shared_name" : "academic (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 2,
        "name" : "academic (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1310,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1300",
        "source" : "1298",
        "target" : "928",
        "shared_name" : "worthwhile (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "worthwhile (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1300,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1292",
        "source" : "1290",
        "target" : "928",
        "shared_name" : "vulgar (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "vulgar (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1292,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1287",
        "source" : "1285",
        "target" : "928",
        "shared_name" : "usual (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "usual (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1287,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1282",
        "source" : "1280",
        "target" : "928",
        "shared_name" : "unpaid (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "unpaid (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1282,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2620",
        "source" : "1275",
        "target" : "2339",
        "shared_name" : "underground (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "underground (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2620,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1277",
        "source" : "1275",
        "target" : "928",
        "shared_name" : "underground (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 2,
        "name" : "underground (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1277,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3999",
        "source" : "1270",
        "target" : "3756",
        "shared_name" : "tough (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 12,
        "count" : 1,
        "name" : "tough (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3999,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3685",
        "source" : "1270",
        "target" : "3432",
        "shared_name" : "tough (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 12,
        "count" : 1,
        "name" : "tough (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3685,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1645",
        "source" : "1270",
        "target" : "1308",
        "shared_name" : "tough (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 12,
        "count" : 1,
        "name" : "tough (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1645,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1272",
        "source" : "1270",
        "target" : "928",
        "shared_name" : "tough (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 12,
        "count" : 1,
        "name" : "tough (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1272,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3146",
        "source" : "1265",
        "target" : "2946",
        "shared_name" : "thorough (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "thorough (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3146,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1267",
        "source" : "1265",
        "target" : "928",
        "shared_name" : "thorough (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "thorough (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1267,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3371",
        "source" : "1260",
        "target" : "3174",
        "shared_name" : "suspicious (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "suspicious (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3371,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3143",
        "source" : "1260",
        "target" : "2946",
        "shared_name" : "suspicious (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "suspicious (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3143,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2916",
        "source" : "1260",
        "target" : "2654",
        "shared_name" : "suspicious (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "suspicious (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2916,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2602",
        "source" : "1260",
        "target" : "2339",
        "shared_name" : "suspicious (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "suspicious (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2602,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2313",
        "source" : "1260",
        "target" : "2037",
        "shared_name" : "suspicious (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "suspicious (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2313,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1998",
        "source" : "1260",
        "target" : "1677",
        "shared_name" : "suspicious (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 2,
        "name" : "suspicious (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1998,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1262",
        "source" : "1260",
        "target" : "928",
        "shared_name" : "suspicious (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "suspicious (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1262,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3979",
        "source" : "1252",
        "target" : "3756",
        "shared_name" : "sudden (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "sudden (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3979,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3669",
        "source" : "1252",
        "target" : "3432",
        "shared_name" : "sudden (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "sudden (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3669,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2910",
        "source" : "1252",
        "target" : "2654",
        "shared_name" : "sudden (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "sudden (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2910,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1254",
        "source" : "1252",
        "target" : "928",
        "shared_name" : "sudden (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "sudden (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1254,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1249",
        "source" : "1247",
        "target" : "928",
        "shared_name" : "subject (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 15,
        "count" : 2,
        "name" : "subject (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1249,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1636",
        "source" : "1242",
        "target" : "1308",
        "shared_name" : "stupid (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "stupid (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1636,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1244",
        "source" : "1242",
        "target" : "928",
        "shared_name" : "stupid (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "stupid (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1244,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1239",
        "source" : "1237",
        "target" : "928",
        "shared_name" : "stingy (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "stingy (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1239,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1234",
        "source" : "1232",
        "target" : "928",
        "shared_name" : "sophisticated (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 1,
        "name" : "sophisticated (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1234,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1226",
        "source" : "1224",
        "target" : "928",
        "shared_name" : "silver (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 12,
        "count" : 1,
        "name" : "silver (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1226,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1218",
        "source" : "1216",
        "target" : "928",
        "shared_name" : "shiny (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "shiny (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1218,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1213",
        "source" : "1211",
        "target" : "928",
        "shared_name" : "set (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 45,
        "count" : 2,
        "name" : "set (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1213,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1580",
        "source" : "1200",
        "target" : "1308",
        "shared_name" : "ridiculous (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "ridiculous (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1580,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1202",
        "source" : "1200",
        "target" : "928",
        "shared_name" : "ridiculous (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "ridiculous (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1202,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2861",
        "source" : "1195",
        "target" : "2654",
        "shared_name" : "rid (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 2,
        "name" : "rid (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2861,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1197",
        "source" : "1195",
        "target" : "928",
        "shared_name" : "rid (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "rid (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1197,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1192",
        "source" : "1190",
        "target" : "928",
        "shared_name" : "relieved (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 13,
        "count" : 1,
        "name" : "relieved (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1192,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3926",
        "source" : "1185",
        "target" : "3756",
        "shared_name" : "real (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 13,
        "count" : 2,
        "name" : "real (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3926,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1942",
        "source" : "1185",
        "target" : "1677",
        "shared_name" : "real (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 13,
        "count" : 1,
        "name" : "real (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1942,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1187",
        "source" : "1185",
        "target" : "928",
        "shared_name" : "real (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 13,
        "count" : 1,
        "name" : "real (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1187,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3337",
        "source" : "1177",
        "target" : "3174",
        "shared_name" : "public (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "public (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3337,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2276",
        "source" : "1177",
        "target" : "2037",
        "shared_name" : "public (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "public (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2276,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1179",
        "source" : "1177",
        "target" : "928",
        "shared_name" : "public (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "public (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1179,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1174",
        "source" : "1172",
        "target" : "928",
        "shared_name" : "polar (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 2,
        "name" : "polar (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1174,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1166",
        "source" : "1164",
        "target" : "928",
        "shared_name" : "past (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "past (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1166,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3320",
        "source" : "1156",
        "target" : "3174",
        "shared_name" : "old (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 9,
        "count" : 1,
        "name" : "old (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3320,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3082",
        "source" : "1156",
        "target" : "2946",
        "shared_name" : "old (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 9,
        "count" : 1,
        "name" : "old (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3082,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2818",
        "source" : "1156",
        "target" : "2654",
        "shared_name" : "old (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 9,
        "count" : 2,
        "name" : "old (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2818,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2520",
        "source" : "1156",
        "target" : "2339",
        "shared_name" : "old (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 9,
        "count" : 1,
        "name" : "old (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2520,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1910",
        "source" : "1156",
        "target" : "1677",
        "shared_name" : "old (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 9,
        "count" : 1,
        "name" : "old (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1910,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1544",
        "source" : "1156",
        "target" : "1308",
        "shared_name" : "old (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 9,
        "count" : 1,
        "name" : "old (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1544,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1158",
        "source" : "1156",
        "target" : "928",
        "shared_name" : "old (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 9,
        "count" : 3,
        "name" : "old (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1158,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1150",
        "source" : "1148",
        "target" : "928",
        "shared_name" : "notable (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "notable (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1150,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3597",
        "source" : "1140",
        "target" : "3432",
        "shared_name" : "necessary (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "necessary (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3597,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1142",
        "source" : "1140",
        "target" : "928",
        "shared_name" : "necessary (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "necessary (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1142,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1532",
        "source" : "1135",
        "target" : "1308",
        "shared_name" : "mysterious (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "mysterious (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1532,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1137",
        "source" : "1135",
        "target" : "928",
        "shared_name" : "mysterious (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "mysterious (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1137,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1132",
        "source" : "1130",
        "target" : "928",
        "shared_name" : "miserable (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "miserable (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1132,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1127",
        "source" : "1125",
        "target" : "928",
        "shared_name" : "mere (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "mere (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1127,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1122",
        "source" : "1120",
        "target" : "928",
        "shared_name" : "lovey (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 0,
        "count" : 1,
        "name" : "lovey (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1122,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3573",
        "source" : "1115",
        "target" : "3432",
        "shared_name" : "lovely (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "lovely (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3573,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3302",
        "source" : "1115",
        "target" : "3174",
        "shared_name" : "lovely (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 2,
        "name" : "lovely (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3302,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1516",
        "source" : "1115",
        "target" : "1308",
        "shared_name" : "lovely (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "lovely (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1516,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1117",
        "source" : "1115",
        "target" : "928",
        "shared_name" : "lovely (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "lovely (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1117,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2787",
        "source" : "1104",
        "target" : "2654",
        "shared_name" : "kind (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "kind (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2787,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1106",
        "source" : "1104",
        "target" : "928",
        "shared_name" : "kind (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "kind (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1106,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3872",
        "source" : "1099",
        "target" : "3756",
        "shared_name" : "jealous (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "jealous (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3872,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2180",
        "source" : "1099",
        "target" : "2037",
        "shared_name" : "jealous (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "jealous (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2180,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1101",
        "source" : "1099",
        "target" : "928",
        "shared_name" : "jealous (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "jealous (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1101,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1096",
        "source" : "1094",
        "target" : "928",
        "shared_name" : "inevitable (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "inevitable (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1096,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1091",
        "source" : "1089",
        "target" : "928",
        "shared_name" : "indefensible (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "indefensible (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1091,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1086",
        "source" : "1084",
        "target" : "928",
        "shared_name" : "hostile (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "hostile (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1086,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1081",
        "source" : "1079",
        "target" : "928",
        "shared_name" : "hefty (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "hefty (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1081,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3834",
        "source" : "1074",
        "target" : "3756",
        "shared_name" : "hard (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 22,
        "count" : 1,
        "name" : "hard (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3834,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3268",
        "source" : "1074",
        "target" : "3174",
        "shared_name" : "hard (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 22,
        "count" : 1,
        "name" : "hard (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3268,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2452",
        "source" : "1074",
        "target" : "2339",
        "shared_name" : "hard (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 22,
        "count" : 2,
        "name" : "hard (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2452,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1819",
        "source" : "1074",
        "target" : "1677",
        "shared_name" : "hard (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 22,
        "count" : 1,
        "name" : "hard (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1819,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1463",
        "source" : "1074",
        "target" : "1308",
        "shared_name" : "hard (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 22,
        "count" : 1,
        "name" : "hard (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1463,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1076",
        "source" : "1074",
        "target" : "928",
        "shared_name" : "hard (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 22,
        "count" : 1,
        "name" : "hard (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1076,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1065",
        "source" : "1063",
        "target" : "928",
        "shared_name" : "government (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "government (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1065,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3825",
        "source" : "1055",
        "target" : "3756",
        "shared_name" : "glad (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 2,
        "name" : "glad (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3825,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3533",
        "source" : "1055",
        "target" : "3432",
        "shared_name" : "glad (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 2,
        "name" : "glad (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3533,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3259",
        "source" : "1055",
        "target" : "3174",
        "shared_name" : "glad (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "glad (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3259,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3042",
        "source" : "1055",
        "target" : "2946",
        "shared_name" : "glad (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "glad (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3042,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2736",
        "source" : "1055",
        "target" : "2654",
        "shared_name" : "glad (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 4,
        "name" : "glad (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2736,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2443",
        "source" : "1055",
        "target" : "2339",
        "shared_name" : "glad (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 3,
        "name" : "glad (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2443,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1446",
        "source" : "1055",
        "target" : "1308",
        "shared_name" : "glad (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "glad (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1446,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1057",
        "source" : "1055",
        "target" : "928",
        "shared_name" : "glad (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 2,
        "name" : "glad (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1057,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1052",
        "source" : "1050",
        "target" : "928",
        "shared_name" : "gentlemanly (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 2,
        "name" : "gentlemanly (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1052,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1047",
        "source" : "1045",
        "target" : "928",
        "shared_name" : "futile (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "futile (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1047,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1039",
        "source" : "1037",
        "target" : "928",
        "shared_name" : "following (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 30,
        "count" : 1,
        "name" : "following (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1039,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1034",
        "source" : "1032",
        "target" : "928",
        "shared_name" : "firm (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 14,
        "count" : 1,
        "name" : "firm (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1034,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2422",
        "source" : "1027",
        "target" : "2339",
        "shared_name" : "female (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "female (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2422,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2144",
        "source" : "1027",
        "target" : "2037",
        "shared_name" : "female (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 2,
        "name" : "female (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2144,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1782",
        "source" : "1027",
        "target" : "1677",
        "shared_name" : "female (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "female (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1782,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1435",
        "source" : "1027",
        "target" : "1308",
        "shared_name" : "female (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "female (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1435,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1029",
        "source" : "1027",
        "target" : "928",
        "shared_name" : "female (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "female (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1029,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1024",
        "source" : "1022",
        "target" : "928",
        "shared_name" : "fellow (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 1,
        "name" : "fellow (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1024,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3247",
        "source" : "1017",
        "target" : "3174",
        "shared_name" : "extremist (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "extremist (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3247,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1019",
        "source" : "1017",
        "target" : "928",
        "shared_name" : "extremist (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "extremist (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1019,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1014",
        "source" : "1012",
        "target" : "928",
        "shared_name" : "exhausted (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 8,
        "count" : 1,
        "name" : "exhausted (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1014,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2719",
        "source" : "1007",
        "target" : "2654",
        "shared_name" : "entertaining (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "entertaining (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2719,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2121",
        "source" : "1007",
        "target" : "2037",
        "shared_name" : "entertaining (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "entertaining (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2121,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1009",
        "source" : "1007",
        "target" : "928",
        "shared_name" : "entertaining (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "entertaining (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1009,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1001",
        "source" : "999",
        "target" : "928",
        "shared_name" : "dictatorial (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "dictatorial (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1001,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "996",
        "source" : "994",
        "target" : "928",
        "shared_name" : "destitute (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "destitute (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 996,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "985",
        "source" : "983",
        "target" : "928",
        "shared_name" : "courteous (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "courteous (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 985,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2094",
        "source" : "978",
        "target" : "2037",
        "shared_name" : "correct (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 12,
        "count" : 1,
        "name" : "correct (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2094,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1747",
        "source" : "978",
        "target" : "1677",
        "shared_name" : "correct (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 12,
        "count" : 1,
        "name" : "correct (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1747,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "980",
        "source" : "978",
        "target" : "928",
        "shared_name" : "correct (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 12,
        "count" : 1,
        "name" : "correct (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 980,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3203",
        "source" : "970",
        "target" : "3174",
        "shared_name" : "clever (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "clever (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3203,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "972",
        "source" : "970",
        "target" : "928",
        "shared_name" : "clever (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "clever (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 972,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "967",
        "source" : "965",
        "target" : "928",
        "shared_name" : "central (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "central (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 967,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "956",
        "source" : "954",
        "target" : "928",
        "shared_name" : "beloved (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "beloved (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 956,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3448",
        "source" : "943",
        "target" : "3432",
        "shared_name" : "aware (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "aware (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3448,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2042",
        "source" : "943",
        "target" : "2037",
        "shared_name" : "aware (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "aware (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2042,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1691",
        "source" : "943",
        "target" : "1677",
        "shared_name" : "aware (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "aware (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1691,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "945",
        "source" : "943",
        "target" : "928",
        "shared_name" : "aware (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "aware (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 945,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3445",
        "source" : "938",
        "target" : "3432",
        "shared_name" : "awake (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "awake (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3445,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "940",
        "source" : "938",
        "target" : "928",
        "shared_name" : "awake (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "awake (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 940,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "935",
        "source" : "933",
        "target" : "928",
        "shared_name" : "anti (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "anti (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 935,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3753",
        "source" : "923",
        "target" : "3432",
        "shared_name" : "yummy (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "yummy (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3753,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "925",
        "source" : "923",
        "target" : "623",
        "shared_name" : "yummy (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "yummy (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 925,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2028",
        "source" : "912",
        "target" : "1677",
        "shared_name" : "wonderful (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "wonderful (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 2028,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "914",
        "source" : "912",
        "target" : "623",
        "shared_name" : "wonderful (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 3,
        "name" : "wonderful (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 914,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4016",
        "source" : "907",
        "target" : "3756",
        "shared_name" : "wet (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 9,
        "count" : 4,
        "name" : "wet (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 4016,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "909",
        "source" : "907",
        "target" : "623",
        "shared_name" : "wet (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 9,
        "count" : 1,
        "name" : "wet (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 909,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3160",
        "source" : "899",
        "target" : "2946",
        "shared_name" : "warm (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 13,
        "count" : 1,
        "name" : "warm (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3160,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "901",
        "source" : "899",
        "target" : "623",
        "shared_name" : "warm (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 13,
        "count" : 1,
        "name" : "warm (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 901,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "896",
        "source" : "894",
        "target" : "623",
        "shared_name" : "unrefined (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "unrefined (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 896,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "891",
        "source" : "889",
        "target" : "623",
        "shared_name" : "tight (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 16,
        "count" : 1,
        "name" : "tight (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 891,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "886",
        "source" : "884",
        "target" : "623",
        "shared_name" : "tasty (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "tasty (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 886,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3982",
        "source" : "876",
        "target" : "3756",
        "shared_name" : "super (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "super (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3982,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "878",
        "source" : "876",
        "target" : "623",
        "shared_name" : "super (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "super (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 878,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "873",
        "source" : "871",
        "target" : "623",
        "shared_name" : "stray (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "stray (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 873,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1628",
        "source" : "866",
        "target" : "1308",
        "shared_name" : "special (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 1,
        "name" : "special (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1628,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "868",
        "source" : "866",
        "target" : "623",
        "shared_name" : "special (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 1,
        "name" : "special (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 868,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3962",
        "source" : "855",
        "target" : "3756",
        "shared_name" : "simple (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 9,
        "count" : 2,
        "name" : "simple (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3962,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3357",
        "source" : "855",
        "target" : "3174",
        "shared_name" : "simple (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 9,
        "count" : 1,
        "name" : "simple (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3357,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3121",
        "source" : "855",
        "target" : "2946",
        "shared_name" : "simple (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 9,
        "count" : 1,
        "name" : "simple (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3121,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1612",
        "source" : "855",
        "target" : "1308",
        "shared_name" : "simple (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 9,
        "count" : 1,
        "name" : "simple (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1612,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "857",
        "source" : "855",
        "target" : "623",
        "shared_name" : "simple (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 9,
        "count" : 1,
        "name" : "simple (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 857,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3959",
        "source" : "850",
        "target" : "3756",
        "shared_name" : "sick (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 9,
        "count" : 2,
        "name" : "sick (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3959,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2878",
        "source" : "850",
        "target" : "2654",
        "shared_name" : "sick (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 9,
        "count" : 1,
        "name" : "sick (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2878,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1221",
        "source" : "850",
        "target" : "928",
        "shared_name" : "sick (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 9,
        "count" : 1,
        "name" : "sick (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1221,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "852",
        "source" : "850",
        "target" : "623",
        "shared_name" : "sick (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 9,
        "count" : 1,
        "name" : "sick (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 852,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "847",
        "source" : "845",
        "target" : "623",
        "shared_name" : "shallow (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "shallow (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 847,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3110",
        "source" : "840",
        "target" : "2946",
        "shared_name" : "second (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 15,
        "count" : 1,
        "name" : "second (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3110,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2582",
        "source" : "840",
        "target" : "2339",
        "shared_name" : "second (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 15,
        "count" : 2,
        "name" : "second (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2582,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2285",
        "source" : "840",
        "target" : "2037",
        "shared_name" : "second (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 15,
        "count" : 2,
        "name" : "second (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2285,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "842",
        "source" : "840",
        "target" : "623",
        "shared_name" : "second (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 15,
        "count" : 1,
        "name" : "second (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 842,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3340",
        "source" : "829",
        "target" : "3174",
        "shared_name" : "ready (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 8,
        "count" : 1,
        "name" : "ready (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3340,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2556",
        "source" : "829",
        "target" : "2339",
        "shared_name" : "ready (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 8,
        "count" : 1,
        "name" : "ready (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2556,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1182",
        "source" : "829",
        "target" : "928",
        "shared_name" : "ready (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 8,
        "count" : 1,
        "name" : "ready (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1182,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "831",
        "source" : "829",
        "target" : "623",
        "shared_name" : "ready (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 8,
        "count" : 2,
        "name" : "ready (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 831,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2845",
        "source" : "824",
        "target" : "2654",
        "shared_name" : "quiet (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 13,
        "count" : 1,
        "name" : "quiet (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2845,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2553",
        "source" : "824",
        "target" : "2339",
        "shared_name" : "quiet (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 13,
        "count" : 1,
        "name" : "quiet (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2553,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1939",
        "source" : "824",
        "target" : "1677",
        "shared_name" : "quiet (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 13,
        "count" : 1,
        "name" : "quiet (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1939,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "826",
        "source" : "824",
        "target" : "623",
        "shared_name" : "quiet (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 13,
        "count" : 1,
        "name" : "quiet (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 826,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3334",
        "source" : "819",
        "target" : "3174",
        "shared_name" : "possible (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 2,
        "name" : "possible (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3334,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3093",
        "source" : "819",
        "target" : "2946",
        "shared_name" : "possible (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 2,
        "name" : "possible (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3093,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2832",
        "source" : "819",
        "target" : "2654",
        "shared_name" : "possible (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 2,
        "name" : "possible (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2832,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2545",
        "source" : "819",
        "target" : "2339",
        "shared_name" : "possible (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "possible (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2545,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1931",
        "source" : "819",
        "target" : "1677",
        "shared_name" : "possible (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "possible (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1931,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "821",
        "source" : "819",
        "target" : "623",
        "shared_name" : "possible (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "possible (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 821,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3612",
        "source" : "814",
        "target" : "3432",
        "shared_name" : "particular (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 9,
        "count" : 2,
        "name" : "particular (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3612,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2250",
        "source" : "814",
        "target" : "2037",
        "shared_name" : "particular (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 9,
        "count" : 1,
        "name" : "particular (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2250,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "816",
        "source" : "814",
        "target" : "623",
        "shared_name" : "particular (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 9,
        "count" : 1,
        "name" : "particular (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 816,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "811",
        "source" : "809",
        "target" : "623",
        "shared_name" : "outer (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 13,
        "count" : 1,
        "name" : "outer (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 811,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3603",
        "source" : "804",
        "target" : "3432",
        "shared_name" : "okay (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 4,
        "name" : "okay (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3603,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3317",
        "source" : "804",
        "target" : "3174",
        "shared_name" : "okay (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "okay (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3317,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2815",
        "source" : "804",
        "target" : "2654",
        "shared_name" : "okay (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 5,
        "name" : "okay (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2815,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2517",
        "source" : "804",
        "target" : "2339",
        "shared_name" : "okay (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 2,
        "name" : "okay (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2517,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1907",
        "source" : "804",
        "target" : "1677",
        "shared_name" : "okay (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 4,
        "name" : "okay (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1907,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1153",
        "source" : "804",
        "target" : "928",
        "shared_name" : "okay (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "okay (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1153,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "806",
        "source" : "804",
        "target" : "623",
        "shared_name" : "okay (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "okay (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 806,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3584",
        "source" : "793",
        "target" : "3432",
        "shared_name" : "minded (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 8,
        "count" : 1,
        "name" : "minded (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3584,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "795",
        "source" : "793",
        "target" : "623",
        "shared_name" : "minded (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 8,
        "count" : 1,
        "name" : "minded (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 795,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3570",
        "source" : "788",
        "target" : "3432",
        "shared_name" : "long (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 12,
        "count" : 1,
        "name" : "long (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3570,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3296",
        "source" : "788",
        "target" : "3174",
        "shared_name" : "long (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 12,
        "count" : 2,
        "name" : "long (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3296,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1868",
        "source" : "788",
        "target" : "1677",
        "shared_name" : "long (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 12,
        "count" : 1,
        "name" : "long (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1868,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1508",
        "source" : "788",
        "target" : "1308",
        "shared_name" : "long (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 12,
        "count" : 1,
        "name" : "long (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1508,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "790",
        "source" : "788",
        "target" : "623",
        "shared_name" : "long (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 12,
        "count" : 1,
        "name" : "long (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 790,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1492",
        "source" : "780",
        "target" : "1308",
        "shared_name" : "left (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 24,
        "count" : 1,
        "name" : "left (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1492,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "782",
        "source" : "780",
        "target" : "623",
        "shared_name" : "left (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 24,
        "count" : 1,
        "name" : "left (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 782,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "777",
        "source" : "775",
        "target" : "623",
        "shared_name" : "lazy (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "lazy (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 777,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3067",
        "source" : "770",
        "target" : "2946",
        "shared_name" : "late (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 11,
        "count" : 1,
        "name" : "late (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3067,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2790",
        "source" : "770",
        "target" : "2654",
        "shared_name" : "late (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 11,
        "count" : 1,
        "name" : "late (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2790,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2183",
        "source" : "770",
        "target" : "2037",
        "shared_name" : "late (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 11,
        "count" : 1,
        "name" : "late (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2183,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1109",
        "source" : "770",
        "target" : "928",
        "shared_name" : "late (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 11,
        "count" : 2,
        "name" : "late (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1109,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "772",
        "source" : "770",
        "target" : "623",
        "shared_name" : "late (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 11,
        "count" : 1,
        "name" : "late (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 772,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1489",
        "source" : "765",
        "target" : "1308",
        "shared_name" : "lame (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "lame (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1489,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "767",
        "source" : "765",
        "target" : "623",
        "shared_name" : "lame (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "lame (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 767,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2784",
        "source" : "760",
        "target" : "2654",
        "shared_name" : "insane (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "insane (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2784,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "762",
        "source" : "760",
        "target" : "623",
        "shared_name" : "insane (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "insane (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 762,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "757",
        "source" : "755",
        "target" : "623",
        "shared_name" : "idle (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 5,
        "name" : "idle (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 757,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3548",
        "source" : "747",
        "target" : "3432",
        "shared_name" : "helpful (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "helpful (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3548,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "749",
        "source" : "747",
        "target" : "623",
        "shared_name" : "helpful (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "helpful (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 749,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2758",
        "source" : "742",
        "target" : "2654",
        "shared_name" : "healthy (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "healthy (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2758,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "744",
        "source" : "742",
        "target" : "623",
        "shared_name" : "healthy (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "healthy (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 744,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "730",
        "source" : "728",
        "target" : "623",
        "shared_name" : "final (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "final (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 730,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2138",
        "source" : "723",
        "target" : "2037",
        "shared_name" : "fast (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 15,
        "count" : 1,
        "name" : "fast (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2138,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "725",
        "source" : "723",
        "target" : "623",
        "shared_name" : "fast (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 15,
        "count" : 1,
        "name" : "fast (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 725,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "720",
        "source" : "718",
        "target" : "623",
        "shared_name" : "fancy (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "fancy (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 720,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3514",
        "source" : "713",
        "target" : "3432",
        "shared_name" : "famous (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 2,
        "name" : "famous (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3514,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2722",
        "source" : "713",
        "target" : "2654",
        "shared_name" : "famous (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "famous (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2722,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1774",
        "source" : "713",
        "target" : "1677",
        "shared_name" : "famous (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 2,
        "name" : "famous (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1774,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "715",
        "source" : "713",
        "target" : "623",
        "shared_name" : "famous (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "famous (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 715,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1004",
        "source" : "708",
        "target" : "928",
        "shared_name" : "elegant (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "elegant (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1004,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "710",
        "source" : "708",
        "target" : "623",
        "shared_name" : "elegant (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 5,
        "name" : "elegant (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 710,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "705",
        "source" : "703",
        "target" : "623",
        "shared_name" : "efficient (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "efficient (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 705,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "700",
        "source" : "698",
        "target" : "623",
        "shared_name" : "early (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 9,
        "count" : 1,
        "name" : "early (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 700,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "692",
        "source" : "690",
        "target" : "623",
        "shared_name" : "disheveled (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "disheveled (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 692,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "684",
        "source" : "682",
        "target" : "623",
        "shared_name" : "dead (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 21,
        "count" : 1,
        "name" : "dead (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 684,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3485",
        "source" : "677",
        "target" : "3432",
        "shared_name" : "current (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "current (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3485,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3222",
        "source" : "677",
        "target" : "3174",
        "shared_name" : "current (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "current (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3222,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "679",
        "source" : "677",
        "target" : "623",
        "shared_name" : "current (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "current (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 679,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "671",
        "source" : "669",
        "target" : "623",
        "shared_name" : "commendable (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "commendable (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 671,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2692",
        "source" : "664",
        "target" : "2654",
        "shared_name" : "cold (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 16,
        "count" : 3,
        "name" : "cold (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2692,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1739",
        "source" : "664",
        "target" : "1677",
        "shared_name" : "cold (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 16,
        "count" : 1,
        "name" : "cold (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1739,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1366",
        "source" : "664",
        "target" : "1308",
        "shared_name" : "cold (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 16,
        "count" : 1,
        "name" : "cold (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1366,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "666",
        "source" : "664",
        "target" : "623",
        "shared_name" : "cold (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 16,
        "count" : 1,
        "name" : "cold (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 666,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3775",
        "source" : "656",
        "target" : "3756",
        "shared_name" : "busy (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "busy (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3775,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3460",
        "source" : "656",
        "target" : "3432",
        "shared_name" : "busy (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "busy (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3460,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2974",
        "source" : "656",
        "target" : "2946",
        "shared_name" : "busy (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "busy (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 2974,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2674",
        "source" : "656",
        "target" : "2654",
        "shared_name" : "busy (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "busy (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2674,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2369",
        "source" : "656",
        "target" : "2339",
        "shared_name" : "busy (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 2,
        "name" : "busy (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2369,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "658",
        "source" : "656",
        "target" : "623",
        "shared_name" : "busy (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 2,
        "name" : "busy (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 658,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3454",
        "source" : "651",
        "target" : "3432",
        "shared_name" : "big (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 17,
        "count" : 1,
        "name" : "big (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3454,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3190",
        "source" : "651",
        "target" : "3174",
        "shared_name" : "big (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 17,
        "count" : 3,
        "name" : "big (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3190,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2971",
        "source" : "651",
        "target" : "2946",
        "shared_name" : "big (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 17,
        "count" : 1,
        "name" : "big (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 2971,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2662",
        "source" : "651",
        "target" : "2654",
        "shared_name" : "big (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 17,
        "count" : 2,
        "name" : "big (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2662,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2360",
        "source" : "651",
        "target" : "2339",
        "shared_name" : "big (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 17,
        "count" : 2,
        "name" : "big (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2360,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2048",
        "source" : "651",
        "target" : "2037",
        "shared_name" : "big (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 17,
        "count" : 1,
        "name" : "big (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2048,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1705",
        "source" : "651",
        "target" : "1677",
        "shared_name" : "big (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 17,
        "count" : 2,
        "name" : "big (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1705,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1332",
        "source" : "651",
        "target" : "1308",
        "shared_name" : "big (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 17,
        "count" : 2,
        "name" : "big (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1332,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "959",
        "source" : "651",
        "target" : "928",
        "shared_name" : "big (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 17,
        "count" : 1,
        "name" : "big (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 959,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "653",
        "source" : "651",
        "target" : "623",
        "shared_name" : "big (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 17,
        "count" : 1,
        "name" : "big (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 653,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3187",
        "source" : "646",
        "target" : "3174",
        "shared_name" : "beautiful (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "beautiful (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3187,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2968",
        "source" : "646",
        "target" : "2946",
        "shared_name" : "beautiful (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "beautiful (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 2968,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1697",
        "source" : "646",
        "target" : "1677",
        "shared_name" : "beautiful (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 2,
        "name" : "beautiful (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1697,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "951",
        "source" : "646",
        "target" : "928",
        "shared_name" : "beautiful (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "beautiful (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 951,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "648",
        "source" : "646",
        "target" : "623",
        "shared_name" : "beautiful (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 4,
        "name" : "beautiful (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 648,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2962",
        "source" : "638",
        "target" : "2946",
        "shared_name" : "available (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "available (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 2962,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1688",
        "source" : "638",
        "target" : "1677",
        "shared_name" : "available (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "available (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1688,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1326",
        "source" : "638",
        "target" : "1308",
        "shared_name" : "available (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "available (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1326,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "640",
        "source" : "638",
        "target" : "623",
        "shared_name" : "available (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "available (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 640,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2352",
        "source" : "633",
        "target" : "2339",
        "shared_name" : "angry (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "angry (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2352,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "635",
        "source" : "633",
        "target" : "623",
        "shared_name" : "angry (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "angry (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 635,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3769",
        "source" : "628",
        "target" : "3756",
        "shared_name" : "amazing (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 2,
        "name" : "amazing (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3769,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3176",
        "source" : "628",
        "target" : "3174",
        "shared_name" : "amazing (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 2,
        "name" : "amazing (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3176,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2956",
        "source" : "628",
        "target" : "2946",
        "shared_name" : "amazing (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 2,
        "name" : "amazing (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 2956,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2349",
        "source" : "628",
        "target" : "2339",
        "shared_name" : "amazing (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 3,
        "name" : "amazing (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2349,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1685",
        "source" : "628",
        "target" : "1677",
        "shared_name" : "amazing (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 2,
        "name" : "amazing (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1685,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1318",
        "source" : "628",
        "target" : "1308",
        "shared_name" : "amazing (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "amazing (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1318,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "930",
        "source" : "628",
        "target" : "928",
        "shared_name" : "amazing (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "amazing (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 930,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "630",
        "source" : "628",
        "target" : "623",
        "shared_name" : "amazing (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "amazing (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 630,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3171",
        "source" : "618",
        "target" : "2946",
        "shared_name" : "young (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 14,
        "count" : 2,
        "name" : "young (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3171,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2943",
        "source" : "618",
        "target" : "2654",
        "shared_name" : "young (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 14,
        "count" : 1,
        "name" : "young (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2943,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2651",
        "source" : "618",
        "target" : "2339",
        "shared_name" : "young (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 14,
        "count" : 1,
        "name" : "young (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2651,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "920",
        "source" : "618",
        "target" : "623",
        "shared_name" : "young (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 14,
        "count" : 3,
        "name" : "young (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 920,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "620",
        "source" : "618",
        "target" : "185",
        "shared_name" : "young (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 14,
        "count" : 2,
        "name" : "young (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 620,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4027",
        "source" : "613",
        "target" : "3756",
        "shared_name" : "wrong (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 13,
        "count" : 2,
        "name" : "wrong (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 4027,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3750",
        "source" : "613",
        "target" : "3432",
        "shared_name" : "wrong (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 13,
        "count" : 2,
        "name" : "wrong (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3750,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3429",
        "source" : "613",
        "target" : "3174",
        "shared_name" : "wrong (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 13,
        "count" : 1,
        "name" : "wrong (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3429,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2643",
        "source" : "613",
        "target" : "2339",
        "shared_name" : "wrong (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 13,
        "count" : 1,
        "name" : "wrong (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2643,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2336",
        "source" : "613",
        "target" : "2037",
        "shared_name" : "wrong (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 13,
        "count" : 1,
        "name" : "wrong (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2336,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2034",
        "source" : "613",
        "target" : "1677",
        "shared_name" : "wrong (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 13,
        "count" : 3,
        "name" : "wrong (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 2034,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1303",
        "source" : "613",
        "target" : "928",
        "shared_name" : "wrong (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 13,
        "count" : 2,
        "name" : "wrong (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1303,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "615",
        "source" : "613",
        "target" : "185",
        "shared_name" : "wrong (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 13,
        "count" : 2,
        "name" : "wrong (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 615,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3739",
        "source" : "608",
        "target" : "3432",
        "shared_name" : "worried (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 8,
        "count" : 1,
        "name" : "worried (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3739,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2031",
        "source" : "608",
        "target" : "1677",
        "shared_name" : "worried (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 8,
        "count" : 1,
        "name" : "worried (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 2031,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1669",
        "source" : "608",
        "target" : "1308",
        "shared_name" : "worried (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 8,
        "count" : 1,
        "name" : "worried (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1669,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "917",
        "source" : "608",
        "target" : "623",
        "shared_name" : "worried (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 8,
        "count" : 1,
        "name" : "worried (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 917,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "610",
        "source" : "608",
        "target" : "185",
        "shared_name" : "worried (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 8,
        "count" : 1,
        "name" : "worried (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 610,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "605",
        "source" : "603",
        "target" : "185",
        "shared_name" : "worldwide (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "worldwide (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 605,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3421",
        "source" : "598",
        "target" : "3174",
        "shared_name" : "well (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 22,
        "count" : 1,
        "name" : "well (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3421,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2940",
        "source" : "598",
        "target" : "2654",
        "shared_name" : "well (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 22,
        "count" : 2,
        "name" : "well (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2940,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2025",
        "source" : "598",
        "target" : "1677",
        "shared_name" : "well (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 22,
        "count" : 1,
        "name" : "well (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 2025,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1666",
        "source" : "598",
        "target" : "1308",
        "shared_name" : "well (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 22,
        "count" : 2,
        "name" : "well (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1666,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1295",
        "source" : "598",
        "target" : "928",
        "shared_name" : "well (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 22,
        "count" : 1,
        "name" : "well (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1295,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "904",
        "source" : "598",
        "target" : "623",
        "shared_name" : "well (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 22,
        "count" : 1,
        "name" : "well (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 904,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "600",
        "source" : "598",
        "target" : "185",
        "shared_name" : "well (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 22,
        "count" : 6,
        "name" : "well (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 600,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "595",
        "source" : "593",
        "target" : "185",
        "shared_name" : "unwell (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "unwell (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 595,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "590",
        "source" : "588",
        "target" : "185",
        "shared_name" : "unhappy (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "unhappy (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 590,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "4002",
        "source" : "583",
        "target" : "3756",
        "shared_name" : "true (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 15,
        "count" : 3,
        "name" : "true (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 4002,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3693",
        "source" : "583",
        "target" : "3432",
        "shared_name" : "true (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 15,
        "count" : 1,
        "name" : "true (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3693,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3402",
        "source" : "583",
        "target" : "3174",
        "shared_name" : "true (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 15,
        "count" : 2,
        "name" : "true (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3402,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2009",
        "source" : "583",
        "target" : "1677",
        "shared_name" : "true (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 15,
        "count" : 3,
        "name" : "true (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 2009,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1648",
        "source" : "583",
        "target" : "1308",
        "shared_name" : "true (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 15,
        "count" : 2,
        "name" : "true (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1648,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "585",
        "source" : "583",
        "target" : "185",
        "shared_name" : "true (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 15,
        "count" : 3,
        "name" : "true (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 585,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "580",
        "source" : "578",
        "target" : "185",
        "shared_name" : "toxic (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "toxic (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 580,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3996",
        "source" : "573",
        "target" : "3756",
        "shared_name" : "tired (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "tired (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3996,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3394",
        "source" : "573",
        "target" : "3174",
        "shared_name" : "tired (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 2,
        "name" : "tired (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3394,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3149",
        "source" : "573",
        "target" : "2946",
        "shared_name" : "tired (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 3,
        "name" : "tired (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3149,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2919",
        "source" : "573",
        "target" : "2654",
        "shared_name" : "tired (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "tired (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2919,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2006",
        "source" : "573",
        "target" : "1677",
        "shared_name" : "tired (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "tired (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 2006,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "575",
        "source" : "573",
        "target" : "185",
        "shared_name" : "tired (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 2,
        "name" : "tired (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 575,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "570",
        "source" : "568",
        "target" : "185",
        "shared_name" : "tingly (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 0,
        "count" : 1,
        "name" : "tingly (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 570,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "565",
        "source" : "563",
        "target" : "185",
        "shared_name" : "thick (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 13,
        "count" : 1,
        "name" : "thick (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 565,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1642",
        "source" : "558",
        "target" : "1308",
        "shared_name" : "talented (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "talented (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1642,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "560",
        "source" : "558",
        "target" : "185",
        "shared_name" : "talented (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "talented (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 560,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "555",
        "source" : "553",
        "target" : "185",
        "shared_name" : "surprising (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "surprising (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 555,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3985",
        "source" : "548",
        "target" : "3756",
        "shared_name" : "sure (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 1,
        "name" : "sure (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3985,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3677",
        "source" : "548",
        "target" : "3432",
        "shared_name" : "sure (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 4,
        "name" : "sure (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3677,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3140",
        "source" : "548",
        "target" : "2946",
        "shared_name" : "sure (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 5,
        "name" : "sure (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3140,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2913",
        "source" : "548",
        "target" : "2654",
        "shared_name" : "sure (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 1,
        "name" : "sure (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2913,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2599",
        "source" : "548",
        "target" : "2339",
        "shared_name" : "sure (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 2,
        "name" : "sure (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2599,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2310",
        "source" : "548",
        "target" : "2037",
        "shared_name" : "sure (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 4,
        "name" : "sure (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2310,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1995",
        "source" : "548",
        "target" : "1677",
        "shared_name" : "sure (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 5,
        "name" : "sure (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1995,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1639",
        "source" : "548",
        "target" : "1308",
        "shared_name" : "sure (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 2,
        "name" : "sure (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1639,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1257",
        "source" : "548",
        "target" : "928",
        "shared_name" : "sure (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 3,
        "name" : "sure (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1257,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "881",
        "source" : "548",
        "target" : "623",
        "shared_name" : "sure (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 1,
        "name" : "sure (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 881,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "550",
        "source" : "548",
        "target" : "185",
        "shared_name" : "sure (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 3,
        "name" : "sure (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 550,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3973",
        "source" : "543",
        "target" : "3756",
        "shared_name" : "sorry (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 5,
        "name" : "sorry (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3973,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3658",
        "source" : "543",
        "target" : "3432",
        "shared_name" : "sorry (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 5,
        "name" : "sorry (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3658,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3368",
        "source" : "543",
        "target" : "3174",
        "shared_name" : "sorry (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 2,
        "name" : "sorry (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3368,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3124",
        "source" : "543",
        "target" : "2946",
        "shared_name" : "sorry (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 4,
        "name" : "sorry (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3124,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2889",
        "source" : "543",
        "target" : "2654",
        "shared_name" : "sorry (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 4,
        "name" : "sorry (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2889,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2591",
        "source" : "543",
        "target" : "2339",
        "shared_name" : "sorry (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "sorry (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2591,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2294",
        "source" : "543",
        "target" : "2037",
        "shared_name" : "sorry (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 5,
        "name" : "sorry (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2294,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1989",
        "source" : "543",
        "target" : "1677",
        "shared_name" : "sorry (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 6,
        "name" : "sorry (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1989,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1625",
        "source" : "543",
        "target" : "1308",
        "shared_name" : "sorry (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "sorry (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1625,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "863",
        "source" : "543",
        "target" : "623",
        "shared_name" : "sorry (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 2,
        "name" : "sorry (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 863,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "545",
        "source" : "543",
        "target" : "185",
        "shared_name" : "sorry (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 5,
        "name" : "sorry (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 545,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3650",
        "source" : "538",
        "target" : "3432",
        "shared_name" : "small (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 13,
        "count" : 1,
        "name" : "small (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3650,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "540",
        "source" : "538",
        "target" : "185",
        "shared_name" : "small (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 13,
        "count" : 1,
        "name" : "small (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 540,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3965",
        "source" : "533",
        "target" : "3756",
        "shared_name" : "skilled (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "skilled (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3965,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3647",
        "source" : "533",
        "target" : "3432",
        "shared_name" : "skilled (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 2,
        "name" : "skilled (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3647,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3360",
        "source" : "533",
        "target" : "3174",
        "shared_name" : "skilled (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "skilled (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3360,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2886",
        "source" : "533",
        "target" : "2654",
        "shared_name" : "skilled (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "skilled (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2886,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2588",
        "source" : "533",
        "target" : "2339",
        "shared_name" : "skilled (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "skilled (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2588,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2291",
        "source" : "533",
        "target" : "2037",
        "shared_name" : "skilled (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 2,
        "name" : "skilled (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2291,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1229",
        "source" : "533",
        "target" : "928",
        "shared_name" : "skilled (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "skilled (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1229,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "860",
        "source" : "533",
        "target" : "623",
        "shared_name" : "skilled (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "skilled (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 860,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "535",
        "source" : "533",
        "target" : "185",
        "shared_name" : "skilled (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "skilled (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 535,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2288",
        "source" : "528",
        "target" : "2037",
        "shared_name" : "single (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 1,
        "name" : "single (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2288,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "530",
        "source" : "528",
        "target" : "185",
        "shared_name" : "single (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 1,
        "name" : "single (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 530,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "525",
        "source" : "523",
        "target" : "185",
        "shared_name" : "sharp (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 15,
        "count" : 1,
        "name" : "sharp (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 525,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3354",
        "source" : "518",
        "target" : "3174",
        "shared_name" : "secret (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 14,
        "count" : 2,
        "name" : "secret (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3354,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3113",
        "source" : "518",
        "target" : "2946",
        "shared_name" : "secret (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 14,
        "count" : 1,
        "name" : "secret (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3113,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2585",
        "source" : "518",
        "target" : "2339",
        "shared_name" : "secret (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 14,
        "count" : 1,
        "name" : "secret (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2585,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "520",
        "source" : "518",
        "target" : "185",
        "shared_name" : "secret (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 14,
        "count" : 2,
        "name" : "secret (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 520,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3943",
        "source" : "513",
        "target" : "3756",
        "shared_name" : "safe (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 1,
        "name" : "safe (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3943,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3639",
        "source" : "513",
        "target" : "3432",
        "shared_name" : "safe (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 1,
        "name" : "safe (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3639,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3104",
        "source" : "513",
        "target" : "2946",
        "shared_name" : "safe (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 1,
        "name" : "safe (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3104,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1966",
        "source" : "513",
        "target" : "1677",
        "shared_name" : "safe (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 1,
        "name" : "safe (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1966,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1599",
        "source" : "513",
        "target" : "1308",
        "shared_name" : "safe (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 1,
        "name" : "safe (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1599,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1208",
        "source" : "513",
        "target" : "928",
        "shared_name" : "safe (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 1,
        "name" : "safe (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1208,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "837",
        "source" : "513",
        "target" : "623",
        "shared_name" : "safe (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 1,
        "name" : "safe (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 837,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "515",
        "source" : "513",
        "target" : "185",
        "shared_name" : "safe (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 1,
        "name" : "safe (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 515,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3940",
        "source" : "508",
        "target" : "3756",
        "shared_name" : "sad (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "sad (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3940,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2282",
        "source" : "508",
        "target" : "2037",
        "shared_name" : "sad (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "sad (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2282,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1963",
        "source" : "508",
        "target" : "1677",
        "shared_name" : "sad (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "sad (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1963,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1596",
        "source" : "508",
        "target" : "1308",
        "shared_name" : "sad (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "sad (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1596,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "510",
        "source" : "508",
        "target" : "185",
        "shared_name" : "sad (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "sad (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 510,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3937",
        "source" : "503",
        "target" : "3756",
        "shared_name" : "right (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 36,
        "count" : 2,
        "name" : "right (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3937,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3631",
        "source" : "503",
        "target" : "3432",
        "shared_name" : "right (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 36,
        "count" : 6,
        "name" : "right (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3631,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3348",
        "source" : "503",
        "target" : "3174",
        "shared_name" : "right (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 36,
        "count" : 7,
        "name" : "right (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3348,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3096",
        "source" : "503",
        "target" : "2946",
        "shared_name" : "right (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 36,
        "count" : 2,
        "name" : "right (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3096,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2864",
        "source" : "503",
        "target" : "2654",
        "shared_name" : "right (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 36,
        "count" : 4,
        "name" : "right (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2864,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2564",
        "source" : "503",
        "target" : "2339",
        "shared_name" : "right (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 36,
        "count" : 4,
        "name" : "right (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2564,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2279",
        "source" : "503",
        "target" : "2037",
        "shared_name" : "right (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 36,
        "count" : 3,
        "name" : "right (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2279,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1960",
        "source" : "503",
        "target" : "1677",
        "shared_name" : "right (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 36,
        "count" : 11,
        "name" : "right (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1960,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1583",
        "source" : "503",
        "target" : "1308",
        "shared_name" : "right (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 36,
        "count" : 4,
        "name" : "right (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1583,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1205",
        "source" : "503",
        "target" : "928",
        "shared_name" : "right (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 36,
        "count" : 1,
        "name" : "right (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1205,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "834",
        "source" : "503",
        "target" : "623",
        "shared_name" : "right (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 36,
        "count" : 6,
        "name" : "right (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 834,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "505",
        "source" : "503",
        "target" : "185",
        "shared_name" : "right (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 36,
        "count" : 4,
        "name" : "right (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 505,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "500",
        "source" : "498",
        "target" : "185",
        "shared_name" : "rare (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "rare (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 500,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "495",
        "source" : "493",
        "target" : "185",
        "shared_name" : "pufferfish (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 2,
        "name" : "pufferfish (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 495,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3923",
        "source" : "488",
        "target" : "3756",
        "shared_name" : "psychic (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "psychic (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3923,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "490",
        "source" : "488",
        "target" : "185",
        "shared_name" : "psychic (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "psychic (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 490,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1169",
        "source" : "483",
        "target" : "928",
        "shared_name" : "pitiful (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 2,
        "name" : "pitiful (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1169,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "485",
        "source" : "483",
        "target" : "185",
        "shared_name" : "pitiful (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "pitiful (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 485,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3907",
        "source" : "478",
        "target" : "3756",
        "shared_name" : "personal (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "personal (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3907,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "480",
        "source" : "478",
        "target" : "185",
        "shared_name" : "personal (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "personal (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 480,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3615",
        "source" : "473",
        "target" : "3432",
        "shared_name" : "perfect (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "perfect (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3615,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2537",
        "source" : "473",
        "target" : "2339",
        "shared_name" : "perfect (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "perfect (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2537,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2253",
        "source" : "473",
        "target" : "2037",
        "shared_name" : "perfect (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "perfect (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2253,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "475",
        "source" : "473",
        "target" : "185",
        "shared_name" : "perfect (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "perfect (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 475,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2534",
        "source" : "468",
        "target" : "2339",
        "shared_name" : "pathetic (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "pathetic (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2534,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "470",
        "source" : "468",
        "target" : "185",
        "shared_name" : "pathetic (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "pathetic (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 470,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3901",
        "source" : "463",
        "target" : "3756",
        "shared_name" : "ostanian (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 0,
        "count" : 1,
        "name" : "ostanian (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3901,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "465",
        "source" : "463",
        "target" : "185",
        "shared_name" : "ostanian (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 0,
        "count" : 1,
        "name" : "ostanian (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 465,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3898",
        "source" : "458",
        "target" : "3756",
        "shared_name" : "original (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "original (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3898,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3609",
        "source" : "458",
        "target" : "3432",
        "shared_name" : "original (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "original (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3609,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3328",
        "source" : "458",
        "target" : "3174",
        "shared_name" : "original (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "original (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3328,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3085",
        "source" : "458",
        "target" : "2946",
        "shared_name" : "original (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "original (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3085,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2821",
        "source" : "458",
        "target" : "2654",
        "shared_name" : "original (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "original (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2821,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2526",
        "source" : "458",
        "target" : "2339",
        "shared_name" : "original (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "original (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2526,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2242",
        "source" : "458",
        "target" : "2037",
        "shared_name" : "original (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "original (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2242,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1913",
        "source" : "458",
        "target" : "1677",
        "shared_name" : "original (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "original (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1913,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1552",
        "source" : "458",
        "target" : "1308",
        "shared_name" : "original (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "original (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1552,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1161",
        "source" : "458",
        "target" : "928",
        "shared_name" : "original (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "original (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1161,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "460",
        "source" : "458",
        "target" : "185",
        "shared_name" : "original (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "original (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 460,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "455",
        "source" : "453",
        "target" : "185",
        "shared_name" : "olive (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "olive (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 455,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "450",
        "source" : "448",
        "target" : "185",
        "shared_name" : "odd (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "odd (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 450,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "445",
        "source" : "443",
        "target" : "185",
        "shared_name" : "obtrusive (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "obtrusive (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 445,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3895",
        "source" : "438",
        "target" : "3756",
        "shared_name" : "normal (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "normal (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3895,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2509",
        "source" : "438",
        "target" : "2339",
        "shared_name" : "normal (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "normal (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2509,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2231",
        "source" : "438",
        "target" : "2037",
        "shared_name" : "normal (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 2,
        "name" : "normal (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2231,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1541",
        "source" : "438",
        "target" : "1308",
        "shared_name" : "normal (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 3,
        "name" : "normal (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1541,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "440",
        "source" : "438",
        "target" : "185",
        "shared_name" : "normal (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 3,
        "name" : "normal (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 440,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3892",
        "source" : "433",
        "target" : "3756",
        "shared_name" : "nice (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "nice (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3892,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3600",
        "source" : "433",
        "target" : "3432",
        "shared_name" : "nice (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 2,
        "name" : "nice (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3600,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3311",
        "source" : "433",
        "target" : "3174",
        "shared_name" : "nice (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "nice (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3311,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2506",
        "source" : "433",
        "target" : "2339",
        "shared_name" : "nice (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "nice (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2506,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1894",
        "source" : "433",
        "target" : "1677",
        "shared_name" : "nice (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 3,
        "name" : "nice (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1894,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1538",
        "source" : "433",
        "target" : "1308",
        "shared_name" : "nice (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "nice (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1538,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1145",
        "source" : "433",
        "target" : "928",
        "shared_name" : "nice (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "nice (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1145,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "801",
        "source" : "433",
        "target" : "623",
        "shared_name" : "nice (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 2,
        "name" : "nice (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 801,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "435",
        "source" : "433",
        "target" : "185",
        "shared_name" : "nice (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "nice (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 435,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3308",
        "source" : "428",
        "target" : "3174",
        "shared_name" : "new (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 12,
        "count" : 1,
        "name" : "new (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3308,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3079",
        "source" : "428",
        "target" : "2946",
        "shared_name" : "new (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 12,
        "count" : 2,
        "name" : "new (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3079,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2503",
        "source" : "428",
        "target" : "2339",
        "shared_name" : "new (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 12,
        "count" : 3,
        "name" : "new (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2503,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2228",
        "source" : "428",
        "target" : "2037",
        "shared_name" : "new (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 12,
        "count" : 2,
        "name" : "new (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2228,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1891",
        "source" : "428",
        "target" : "1677",
        "shared_name" : "new (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 12,
        "count" : 1,
        "name" : "new (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1891,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1535",
        "source" : "428",
        "target" : "1308",
        "shared_name" : "new (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 12,
        "count" : 4,
        "name" : "new (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1535,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "798",
        "source" : "428",
        "target" : "623",
        "shared_name" : "new (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 12,
        "count" : 2,
        "name" : "new (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 798,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "430",
        "source" : "428",
        "target" : "185",
        "shared_name" : "new (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 12,
        "count" : 1,
        "name" : "new (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 430,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "425",
        "source" : "423",
        "target" : "185",
        "shared_name" : "mean (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 16,
        "count" : 1,
        "name" : "mean (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 425,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2215",
        "source" : "418",
        "target" : "2037",
        "shared_name" : "married (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "married (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2215,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "420",
        "source" : "418",
        "target" : "185",
        "shared_name" : "married (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "married (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 420,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3576",
        "source" : "413",
        "target" : "3432",
        "shared_name" : "mad (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "mad (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3576,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3076",
        "source" : "413",
        "target" : "2946",
        "shared_name" : "mad (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "mad (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3076,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2802",
        "source" : "413",
        "target" : "2654",
        "shared_name" : "mad (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "mad (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2802,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2212",
        "source" : "413",
        "target" : "2037",
        "shared_name" : "mad (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 2,
        "name" : "mad (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2212,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1524",
        "source" : "413",
        "target" : "1308",
        "shared_name" : "mad (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "mad (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1524,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "415",
        "source" : "413",
        "target" : "185",
        "shared_name" : "mad (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 2,
        "name" : "mad (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 415,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "410",
        "source" : "408",
        "target" : "185",
        "shared_name" : "loose (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 18,
        "count" : 1,
        "name" : "loose (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 410,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "405",
        "source" : "403",
        "target" : "185",
        "shared_name" : "lone (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "lone (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 405,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3878",
        "source" : "398",
        "target" : "3756",
        "shared_name" : "little (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 6,
        "name" : "little (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3878,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3567",
        "source" : "398",
        "target" : "3432",
        "shared_name" : "little (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 3,
        "name" : "little (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3567,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3293",
        "source" : "398",
        "target" : "3174",
        "shared_name" : "little (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 4,
        "name" : "little (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3293,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3070",
        "source" : "398",
        "target" : "2946",
        "shared_name" : "little (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 2,
        "name" : "little (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3070,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2796",
        "source" : "398",
        "target" : "2654",
        "shared_name" : "little (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 3,
        "name" : "little (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2796,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2489",
        "source" : "398",
        "target" : "2339",
        "shared_name" : "little (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 3,
        "name" : "little (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2489,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2186",
        "source" : "398",
        "target" : "2037",
        "shared_name" : "little (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 1,
        "name" : "little (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2186,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1865",
        "source" : "398",
        "target" : "1677",
        "shared_name" : "little (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 7,
        "name" : "little (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1865,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1505",
        "source" : "398",
        "target" : "1308",
        "shared_name" : "little (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 7,
        "name" : "little (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1505,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1112",
        "source" : "398",
        "target" : "928",
        "shared_name" : "little (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 2,
        "name" : "little (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1112,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "785",
        "source" : "398",
        "target" : "623",
        "shared_name" : "little (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 3,
        "name" : "little (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 785,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "400",
        "source" : "398",
        "target" : "185",
        "shared_name" : "little (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 9,
        "name" : "little (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 400,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "395",
        "source" : "393",
        "target" : "185",
        "shared_name" : "like (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 11,
        "count" : 1,
        "name" : "like (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 395,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "390",
        "source" : "388",
        "target" : "185",
        "shared_name" : "lethal (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "lethal (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 390,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3875",
        "source" : "383",
        "target" : "3756",
        "shared_name" : "key (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 21,
        "count" : 1,
        "name" : "key (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3875,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "385",
        "source" : "383",
        "target" : "185",
        "shared_name" : "key (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 21,
        "count" : 1,
        "name" : "key (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 385,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "380",
        "source" : "378",
        "target" : "185",
        "shared_name" : "infamous (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "infamous (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 380,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3849",
        "source" : "373",
        "target" : "3756",
        "shared_name" : "impressive (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 2,
        "name" : "impressive (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3849,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3564",
        "source" : "373",
        "target" : "3432",
        "shared_name" : "impressive (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "impressive (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3564,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3279",
        "source" : "373",
        "target" : "3174",
        "shared_name" : "impressive (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "impressive (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3279,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "375",
        "source" : "373",
        "target" : "185",
        "shared_name" : "impressive (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "impressive (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 375,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3561",
        "source" : "368",
        "target" : "3432",
        "shared_name" : "important (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "important (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3561,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2471",
        "source" : "368",
        "target" : "2339",
        "shared_name" : "important (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "important (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2471,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2177",
        "source" : "368",
        "target" : "2037",
        "shared_name" : "important (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "important (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2177,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1842",
        "source" : "368",
        "target" : "1677",
        "shared_name" : "important (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "important (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1842,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "370",
        "source" : "368",
        "target" : "185",
        "shared_name" : "important (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "important (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 370,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3846",
        "source" : "363",
        "target" : "3756",
        "shared_name" : "hungry (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "hungry (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3846,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2166",
        "source" : "363",
        "target" : "2037",
        "shared_name" : "hungry (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "hungry (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2166,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "752",
        "source" : "363",
        "target" : "623",
        "shared_name" : "hungry (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "hungry (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 752,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "365",
        "source" : "363",
        "target" : "185",
        "shared_name" : "hungry (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "hungry (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 365,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "360",
        "source" : "358",
        "target" : "185",
        "shared_name" : "horrendous (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "horrendous (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 360,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2465",
        "source" : "353",
        "target" : "2339",
        "shared_name" : "hopeless (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "hopeless (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2465,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "355",
        "source" : "353",
        "target" : "185",
        "shared_name" : "hopeless (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "hopeless (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 355,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3837",
        "source" : "348",
        "target" : "3756",
        "shared_name" : "high (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 18,
        "count" : 1,
        "name" : "high (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3837,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1471",
        "source" : "348",
        "target" : "1308",
        "shared_name" : "high (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 18,
        "count" : 1,
        "name" : "high (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1471,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "350",
        "source" : "348",
        "target" : "185",
        "shared_name" : "high (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 18,
        "count" : 1,
        "name" : "high (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 350,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "345",
        "source" : "343",
        "target" : "185",
        "shared_name" : "hectic (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "hectic (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 345,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3545",
        "source" : "338",
        "target" : "3432",
        "shared_name" : "happy (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 4,
        "name" : "happy (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3545,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3265",
        "source" : "338",
        "target" : "3174",
        "shared_name" : "happy (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 2,
        "name" : "happy (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3265,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3054",
        "source" : "338",
        "target" : "2946",
        "shared_name" : "happy (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "happy (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3054,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2755",
        "source" : "338",
        "target" : "2654",
        "shared_name" : "happy (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "happy (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2755,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2449",
        "source" : "338",
        "target" : "2339",
        "shared_name" : "happy (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "happy (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2449,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1460",
        "source" : "338",
        "target" : "1308",
        "shared_name" : "happy (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 3,
        "name" : "happy (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1460,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1071",
        "source" : "338",
        "target" : "928",
        "shared_name" : "happy (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "happy (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1071,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "739",
        "source" : "338",
        "target" : "623",
        "shared_name" : "happy (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 2,
        "name" : "happy (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 739,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "340",
        "source" : "338",
        "target" : "185",
        "shared_name" : "happy (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 2,
        "name" : "happy (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 340,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3831",
        "source" : "333",
        "target" : "3756",
        "shared_name" : "great (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 3,
        "name" : "great (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3831,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3542",
        "source" : "333",
        "target" : "3432",
        "shared_name" : "great (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 2,
        "name" : "great (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3542,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3051",
        "source" : "333",
        "target" : "2946",
        "shared_name" : "great (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 2,
        "name" : "great (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3051,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2158",
        "source" : "333",
        "target" : "2037",
        "shared_name" : "great (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 1,
        "name" : "great (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2158,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1816",
        "source" : "333",
        "target" : "1677",
        "shared_name" : "great (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 2,
        "name" : "great (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1816,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1457",
        "source" : "333",
        "target" : "1308",
        "shared_name" : "great (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 1,
        "name" : "great (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1457,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1068",
        "source" : "333",
        "target" : "928",
        "shared_name" : "great (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 1,
        "name" : "great (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1068,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "335",
        "source" : "333",
        "target" : "185",
        "shared_name" : "great (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 2,
        "name" : "great (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 335,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3828",
        "source" : "328",
        "target" : "3756",
        "shared_name" : "good (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 27,
        "count" : 9,
        "name" : "good (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3828,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3536",
        "source" : "328",
        "target" : "3432",
        "shared_name" : "good (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 27,
        "count" : 4,
        "name" : "good (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3536,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3262",
        "source" : "328",
        "target" : "3174",
        "shared_name" : "good (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 27,
        "count" : 6,
        "name" : "good (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3262,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3045",
        "source" : "328",
        "target" : "2946",
        "shared_name" : "good (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 27,
        "count" : 5,
        "name" : "good (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3045,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2739",
        "source" : "328",
        "target" : "2654",
        "shared_name" : "good (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 27,
        "count" : 5,
        "name" : "good (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2739,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2446",
        "source" : "328",
        "target" : "2339",
        "shared_name" : "good (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 27,
        "count" : 3,
        "name" : "good (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2446,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2155",
        "source" : "328",
        "target" : "2037",
        "shared_name" : "good (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 27,
        "count" : 6,
        "name" : "good (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2155,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1808",
        "source" : "328",
        "target" : "1677",
        "shared_name" : "good (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 27,
        "count" : 8,
        "name" : "good (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1808,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1449",
        "source" : "328",
        "target" : "1308",
        "shared_name" : "good (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 27,
        "count" : 7,
        "name" : "good (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1449,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1060",
        "source" : "328",
        "target" : "928",
        "shared_name" : "good (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 27,
        "count" : 5,
        "name" : "good (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1060,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "736",
        "source" : "328",
        "target" : "623",
        "shared_name" : "good (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 27,
        "count" : 7,
        "name" : "good (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 736,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "330",
        "source" : "328",
        "target" : "185",
        "shared_name" : "good (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 27,
        "count" : 9,
        "name" : "good (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 330,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3525",
        "source" : "323",
        "target" : "3432",
        "shared_name" : "fun (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "fun (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3525,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3256",
        "source" : "323",
        "target" : "3174",
        "shared_name" : "fun (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "fun (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3256,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2440",
        "source" : "323",
        "target" : "2339",
        "shared_name" : "fun (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "fun (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2440,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2152",
        "source" : "323",
        "target" : "2037",
        "shared_name" : "fun (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 2,
        "name" : "fun (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2152,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1042",
        "source" : "323",
        "target" : "928",
        "shared_name" : "fun (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "fun (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 1042,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "733",
        "source" : "323",
        "target" : "623",
        "shared_name" : "fun (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 2,
        "name" : "fun (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 733,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "325",
        "source" : "323",
        "target" : "185",
        "shared_name" : "fun (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "fun (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 325,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3517",
        "source" : "318",
        "target" : "3432",
        "shared_name" : "fine (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 1,
        "name" : "fine (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3517,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2730",
        "source" : "318",
        "target" : "2654",
        "shared_name" : "fine (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 1,
        "name" : "fine (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2730,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "320",
        "source" : "318",
        "target" : "185",
        "shared_name" : "fine (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 1,
        "name" : "fine (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 320,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3812",
        "source" : "313",
        "target" : "3756",
        "shared_name" : "fierce (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "fierce (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3812,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1438",
        "source" : "313",
        "target" : "1308",
        "shared_name" : "fierce (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "fierce (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1438,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "315",
        "source" : "313",
        "target" : "185",
        "shared_name" : "fierce (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "fierce (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 315,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3809",
        "source" : "308",
        "target" : "3756",
        "shared_name" : "fake (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 8,
        "count" : 1,
        "name" : "fake (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3809,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3250",
        "source" : "308",
        "target" : "3174",
        "shared_name" : "fake (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 8,
        "count" : 1,
        "name" : "fake (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3250,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1427",
        "source" : "308",
        "target" : "1308",
        "shared_name" : "fake (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 8,
        "count" : 1,
        "name" : "fake (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1427,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "310",
        "source" : "308",
        "target" : "185",
        "shared_name" : "fake (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 8,
        "count" : 2,
        "name" : "fake (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 310,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "305",
        "source" : "303",
        "target" : "185",
        "shared_name" : "faint (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 8,
        "count" : 1,
        "name" : "faint (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 305,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "300",
        "source" : "298",
        "target" : "185",
        "shared_name" : "extreme (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 6,
        "count" : 1,
        "name" : "extreme (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 300,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3806",
        "source" : "293",
        "target" : "3756",
        "shared_name" : "extra (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 1,
        "name" : "extra (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3806,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1424",
        "source" : "293",
        "target" : "1308",
        "shared_name" : "extra (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 1,
        "name" : "extra (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1424,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "295",
        "source" : "293",
        "target" : "185",
        "shared_name" : "extra (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 1,
        "name" : "extra (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 295,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3029",
        "source" : "288",
        "target" : "2946",
        "shared_name" : "exciting (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 1,
        "name" : "exciting (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3029,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2414",
        "source" : "288",
        "target" : "2339",
        "shared_name" : "exciting (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 3,
        "name" : "exciting (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2414,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2130",
        "source" : "288",
        "target" : "2037",
        "shared_name" : "exciting (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 1,
        "name" : "exciting (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2130,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1416",
        "source" : "288",
        "target" : "1308",
        "shared_name" : "exciting (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 1,
        "name" : "exciting (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1416,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "290",
        "source" : "288",
        "target" : "185",
        "shared_name" : "exciting (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 10,
        "count" : 2,
        "name" : "exciting (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 290,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3501",
        "source" : "283",
        "target" : "3432",
        "shared_name" : "easy (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 15,
        "count" : 1,
        "name" : "easy (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3501,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3023",
        "source" : "283",
        "target" : "2946",
        "shared_name" : "easy (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 15,
        "count" : 1,
        "name" : "easy (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 3023,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2716",
        "source" : "283",
        "target" : "2654",
        "shared_name" : "easy (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 15,
        "count" : 1,
        "name" : "easy (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2716,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2118",
        "source" : "283",
        "target" : "2037",
        "shared_name" : "easy (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 15,
        "count" : 1,
        "name" : "easy (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2118,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1398",
        "source" : "283",
        "target" : "1308",
        "shared_name" : "easy (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 15,
        "count" : 1,
        "name" : "easy (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1398,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "285",
        "source" : "283",
        "target" : "185",
        "shared_name" : "easy (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 15,
        "count" : 1,
        "name" : "easy (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 285,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2713",
        "source" : "278",
        "target" : "2654",
        "shared_name" : "dry (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 19,
        "count" : 2,
        "name" : "dry (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2713,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "695",
        "source" : "278",
        "target" : "623",
        "shared_name" : "dry (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 19,
        "count" : 1,
        "name" : "dry (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 695,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "280",
        "source" : "278",
        "target" : "185",
        "shared_name" : "dry (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 19,
        "count" : 1,
        "name" : "dry (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 280,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3798",
        "source" : "273",
        "target" : "3756",
        "shared_name" : "discrete (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "discrete (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3798,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "275",
        "source" : "273",
        "target" : "185",
        "shared_name" : "discrete (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "discrete (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 275,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3792",
        "source" : "268",
        "target" : "3756",
        "shared_name" : "different (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 3,
        "name" : "different (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3792,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3231",
        "source" : "268",
        "target" : "3174",
        "shared_name" : "different (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "different (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3231,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2705",
        "source" : "268",
        "target" : "2654",
        "shared_name" : "different (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "different (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2705,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2398",
        "source" : "268",
        "target" : "2339",
        "shared_name" : "different (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "different (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2398,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2115",
        "source" : "268",
        "target" : "2037",
        "shared_name" : "different (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "different (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2115,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1758",
        "source" : "268",
        "target" : "1677",
        "shared_name" : "different (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "different (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1758,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "270",
        "source" : "268",
        "target" : "185",
        "shared_name" : "different (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 2,
        "name" : "different (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 270,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3228",
        "source" : "263",
        "target" : "3174",
        "shared_name" : "delicious (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "delicious (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3228,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2112",
        "source" : "263",
        "target" : "2037",
        "shared_name" : "delicious (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 4,
        "name" : "delicious (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2112,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1750",
        "source" : "263",
        "target" : "1677",
        "shared_name" : "delicious (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "delicious (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1750,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1380",
        "source" : "263",
        "target" : "1308",
        "shared_name" : "delicious (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 3,
        "name" : "delicious (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1380,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "991",
        "source" : "263",
        "target" : "928",
        "shared_name" : "delicious (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 1,
        "name" : "delicious (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 991,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "687",
        "source" : "263",
        "target" : "623",
        "shared_name" : "delicious (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 2,
        "name" : "delicious (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 687,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "265",
        "source" : "263",
        "target" : "185",
        "shared_name" : "delicious (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 3,
        "count" : 2,
        "name" : "delicious (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 265,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3789",
        "source" : "258",
        "target" : "3756",
        "shared_name" : "dangerous (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 4,
        "name" : "dangerous (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3789,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3225",
        "source" : "258",
        "target" : "3174",
        "shared_name" : "dangerous (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 2,
        "name" : "dangerous (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3225,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1372",
        "source" : "258",
        "target" : "1308",
        "shared_name" : "dangerous (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "dangerous (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1372,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "988",
        "source" : "258",
        "target" : "928",
        "shared_name" : "dangerous (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 1,
        "name" : "dangerous (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 988,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "260",
        "source" : "258",
        "target" : "185",
        "shared_name" : "dangerous (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 2,
        "count" : 2,
        "name" : "dangerous (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 260,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3474",
        "source" : "253",
        "target" : "3432",
        "shared_name" : "countless (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "countless (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3474,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "255",
        "source" : "253",
        "target" : "185",
        "shared_name" : "countless (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 1,
        "count" : 1,
        "name" : "countless (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 255,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3219",
        "source" : "248",
        "target" : "3174",
        "shared_name" : "cool (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 11,
        "count" : 1,
        "name" : "cool (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3219,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2996",
        "source" : "248",
        "target" : "2946",
        "shared_name" : "cool (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 11,
        "count" : 1,
        "name" : "cool (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 2996,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2387",
        "source" : "248",
        "target" : "2339",
        "shared_name" : "cool (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 11,
        "count" : 1,
        "name" : "cool (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2387,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1369",
        "source" : "248",
        "target" : "1308",
        "shared_name" : "cool (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 11,
        "count" : 1,
        "name" : "cool (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1369,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "975",
        "source" : "248",
        "target" : "928",
        "shared_name" : "cool (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 11,
        "count" : 2,
        "name" : "cool (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 975,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "674",
        "source" : "248",
        "target" : "623",
        "shared_name" : "cool (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 11,
        "count" : 1,
        "name" : "cool (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 674,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "250",
        "source" : "248",
        "target" : "185",
        "shared_name" : "cool (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 11,
        "count" : 1,
        "name" : "cool (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 250,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3463",
        "source" : "243",
        "target" : "3432",
        "shared_name" : "certain (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 1,
        "name" : "certain (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3463,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1731",
        "source" : "243",
        "target" : "1677",
        "shared_name" : "certain (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 1,
        "name" : "certain (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1731,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1353",
        "source" : "243",
        "target" : "1308",
        "shared_name" : "certain (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 1,
        "name" : "certain (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1353,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "245",
        "source" : "243",
        "target" : "185",
        "shared_name" : "certain (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 7,
        "count" : 1,
        "name" : "certain (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 245,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "240",
        "source" : "238",
        "target" : "185",
        "shared_name" : "casual (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 9,
        "count" : 1,
        "name" : "casual (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 240,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2980",
        "source" : "233",
        "target" : "2946",
        "shared_name" : "careful (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "careful (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 2980,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2375",
        "source" : "233",
        "target" : "2339",
        "shared_name" : "careful (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "careful (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2375,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1728",
        "source" : "233",
        "target" : "1677",
        "shared_name" : "careful (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 2,
        "name" : "careful (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1728,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1345",
        "source" : "233",
        "target" : "1308",
        "shared_name" : "careful (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "careful (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1345,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "661",
        "source" : "233",
        "target" : "623",
        "shared_name" : "careful (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 2,
        "name" : "careful (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 661,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "235",
        "source" : "233",
        "target" : "185",
        "shared_name" : "careful (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "careful (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 235,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "230",
        "source" : "228",
        "target" : "185",
        "shared_name" : "capable (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "capable (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 230,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "962",
        "source" : "223",
        "target" : "928",
        "shared_name" : "boring (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "boring (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 962,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "225",
        "source" : "223",
        "target" : "185",
        "shared_name" : "boring (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "boring (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 225,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2671",
        "source" : "218",
        "target" : "2654",
        "shared_name" : "bored (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "bored (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2671,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "220",
        "source" : "218",
        "target" : "185",
        "shared_name" : "bored (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "bored (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 220,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3772",
        "source" : "213",
        "target" : "3756",
        "shared_name" : "bad (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 17,
        "count" : 1,
        "name" : "bad (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3772,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3451",
        "source" : "213",
        "target" : "3432",
        "shared_name" : "bad (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 17,
        "count" : 2,
        "name" : "bad (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3451,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3184",
        "source" : "213",
        "target" : "3174",
        "shared_name" : "bad (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "shared_interaction" : "interacts with",
        "synsetCount" : 17,
        "count" : 2,
        "name" : "bad (interacts with) 02x10_-_Enjoy_the_Resort_to_the_Fullest-Bragging_About_Vacation",
        "interaction" : "interacts with",
        "SUID" : 3184,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2965",
        "source" : "213",
        "target" : "2946",
        "shared_name" : "bad (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 17,
        "count" : 4,
        "name" : "bad (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 2965,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2659",
        "source" : "213",
        "target" : "2654",
        "shared_name" : "bad (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 17,
        "count" : 2,
        "name" : "bad (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2659,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2045",
        "source" : "213",
        "target" : "2037",
        "shared_name" : "bad (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 17,
        "count" : 1,
        "name" : "bad (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2045,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1694",
        "source" : "213",
        "target" : "1677",
        "shared_name" : "bad (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 17,
        "count" : 2,
        "name" : "bad (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1694,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1329",
        "source" : "213",
        "target" : "1308",
        "shared_name" : "bad (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "shared_interaction" : "interacts with",
        "synsetCount" : 17,
        "count" : 1,
        "name" : "bad (interacts with) 02x04_-_The_Pastry_of_Knowledge-The_Informant_s_Great_Romance_Plan_II",
        "interaction" : "interacts with",
        "SUID" : 1329,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "948",
        "source" : "213",
        "target" : "928",
        "shared_name" : "bad (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "shared_interaction" : "interacts with",
        "synsetCount" : 17,
        "count" : 1,
        "name" : "bad (interacts with) 02x03_-_Mission_and_Family-The_Elegant_Bondman-The_Heart_of_a_Child",
        "interaction" : "interacts with",
        "SUID" : 948,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "643",
        "source" : "213",
        "target" : "623",
        "shared_name" : "bad (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 17,
        "count" : 3,
        "name" : "bad (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 643,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "215",
        "source" : "213",
        "target" : "185",
        "shared_name" : "bad (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 17,
        "count" : 4,
        "name" : "bad (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 215,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "210",
        "source" : "208",
        "target" : "185",
        "shared_name" : "armed (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "armed (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 210,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1682",
        "source" : "203",
        "target" : "1677",
        "shared_name" : "actual (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "actual (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1682,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "205",
        "source" : "203",
        "target" : "185",
        "shared_name" : "actual (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 5,
        "count" : 1,
        "name" : "actual (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 205,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3758",
        "source" : "183",
        "target" : "3756",
        "shared_name" : "able (interacts with) 02x12_-_Part_of_the_Family",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 2,
        "name" : "able (interacts with) 02x12_-_Part_of_the_Family",
        "interaction" : "interacts with",
        "SUID" : 3758,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3434",
        "source" : "183",
        "target" : "3432",
        "shared_name" : "able (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "able (interacts with) 02x11_-_Berlint_in_Love-Nightfall_s_Daily_Life",
        "interaction" : "interacts with",
        "SUID" : 3434,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2948",
        "source" : "183",
        "target" : "2946",
        "shared_name" : "able (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "able (interacts with) 02x09_-_The_Hand_That_Connects_to_the_Future",
        "interaction" : "interacts with",
        "SUID" : 2948,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2656",
        "source" : "183",
        "target" : "2654",
        "shared_name" : "able (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 4,
        "name" : "able (interacts with) 02x08_-_The_Symphony_Upon_the_Ship-Sis_s_Herb_Tea",
        "interaction" : "interacts with",
        "SUID" : 2656,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2341",
        "source" : "183",
        "target" : "2339",
        "shared_name" : "able (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 2,
        "name" : "able (interacts with) 02x07_-_Who_Is_This_Mission_For_",
        "interaction" : "interacts with",
        "SUID" : 2341,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2039",
        "source" : "183",
        "target" : "2037",
        "shared_name" : "able (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 3,
        "name" : "able (interacts with) 02x06_-_The_Fearsome_Luxury_Cruise_Ship",
        "interaction" : "interacts with",
        "SUID" : 2039,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1679",
        "source" : "183",
        "target" : "1677",
        "shared_name" : "able (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 4,
        "name" : "able (interacts with) 02x05_-_Plan_to_Cross_the_Border",
        "interaction" : "interacts with",
        "SUID" : 1679,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "625",
        "source" : "183",
        "target" : "623",
        "shared_name" : "able (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 2,
        "name" : "able (interacts with) 02x02_-_Bond_s_Strategy_to_Stay_Alive-Damian_s_Field_Research_Trip",
        "interaction" : "interacts with",
        "SUID" : 625,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "187",
        "source" : "183",
        "target" : "185",
        "shared_name" : "able (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "shared_interaction" : "interacts with",
        "synsetCount" : 4,
        "count" : 1,
        "name" : "able (interacts with) 02x01_-_Follow_Mama_and_Papa",
        "interaction" : "interacts with",
        "SUID" : 187,
        "nodeType" : "ADJ",
        "selected" : false
      },
      "selected" : false
    } ]
  }
}}